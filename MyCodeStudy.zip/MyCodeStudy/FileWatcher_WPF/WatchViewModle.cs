﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Cryptography;
using System.Windows;


namespace FileWatcher_WPF
{
    public class WatchViewModle
    {
       public  FileWatcher FileWatcher;

        public WatchViewModle()
        {
            FileWatcher = new FileWatcher();
            BeginFileWatcher();
        }

        public void BeginFileWatcher()
        {
            try
            {
                FileWatcher.BeginWathceFile(@"C:\Users\F7692596\Desktop\", ".");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
    public class FileWatcher:ObservableObject
    {
        private string notifyMessage = "";
        public string NotifyMessage { get => notifyMessage; set => SetProperty(ref notifyMessage, value); }

        FileSystemWatcher fileSystemWatcher;

        public FileWatcher()
        { 
            fileSystemWatcher = new FileSystemWatcher();
        }

        private string monitorFolder;

        public string onitorFolder
        {
            get { return monitorFolder; }
            set { monitorFolder = value; }
        }

        private string filter;

        public string Filter { get => filter; set => filter = value; }


        public void BeginWathceFile(string path,string filter)
        {            
            try
            {
                fileSystemWatcher.Path = path;
                fileSystemWatcher.Filter = filter;
                fileSystemWatcher.IncludeSubdirectories = true;
                fileSystemWatcher.NotifyFilter = NotifyFilters.FileName | NotifyFilters.Attributes | NotifyFilters.LastWrite | NotifyFilters.LastAccess | NotifyFilters.Size;
                fileSystemWatcher.Changed += FileSystemWatcher_Changed;
                fileSystemWatcher.Created += FileSystemWatcher_Created;
                fileSystemWatcher.Renamed += FileSystemWatcher_Renamed;
                fileSystemWatcher.Deleted += FileSystemWatcher_Deleted;

                fileSystemWatcher.EnableRaisingEvents = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FileSystemWatcher_Deleted(object sender, FileSystemEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void FileSystemWatcher_Renamed(object sender, RenamedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void FileSystemWatcher_Created(object sender, FileSystemEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void FileSystemWatcher_Changed(object sender, FileSystemEventArgs e)
        {
            fileSystemWatcher.EnableRaisingEvents = false;
            switch (e.ChangeType)
            {
                case WatcherChangeTypes.Created:
                    break;
                case WatcherChangeTypes.Deleted:
                    break;
                case WatcherChangeTypes.Changed:
                    notifyMessage = $"{DateTime.Now.ToString("HH:mm:ss")}:文件--{e.Name}发生了改变";
                    break;
                case WatcherChangeTypes.Renamed:
                    break;
                case WatcherChangeTypes.All:
                    break;
                default:
                    break;
            }

            fileSystemWatcher.EnableRaisingEvents = true;
        }
    }



    public class FileHashCode
    {
        private int hashcode;

        public int HashCode
        {
            get { return hashcode; }
            set { hashcode = value; }
        }

        public string GetMD5()
        {
            string path = @"D:\NPOI_Creat.xlsx";
            byte[] md5ByteArr = null;
            try
            {
                using (FileStream fileStream = new FileStream(path, FileMode.Open))
                {
                    var md5 = new MD5CryptoServiceProvider();
                    md5ByteArr = md5.ComputeHash(fileStream);
                }
            }
            catch (Exception)
            {

                throw;
            }
            return md5ByteArr.ToString();
        }
    }
}
