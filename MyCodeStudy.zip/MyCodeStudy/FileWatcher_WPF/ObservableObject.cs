﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace FileWatcher_WPF
{
    public abstract class ObservableObject : INotifyPropertyChanged
    {

        /// <summary>
        /// 属性改变事件，发生变化时向关注我的人打电话
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// 引发属性改变事件的方法
        /// </summary>
        /// <param name="properName">发生改变的属性的名称</param>
        protected void RaisePropertyChanged([CallerMemberName] string properName = null)
        {
            //?保证该成员为空时不会触发该方法
            PropertyChanged?.Invoke(
                this,
                new PropertyChangedEventArgs(properName)
            );
        }

        /// <summary>
        /// 属性设置器，设置新的属性值，如果是真的“新”，调用<seealso cref="="RaisPropertyChanged(string)""/>
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="target"></param>
        /// <param name="value"></param>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        protected bool SetProperty<T>(
            ref T target,
            T value,
            [CallerMemberName] string propertyName = null)
        {
            if (EqualityComparer<T>.Default.Equals(target, value))
                return false;
            target = value;
            RaisePropertyChanged(propertyName);
            return true;
        }
    }
}
