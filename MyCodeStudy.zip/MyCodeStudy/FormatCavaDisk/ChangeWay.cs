﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormatCavaDisk
{
    public enum ChangeWay
    { 
        API_Management=1,
        CMD_Format_com=2,
        CMD_Convert=3
    }
}
