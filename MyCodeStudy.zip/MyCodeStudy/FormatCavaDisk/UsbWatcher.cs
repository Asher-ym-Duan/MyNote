﻿using System;
using System.Collections.Generic;
using Microsoft.Win32;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Management;
using System.Windows.Forms;

namespace FormatCavaDisk
{
    public class UsbWatcher
    {
        public Action TestAction { get; set; }

        public UsbWatcher(Action action)
        {
            TestAction = action;
        }

        private ManagementEventWatcher insertWatcher;
        private TimeSpan withinInterval;

        public void Setup()
        {
            withinInterval = new TimeSpan(0, 0, 0, 0, 500);
            try
            {
                ManagementScope Scope = new ManagementScope("root\\CIMV2");
                Scope.Options.EnablePrivileges = true;

                WqlEventQuery InsertQuery = new WqlEventQuery("__InstanceCreationEvent",
                    withinInterval,
                    "TargetInstance isa 'Win32_USBControllerDevice'");

                insertWatcher = new ManagementEventWatcher(Scope, InsertQuery);
                insertWatcher.EventArrived += new EventArrivedEventHandler(USBAdded);
                insertWatcher.Start();
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public void USBAdded(object sender, EventArrivedEventArgs e)
        {
            TestAction();
        }

    }
}
