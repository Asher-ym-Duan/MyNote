﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormatCavaDisk
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            CheckForIllegalCrossThreadCalls = false;

            this.radioButton3.Enabled = true;
            this.radioButton2.Enabled = true;
            this.radioButton3.Enabled = false;

            this.radioButton1.Checked = true;


            UsbWatcher usbWatcher = new UsbWatcher(StartFormatDisk);
            usbWatcher.Setup();
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            
            StartFormatDisk();
        }

        private void StartFormatDisk()
        {
            this.button1.Enabled = false;
            AppendText("開始檢索磁盤……");
            ChangeWay way = GetGroupItem();
            char[] diskNames = CheckFAT32Disk();
            if (diskNames == null || diskNames.Length == 0)
            {
                AppendText("未找到系統檔案類型為FAT32的磁盤！");
                this.button1.Enabled = true;
                return;
            }

            foreach (var item in diskNames)
            {
                AppendText($"正在格式化磁盤 {item} ……");
                switch (way)
                {
                    case FormatCavaDisk.ChangeWay.API_Management:
                        DriveManager.FormatDrive_Win32Api(item, "Kindle");
                        break;
                    case FormatCavaDisk.ChangeWay.CMD_Format_com:
                        DriveManager.FormatDrive(item, "Kindle");
                        break;
                    case FormatCavaDisk.ChangeWay.CMD_Convert:
                        AppendText("convert格式化方法暫停使用！");
                        break;
                    default:
                        break;
                }
            }
            char[] checkDiskName = CheckFAT32Disk();
            foreach (var item in diskNames)
            {
                if (!checkDiskName.Contains(item))
                {
                    AppendText($"磁盤 {item} 格式化成功！");
                }
                else
                {
                    AppendText($"磁盤 {item} 格式化失敗！");
                }
            }
            this.button1.Enabled = true;
        }


        private ChangeWay GetGroupItem()
        {
            ChangeWay way = 0;
            if (radioButton1.Checked)
            {
                way = FormatCavaDisk.ChangeWay.API_Management;
            }
            else if(radioButton2.Checked)
            {
                way = FormatCavaDisk.ChangeWay.CMD_Format_com;
            }
            return way;
        }

        private char[] CheckFAT32Disk()
        {
            List<char> list=null;
            try
            {
                list = new List<char>();
                foreach (DriveInfo disk in DriveInfo.GetDrives().Where(d => d.IsReady == true && d.VolumeLabel.ToUpper() == "KINDLE" && d.DriveFormat == "FAT32"))
                {
                    char diskName = disk.Name.ToCharArray()[0];
                    list.Add(diskName);
                }
            }
            catch (Exception ex)
            {
                AppendText("發生異常！！！"+ex.Message);
            }
            return list.ToArray();
        }

        private void CheckDisk()
        {
            ClearRichBox();
            DriveInfo drive = DriveInfo.GetDrives().Where(x => x.IsReady == true && x.VolumeLabel == "KINDLE").FirstOrDefault();
            if (drive == null)
            {
                AppendText($"沒有找到磁盤卷名為 KINDLE 的磁盤！", false);
                return;
            }
            if (drive.DriveFormat == "FAT32")
            {
                AppendText($"磁盘{drive.Name}是 {drive.DriveFormat}!", true);
            }
            else
            {
                AppendText($"磁盘{drive.Name}是 {drive.DriveFormat}", false);
            }

        }
        private void AppendText(string text,bool isFAT32)
        {
            string timeStr = DateTime.Now.ToString("HH:mm:ss");
            string showStr = $"[{timeStr}]: {text}";
            this.Invoke(new Action(() => {
                this.richTextBox1.AppendText(showStr);
                if (isFAT32)
                {
                    this.richTextBox1.ForeColor = Color.Red;
                }
                else
                {
                    this.richTextBox1.ForeColor = Color.Green;
                }
            }));
            
            
            //this.richTextBox1.AppendText("\n");
        }

        private void AppendText(string text)
        {
            string timeStr = DateTime.Now.ToString("HH:mm:ss");
            string showStr = $"[{timeStr}]: {text}";
            
            this.richTextBox1.AppendText(showStr+"\n");
            this.richTextBox1.Focus();  //一直獲取焦點，文本增多時不需要手動下滑
        }

        private void ClearRichBox()
        {
            this.Invoke(new Action(()=> { 
                this.richTextBox1.Clear();
            
            }));
        }
    }
}
