﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.Windows;

namespace SocketStudy
{
    public class MySocketServer
    {
        public static SocketServer socket;

        public readonly static object obj_lock = new object();
        public static SocketServer GetInstance()
        {
            if (socket==null)
            {
                lock(obj_lock)
                {
                    if (socket==null)
                    {
                        socket = new SocketServer();
                    }
                }
            }
            return socket;
        }
    }

    public class SocketServer:ISend
    {
        public Socket socket;
        IPAddress IP;
        int Port;
        IPEndPoint IpEndPoint;

        public SocketServer()
        {
            socket = new Socket(AddressFamily.InterNetwork,SocketType.Stream,ProtocolType.Tcp);
        }

        public void ConfigSocket(string address, string portIn)
        {
            IP = IPAddress.Parse(address);    //获取输入的IP地址
            Port = int.Parse(portIn);   //获取输入的端口号
            IpEndPoint = new IPEndPoint(IP, Port);
        }

        public void Listen()
        {
            if (IP==null)
            {
                MessageBox.Show("The ip is null!");
                return;
            }
            try
            {
                socket.Bind(IpEndPoint);    //绑定IpEndPoint
                socket.Listen(10);      //开始监听，10表示监听数量

                    

                    Task.Run(() => {
                        while (true)
                        {
                            //会阻塞线程
                            Socket connectSocket = socket.Accept(); //用socket对象的Accept()方法创建用于和客户端进行通信的socket对象                

                            
                            byte[] buffer = new byte[1024 * 1024 * 3];

                            int len = connectSocket.Receive(buffer);
                            if (len == 0)
                                break;

                        }
                    });

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }


        public int Send(string content)
        {
            byte[] data = new byte[content.Length];
            data = Encoding.ASCII.GetBytes(content);
            return socket.Send(data);
        }

        public void Close()
        { 
        
            }
    }
}
