﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace SocketStudy
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

        }


        public static Socket ServerSocket;    //声明用于监听的套接字
        public static Socket socketAccept;    //声明绑定了客户端的套接字
        public static Socket socket;    //声明用于与某一个客户端通信的套接字
        static bool CFlag = false;
        static bool SFlag = false;

        Thread th1;
        Thread th2;

        private void button_Start_Click(object sender, RoutedEventArgs e)
        {

            ServerSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            Dispatcher.Invoke(() =>
            {
                richTextBox_Show.AppendText("正在连接……\n");
            });

            button_Start.IsEnabled = false;


            IPAddress ip = IPAddress.Parse(textBox_Address.Text);
            int port = int.Parse(textBox_Port.Text);

            IPEndPoint ipEndPoint = new IPEndPoint(ip, port);

            try
            {
                ServerSocket.Bind(ipEndPoint);

                ServerSocket.Listen(10);

                th1 = new Thread(Listen);
                th1.IsBackground = true;
                th1.Start(ServerSocket);

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        void Listen(object sk)
        {
            socketAccept = sk as Socket;
            try
            {
                while (true)
                {
                    socket = socketAccept.Accept();     //阻塞

                    CFlag = false;
                    SFlag = true;

                    //this.richTextBox_Show.Dispatcher.BeginInvoke(new Action(() =>
                    this.Dispatcher.BeginInvoke(new Action(() =>
                    {
                        richTextBox_Show.AppendText(DateTime.Now.ToString("HH:mm:ss  ") + textBox_Address.Text + " 连接成功!" + "\n");
                    }), System.Windows.Threading.DispatcherPriority.ApplicationIdle);
                    //MessageBox.Show(DateTime.Now.ToString("HH:mm:ss  ") + textBox_Address.Text + " 连接成功!");
                    //RichBoxShowMessage(DateTime.Now.ToString("HH:mm:ss  ") + textBox_Address.Text + " 连接成功!");


                    th2 = new Thread(Receive);
                    th2.IsBackground = true;
                    th2.Start(socket);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void Receive(object sk)
        {
            socket = sk as Socket;
            try
            {
                while (true)
                {
                    if (SFlag && !CFlag)
                    {
                        byte[] receiveData = new byte[1024];
                        int len = socket.Receive(receiveData);      //阻塞

                        if (len > 0)
                        {
                            string recevieStr = Encoding.UTF8.GetString(receiveData);
                            if (recevieStr == "*close*")
                            {

                                RichBoxShowMessage(DateTime.Now.ToString("HH:mm:ss  ") + "客户端已退出");

                                CFlag = true;
                                break;
                            }
                            RichBoxShowMessage(DateTime.Now.ToString("HH:mm:ss  ") + "接收： " + recevieStr);
                        }
                        else
                        {
                            break;
                        }
                    }

                }

            }
           /* catch(System.Net.Sockets.SocketException e)
            { 
                
            }*/
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void button_Send_Click(object sender, RoutedEventArgs e)
        {
            if (SFlag && !CFlag)
            {
                byte[] send = new byte[1024];
                send = Encoding.UTF8.GetBytes(textBox_Send.Text);
                socket.Send(send);

                RichBoxShowMessage(DateTime.Now.ToString("HH:mm:ss  ") + "发送： " + textBox_Send.Text);
                textBox_Send.Clear();

            }
        }

        private void button_End_Click(object sender, RoutedEventArgs e)
        {
            if (CFlag)
            {
                th2.Abort();
                socket.Close();
            }
            ServerSocket.Close();
            socketAccept.Close();
            th1.Abort();

            CFlag = false;
            SFlag = false;
            button_Start.IsEnabled = true;

            RichBoxShowMessage(DateTime.Now.ToString("HH:mm:ss  ") + "服务器已关闭！ " + "\n");

        }

        private void textBox_Send_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                this.button_Send_Click(sender, e);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            //执行新线程时跨线程资源访问检查会提示报错，所以这里关闭检测
        }

        void RichBoxShowMessage(string message)
        {
            Task.Run(() =>
            {
                //this.richTextBox_Show.Dispatcher.BeginInvoke(new Action(() =>
                this.Dispatcher.BeginInvoke(new Action(() =>
                {
                    richTextBox_Show.AppendText(message + "\n");
                }), System.Windows.Threading.DispatcherPriority.ApplicationIdle);
            });
        }
    }
}
