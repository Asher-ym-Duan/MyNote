﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SocketStudy
{
    public interface ISend
    {
        int Send(string content);
    }
}
