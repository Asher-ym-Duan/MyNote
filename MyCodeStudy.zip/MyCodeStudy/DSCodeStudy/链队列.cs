﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSCodeStudy
{
    class 链队列 : IRun
    {
        public void Run()
        {
            //使用自定义队列
            LinkQueue<string> queue1 = new LinkQueue<string>();

            Console.WriteLine($"The queue length is: { queue1.Count}");

            queue1.Enqueue("Foxconn");
            queue1.Enqueue("Huawei");
            Console.WriteLine($"After enqueue,The queue length is: { queue1.Count}");
            Console.WriteLine();

            string temp = queue1.Peek();
            Console.WriteLine($"After peek,The queue length is: { queue1.Count}");
            Console.WriteLine($"The peek value is: { temp}");
            Console.WriteLine();

            temp = queue1.Dequeue();
            Console.WriteLine($"After dequeue,The queue length is: { queue1.Count}");
            Console.WriteLine($"The dequeue value is: { temp}");
            Console.WriteLine();

            temp = queue1.Dequeue();
            Console.WriteLine($"After dequeue,The queue length is: { queue1.Count}");
            Console.WriteLine($"The dequeue value is: { temp}");
            Console.WriteLine();

            temp = queue1.Dequeue();
            Console.WriteLine($"After dequeue,The queue length is: { queue1.Count}");
            Console.WriteLine($"The dequeue value is: { temp}");
            Console.WriteLine();
            Console.ReadKey();

        }
    }

    class LinkQueue<T> : IQueue<T>
    {
        private Node<T> front;  //头结点
        private Node<T> rear;   //尾节点
        private int count;  //链队列元素个数

        public LinkQueue()
        {
            front = null;
            rear = null;
            count = 0;
        }

        public int Count { get { return count; } }

        public void Clear()
        {
            count=0;
            front = null;
            rear = null;
        }

        public T Dequeue()
        {
            Node<T> temp;
            if (count==0)
            {
                Console.WriteLine("The queue is Empty,Cannot dequeue!");
                return default(T);
            }
            if (count==1)
            {
                temp = rear;
                rear = null;
                front = null;
                count=0;
                return temp.Data;
            }
            else
            {
                temp = front;
                while (temp.Next.Next != null)
                {
                    temp = temp.Next;
                }
                rear = temp;
                count--;
                return temp.Next.Data;
            }
                   
        }

        public void Enqueue(T item)
        {
            Node<T> newNode = new Node<T>(item);
            if (count==0)
            {
                front = newNode;
                rear = newNode;
                count = 1;
            }
            else
            {
                rear.Next = newNode;    
                rear = newNode;     //引用类型的赋值只传递引用地址
                count++;
            }

        }

        public bool IsEmpty()
        {
            return count==0?true:false;
        }

        public T Peek()
        {
            if (count>0)
            {
                return front.Data;
            }
            else
            {
                Console.WriteLine("The queue is Empty,Cannot peek!");
                return default(T);
            }
        }
    }
}
