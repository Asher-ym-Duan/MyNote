﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace DSCodeStudy
{
    class 队列 : IRun
    {
        public void Run()
        {
            //BasicQueueDS();
            MySeqQueueDS();
        }

        /// <summary>
        /// 自定义的的循环队列学习
        /// </summary>
        public void MySeqQueueDS()
        {
            //使用自定义队列         
            SeqQueue<int> queue1 = new SeqQueue<int>(5);

            //入队
            queue1.Enqueue(20);
            queue1.Enqueue(23);
            queue1.Enqueue(01);
            queue1.Enqueue(06);
            foreach (var item in queue1)
            {
                Console.WriteLine($"队列数据：{item.ToString()}");
            }
            Console.WriteLine($"队列的大小为：{queue1.Count}");

            //获取队列中的元素
            int i = queue1.Peek();
            Console.WriteLine($"Peek得到的结果： {i}");
            Console.WriteLine($"Peek队列大小为： {queue1.Count}");

            int j = queue1.Dequeue();
            Console.WriteLine($"取得队首的数据为： {j}");
            Console.WriteLine($"出队之后，队列的大小为： {queue1.Count}");
            foreach (var item in queue1)
            {
                Console.WriteLine($"队列数据：{item.ToString()}");
            }


            //检测SeqQueue的接口IEnumerable<T>和IEnumerator<T>是否实现
            Console.WriteLine("---------------------");
            queue1.Enqueue(123);
            Console.WriteLine($"123入队，队列的大小为：{queue1.Count}");
            foreach (var item in queue1)
            {
                Console.WriteLine($"队列数据：{item.ToString()}");
            }

            queue1.Enqueue(456);
            Console.WriteLine($"456入队，队列的大小为：{queue1.Count}");
            foreach (var item in queue1)
            {
                Console.WriteLine($"队列数据：{item.ToString()}");
            }

            queue1.Dequeue();
            Console.WriteLine($"出队，队列的大小为：{queue1.Count}");
            foreach (var item in queue1)
            {
                Console.WriteLine($"队列数据：{item.ToString()}");
            }

            queue1.Enqueue(789);
            Console.WriteLine($"789入队，队列的大小为：{queue1.Count}");
            foreach (var item in queue1)
            {
                Console.WriteLine($"队列数据：{item.ToString()}");
            }

            queue1.Enqueue(20230106);
            Console.WriteLine($"队列的大小为：{queue1.Count}");
            foreach (var item in queue1)
            {
                Console.WriteLine($"队列数据：{item.ToString()}");
            }

            queue1.Dequeue();
            Console.WriteLine($"出队，队列的大小为：{queue1.Count}");
            queue1.Dequeue();
            Console.WriteLine($"出队，队列的大小为：{queue1.Count}");
            queue1.Dequeue();
            Console.WriteLine($"出队，队列的大小为：{queue1.Count}");
            queue1.Dequeue();
            Console.WriteLine($"出队，队列的大小为：{queue1.Count}");
            queue1.Dequeue();
            Console.WriteLine($"出队，队列的大小为：{queue1.Count}");
            foreach (var item in queue1)
            {
                Console.WriteLine($"队列数据：{item.ToString()}");
            }
        }

        /// <summary>
        /// BCL中的队列学习
        /// </summary>
        public void BasicQueueDS()
        {
            //使用BCL中的队列
            Queue<int> queue1 = new Queue<int>();
            //入队
            queue1.Enqueue(20);
            queue1.Enqueue(23);
            queue1.Enqueue(01);
            queue1.Enqueue(06);
            for (int i = 0; i < queue1.Count; i++)
            {

            }
            foreach (var item in queue1)
            {
                Console.WriteLine($"队列数据：{item.ToString()}");
            }
            Console.WriteLine($"队列的大小为：{queue1.Count}");
            //获取队列中的元素
            int m = queue1.Peek();
            Console.WriteLine($"Peek得到的结果： {m}");
            Console.WriteLine($"Peek队列大小为： {queue1.Count}");

            int n = queue1.Dequeue();
            Console.WriteLine($"取得队首的数据为： {n}");
            Console.WriteLine($"出队之后，队列的大小为： {queue1.Count}");
        }
    }

    class SeqQueue<T> : IQueue<T>, IEnumerator<T>, IEnumerable<T>
    {
        private T[] data;
        private int count;
        private int front;  //队首(队首元素索引-1)
        private int rear;  //队尾(队尾元素索引)
        private int position;   //用于实现IEnumerator<T>
        public SeqQueue(int size)
        {
            data = new T[size];
            count = 0;
            front = rear = -1;
        }
        public SeqQueue() : this(10)
        {

        }
        public int Count { get { return count; } }

        /// <summary>
        /// For Implement the interface:IEnumerator<T>
        /// </summary>
        public T Current
        {
            get
            {
                return data[position];
            }
        }

        object IEnumerator.Current => throw new NotImplementedException();

        public void Clear()
        {
            count = 0;
            front = rear = -1;
        }


        public T Dequeue()
        {
            if (count <= 0)//队列为空时，无法出队
            {
                Console.WriteLine("队列数据为空，无法出队！");
                return default(T);
            }
            else
            {
                T temp = data[front + 1];
                //当队首元素是数组最后一个元素时时，初始化front值
                if (front == data.Length - 2)
                {
                    front = -1;
                }
                else
                {
                    //正常情况，入队一次，front往后++
                    front++;
                }
                //每入队一次，初始化position为队首元素的索引
                position = front + 1;
                count--;
                return temp;
            }
        }

        /// <summary>
        /// 循环队列，数组数据仅覆盖，不删除
        /// </summary>
        /// <returns></returns>
        public void Enqueue(T item)
        {
            if (count == data.Length)
            {
                Console.WriteLine($"队列已满，{item.ToString()} 无法入队！");
            }
            else
            {
                //队尾元素是数组最后一个元素时，入队时定义队尾元素为0
                if (rear == data.Length - 1)
                {
                    data[0] = item;
                    rear = 0;
                }
                else
                {
                    //正常情况每入队一个元素，rear++
                    data[rear + 1] = item;
                    rear++;
                }
                count++;
            }
        }

        public bool IsEmpty()
        {
            return (count == 0) ? true : false;
        }

        public T Peek()
        {
            if (count <= 0)
            {
                Console.WriteLine("队列数据为空，无法取得队首元素！");
                return default(T);
            }
            else
            {
                T temp = data[front + 1];
                return temp;
            }
        }

        /// <summary>
        /// For Implement the interface:IEnumerator<T>
        /// </summary>
        public bool MoveNext()
        {
            //position等于队尾元素索引时，无法向后移动
            if (position == rear)
            {
                return false;
            }
            //position等于数组最后一个元素，且不等于队尾元素时，下一个元素为数组第一个元素
            if (position == data.Length - 1)
            {
                position = 0;
                return true;
            }
            else
            {
                //正常情况下，指向数组下一个元素
                position++;
                return true;
            }
        }

        /// <summary>
        /// For Implement the interface:IEnumerator<T>
        /// </summary>
        public void Reset()
        {
            //初始化position为数组第一个元素索引
            position = front + 1;
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// For Implement the interface:IEnumerable<T>
        /// </summary>
        public IEnumerator<T> GetEnumerator()
        {
            for (int i = 1; i <= count; i++)
            {
                yield return Current;
                MoveNext();
            };
            Reset();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
}
