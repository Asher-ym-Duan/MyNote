﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSCodeStudy
{
    class 栈和队列的应用 : IRun
    {
        public void Run()
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 判断一个字符串是不是回文
        /// 回文格式: 1bCDCb1 , 2XYYX2
        /// </summary>
        public void IsPalindrome(string text)
        {
            Stack<char> stack1 = new Stack<char>();
            Queue<char> queue1 = new Queue<char>();
            char[] strArr = text.ToArray();
            foreach (var item in strArr)
            {
                stack1.Push(item);
                queue1.Enqueue(item);
            }
            
        }
    }
}
