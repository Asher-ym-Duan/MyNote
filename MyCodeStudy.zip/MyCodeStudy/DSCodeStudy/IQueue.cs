﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSCodeStudy
{
    interface IQueue<T>
    {
        //队列大小
        int Count { get; }
        //队列是否为空
        bool IsEmpty();
        //清空队列
        void Clear();
        //入队
        void Enqueue(T item);
        //出队
        T Dequeue();
        //取队列首元素
        T Peek();
    }
}
