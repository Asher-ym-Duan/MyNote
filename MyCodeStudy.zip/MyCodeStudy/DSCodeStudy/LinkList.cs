﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSCodeStudy
{
    /// <summary>
    /// 单链表
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class LinkList<T> : IListDS<T>, IEnumerator<T>,IEnumerable<T>
    {
        private Node<T> head;//存储一个头结点

        int position = 0;

        /// <summary>
        /// IEnumerator<T>接口实现属性
        /// </summary>
        public T Current
        {
            get { return this[position]; }
        }

        object IEnumerator.Current => throw new NotImplementedException();

        public LinkList()
        {
            head = null;
        }

        public T this[int index]
        {
            get 
            {
                return GetEle(index);
            }
        }


        public void Add(T item)
        {
            Node<T> newNode = new Node<T>(item);//根据数据创建一个新的节点
            if (head == null)//判断头结点是否为空
            {
                head = newNode;//头结点为空时把新节点赋给头结点
            }
            else
            {
                Node<T> temp = head;//地址传递
                while (temp.Next!=null)//找出链表中最后一个节点（指针为空）
                {
                    temp = temp.Next;
                }
                temp.Next = newNode;//添加节点
            }
        }

        public void Clear()
        {
            head=null;
        }

        public T Delete(int index)
        {
            T delData=default(T);
            if (index==0)
            {
                //下標為0時，頭結點替換為下一個節點
                delData=head.Data;
                head = head.Next;
            }
            else
            {
                Node<T> temp = head;
                for (int i = 1; i <= index-1; i++)
                {
                    //找出刪除節點的前一個節點
                    temp = temp.Next;
                }
                Node<T> preNode = temp;
                delData = preNode.Next.Data;
                Node<T> nextNode = preNode.Next.Next;
                //將刪除節點前一個節點的指針指向後一個節點
                preNode.Next = nextNode;
            }
            return delData;
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public T GetEle(int index)
        { 
            Node<T> temp=head;
            for (int i = 0; i < index; i++)
            {
                temp = temp.Next;
            }
            /*int count = 0;
            while (count < index)
            {
                temp = temp.Next;
                count++;
            }*/
            return temp.Data;
        }

        public int GetLength()
        {
            Node<T> temp = head;
            int length = 1;
            if (head!=null)
            {
                while (temp.Next != null)
                {
                    temp = temp.Next;
                    length++;
                };
            }
            else
            {
                length = 0;
            }
            return length;
        }

        public void Insert(int index, T item)
        {
            Node<T> insertNode = new Node<T>(item);
            if (index==0)
            {
                insertNode.Next = head;
                head = insertNode;
            }
            else
            {
                Node<T> tempNode = head;//
                for (int i = 0; i < index - 1; i++)
                {
                    //找到插入位置的前一個節點
                    tempNode = tempNode.Next;
                }
                Node<T> preNode = tempNode;
                Node<T> NextdNode = tempNode.Next;
                //將前一個節點的指針指向插入節點
                //插入節點的指針指向需要移動的節點
                preNode.Next = insertNode;
                insertNode.Next = NextdNode;
            }
        }

        /// <summary>
        /// IEnumerator<T>接口实现方法
        /// </summary>
        /// <returns></returns>
        public bool MoveNext()
        {
            position++;
            return position > GetLength();
        }

        /// <summary>
        /// IEnumerator<T>接口实现方法
        /// </summary>
        public void Reset()
        {
            position = -1;
        }

        /// <summary>
        /// IEnumerable<T>接口实现方法
        /// </summary>
        /// <returns></returns>
        public IEnumerator<T> GetEnumerator()
        {
            List<T> list = new List<T> ();
            for (int i = 0; i < GetLength(); i++)
            {
                //yield return GetEle(i);
                list.Add(GetEle(i));
            }
            return (IEnumerator<T>)list;
        }

        /// <summary>
        /// IEnumerable<T>接口实现方法
        /// </summary>
        /// <returns></returns>
        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
}
