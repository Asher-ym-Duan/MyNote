﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSCodeStudy
{
    class Node<T>
    {
        private T data;
        private Node<T> next;

        public Node()
        {
            this.data = default(T);
            this.next = null;
        }
        public Node(T value)
        {
            this.data = value;
            this.next = null;
        }
        public Node(Node<T> next)
        {
            this.next = next;
            //this.data = default(T);
        }
        public Node(T value,Node<T> next) 
        {
            this.next = next;
            this.data = value;
        }

        public T Data 
        { 
            set{this.data=value;}
            get { return this.data; }
        }
        public Node<T> Next 
        {
            set { this.next = value; }
            get { return this.next; }
        }
    }
}
