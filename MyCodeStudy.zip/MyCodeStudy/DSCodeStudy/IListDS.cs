﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSCodeStudy
{
    public interface IListDS<T>
    {
        void Add(T item);
        void Insert(int index,T item);
        T Delete(int index);
        T GetEle(int index);
        void Clear();
        int GetLength();
        /// <summary>
        /// 通过索引器获取元素
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        T this[int index] { get; }
    }
}
