﻿using System;
using System.Data;
using System.Collections;

namespace DSCodeStudy
{
    class Program
    {
        static void Main(string[] args)
        { 
            System.Text.Encoding.GetEncoding("utf-8");
            //设置console为中文编码
            Console.OutputEncoding = System.Text.Encoding.GetEncoding("utf-8");

            //接口执行程序
            /*IRun program = new 链队列();
            program.Run();
            Console.ReadKey();*/



            //测试时间复杂度
            //TestTimeComplexity()
            //测试自定义的单链表
            TestMyLinkList();
            //TestBCLStack();
        }
        public static void TestTimeComplexity()
        {
            //O(n)
            DateTime startTime1 = DateTime.Now;
            TimeN(100);
            DateTime endTime1 = DateTime.Now;

            //O(n^2)
            DateTime startTime2 = DateTime.Now;
            for (int i = 0; i < 100; i++)
            {
                TimeN(100);
            }
            DateTime endTime2 = DateTime.Now;

            Console.WriteLine($"CostTime:{endTime1.Subtract(startTime1)}ms");
            Console.WriteLine($"CostTime:{endTime2.Subtract(startTime2)}ms");
            Console.ReadKey();
        }
        public static void TimeN(int count)
        {
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine("TimeN");
            }
        }

        public static void TestMyLinkList()
        {
            LinkList<string> linkList = new LinkList<string>();
            Console.WriteLine("Length1: " + linkList.GetLength());
            linkList.Add("123");
            linkList.Add("456");
            linkList.Add("789");
            Console.WriteLine("Length2: " + linkList.GetLength());
            linkList.Insert(2, "ABC");
            Console.WriteLine("Length3: " + linkList.GetLength());
            foreach (var item in linkList)
            {
                Console.WriteLine("value: " + item);
            }
            Console.Read();
        }

        public static void TestBCLStack()
        {
            
            //new 一个空栈
            Stack stack = new Stack();
            //往栈中压入元素
            stack.Push("abadon");
            stack.Push('a');
            stack.Push(1);
            Console.WriteLine("1.stack中的元素个数:"+stack.Count);
            //弹出栈顶元素并获取该元素
            object temp = stack.Pop();
            Console.WriteLine("stack中pop的数据:"+temp.ToString());
            Console.WriteLine("2.stack中的元素个数:"+stack.Count);
            //获取栈顶元素但不弹出
            temp = stack.Peek();
            Console.WriteLine("stack中peek的数据:" + temp.ToString());
            Console.WriteLine("3.stack中的元素个数:" + stack.Count);
            //清空栈
            stack.Clear();
            Console.WriteLine("4.stack中的元素个数:"+stack.Count);
            Console.ReadKey();
        }

        public void TestTemporaryVariable()
        {
            Node<string> node1 = new Node<string>("GOOD");
            Node<string> node2 = new Node<string>("BAD");
            Node<string> node3 = new Node<string>("WELL");
            Node<string> node4 = new Node<string>("TERRIABLE");
            node1.Next = node2;
            node2.Next = node3;
            Node<string> front = node1;
            Node<string> rear = node3;
            rear.Next = node4;
            rear = node4;
            Console.WriteLine($"node3.data={node3.Data}---node3.next={node3.Next.Data}");
            Console.WriteLine($"node4.data={node4.Data}---node4.next={node4.Next.Data}");
            Console.WriteLine($"rear.data={rear.Data}---rear.next={rear.Next.Data}");
            Console.ReadKey();
        }
    }
}
