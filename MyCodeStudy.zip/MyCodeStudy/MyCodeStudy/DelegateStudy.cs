﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MyCodeStudy
{
    /// <summary>
    /// 学习委托的使用方法
    /// </summary>
    internal class DelegateStudy : IRunning
    {
        //疑问1：如何使用委托的异步调用？

        //疑问2：为何线程池创建线程比Start()要快?

        public void Run()
        {

            //1.无参数无返回值的委托
            NoReturnNoParaCallback NoRetuNoPara = new NoReturnNoParaCallback(PrintFixedText); //委托实例化并绑定方法
            NoRetuNoPara += PrintFixedText; //委托多播:一个委托对象按顺序绑定方法
            NoRetuNoPara -= PrintFixedText; //委托多播:一个委托对象按顺序解除绑定方法
            NoRetuNoPara(); //使用委托对象调用方法
            //该线程用于测试委托的阻塞调用方法Invoke()
            /*Thread thread = new Thread(new ThreadStart(() =>
            {
                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine("(ThreadStart) loop time: " + i);
                }
            }));
            thread.Start();*/
            //使用线程池创建线程
            //测试发现线程创建的时间：线程池 < Start()
            ThreadPool.QueueUserWorkItem((m) =>
            {
                for (int i = 0; i < (int)m; i++)
                {
                    Console.WriteLine("(ThreadPool) loop time: " + i);
                }
            }, 5);
            //利用循环占用时间，用于测试线程启动时是否具有延时性
            for (int i = 0; i < 30; i++)
            {
                Console.WriteLine("-----------------"+i+"-----------------");
            }    
            //Thread.Sleep(1000);
            //NoRetuNoPara.Invoke();  //委托对象的同步调用：也可以成为阻塞调用，它将阻塞当前线程，然后执行调用，调用完毕后在向下执行
            //NoRetuNoPara.BeginInvoke();   //委托对象的异步调用：？？？


            //2.有参数无返回值的委托
            NoReturnWithParaCallback noRetuWithPara=new NoReturnWithParaCallback(PrintInputText);
            noRetuWithPara("Asher");
            //NoRetuWithPara.Invoke("Asher");



            //3.有参数有返回值的委托
            //创建一个职工对象的集合
            List<Employee> Employees = new List<Employee>();
            Employees.Add(new Employee("Asher", "F7692596"));
            Employees.Add(new Employee("Ann", "F7692820"));
            Employees.Add(new Employee("Aiden", "F7691188"));
            ReturnWithParaCallback retuWithPara = new ReturnWithParaCallback(GetSpecificJobNumber);
            Console.WriteLine("Return with Paratemer: "+retuWithPara(Employees, "Asher"));  //打印获取到的工号


            //4.无参数有返回值的委托
            ReturnWithNoParaCallback retuWithNoPara = new ReturnWithNoParaCallback(TestReturnWithoutPara);
            string[] names=retuWithNoPara();
            foreach (string name in names)
            {
                Console.WriteLine("Return with no Paratemer: "+"name: " +name);
            }


            Console.WriteLine("========================================================================");
            //5.Action创建委托时，绑定的方法不能有返回值
            Action<string> action = PrintInputText;
            action("Ann");


            //6.Func创建委托时，绑定的方法必须要有返回值，创建时最后一个参数为返回值类型
            Func<List<Employee>,string,string> func = GetSpecificJobNumber;
            Console.WriteLine("Func Creat delegete: "+"jobNumber:"+func(Employees,"Aiden"));


            //7.Predicate可以綁定返回值為bool類型的方法
            Predicate<int> predicate = (i) => i > 50;
            bool flag = predicate(60);
            Console.WriteLine(flag);

            Console.ReadKey();
        }

        public delegate void NoReturnNoParaCallback();
        public delegate void NoReturnWithParaCallback(string name);
        public delegate string ReturnWithParaCallback(List<Employee> Employees,string name);
        public delegate string[] ReturnWithNoParaCallback();

        /// <summary>
        /// 打印固定文本，用于测试无参数无返回值的委托
        /// </summary>
        public void PrintFixedText()
        {
            Console.WriteLine("This is a method without parameter and return");
        }

        /// <summary>
        /// 打印输入文本，用于测试有参数无返回值的委托
        /// </summary>
        /// <param name="name"></param>
        public void PrintInputText(string name)
        { 
            Console.WriteLine("Input name is :"+name);
        }

        /// <summary>
        /// 打印指定职工的工号,用于测试有参数有返回值的委托
        /// </summary>
        /// <param name="Employees"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        public string GetSpecificJobNumber(List<Employee> Employees,string name)
        {
            foreach (var Employee in Employees)
            {
                if (Employee.name!=null && Employee.name.Equals(name))
                {
                    return Employee.jobNumber;
                }
            }
            return null;
        }

        /// <summary>
        /// 返回一个字符串数组，用于测试无参数有返回值的委托
        /// </summary>
        /// <returns></returns>
        public string[] TestReturnWithoutPara()
        {
            string[] result = { "Asher", "Ann", "Aiden", "Nick", "Erica", "Felix" };
            return result;
        }
    }
}
