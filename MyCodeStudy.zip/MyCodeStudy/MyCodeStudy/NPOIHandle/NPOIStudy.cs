﻿using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using NPOI.XSSF.UserModel;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

namespace MyCodeStudy
{
    class NPOIStudy : IRunning
    {
        const string WPSPATH = @"C:\Users\F7692596\AppData\Local\Kingsoft\WPS Office\ksolaunch.exe";

        public static string errorMessage;

        public object StringBuffer { get; private set; }

        public void Run()
        {
            string outDir = @"D:\CodeStudy\FileHandle\";
            string currDir = Directory.GetCurrentDirectory() + @"\tempFile\";
            string outPath = outDir + "貨物清單.xlsx";
            string currPath = currDir + @"\tempFile\貨物清單.xlsx";
            #region 測試DateTime的轉換
            /*DateTime dateTime;
            DateTime.TryParse("2022/02/06",out dateTime);
            Console.WriteLine(dateTime+"\t"+dateTime.ToString());
            DateTime.TryParse("2022-05-03",out dateTime);
            Console.WriteLine(dateTime+"\t"+dateTime.ToString());
            DateTime.TryParse("2022年7月2日",out dateTime);
            Console.WriteLine(dateTime+"\t"+dateTime.ToString());*/
            #endregion

            int count = 1;
            while (count > 0)
            {
                count--;
                //CreatExcelFile("D:\\NPOI_Creat.xlsx");
                CreatCellStyle("D:\\NPOI_StyleSetting.xlsx");
                //CreatCellStyle(currDir+"单元格格式.xlsx");
                //FormulaSettings(currDir + "公式設置.xlsx");
                //MergeCells(currDir+"合併單元格.xlsx");
                //ReadExcel(outPath);
                //CreatCellStyle(outPath);
                //CreatFileByTxt(currPath);
                //Console.WriteLine(Path.GetTempPath());
                //Console.ReadKey();
            }
        }


        public void CreatExcelFile(string fileName)
        {
            /*
            在NPOI中，IRow和ICell是表格結構的基本元素，必須先通過Create函數創建後才能使用，不然會報錯
            是否有單元格和單元格裡是否有值，這是分開保存的，設置單元格內容補習要先創建單元格
            (單元格内容不爲空)單元格的設置順序為：
                1.設置第一行，再設置第一行的所有單元格（第一列，第二列，……）
                 2.設置第二行，再設置第二行的所有單元格（第一列，第二列，……）
                 3.……
            */
            //HSSFWorkbook 和XSSFWorkbook繼承接口IWrokbook
            //創建一個工作簿
            IWorkbook book = new XSSFWorkbook();
            //創建一個工作表
            ISheet sheet = book.CreateSheet("sheet1");
            //在第一行創建行
            IRow row = sheet.CreateRow(0);
            //在第一行的第一列創建單元格
            ICell cell = row.CreateCell(0);
            //給單元格賦值
            cell.SetCellValue("This is A1");
            //創建文件流
            FileStream fileStream = new FileStream(@"D:\NPOI_Creat.xlsx", FileMode.OpenOrCreate);
            //將工作簿寫入文件流
            book.Write(fileStream);
            //釋放资源
            fileStream.Close();
            book.Close();
        }

        public void ReadExcel(string filePath)
        {
            IWorkbook book = null;
            string extensionName = Path.GetExtension(filePath);
            try
            {
                book = SetWorkbookObject(filePath);
                //FileStream fileStream = new FileStream(path, FileMode.Open);
                book.GetSheetAt(0).GetRow(0).GetCell(0).SetCellValue("Read This workbook");
                using (FileStream stream = new FileStream(filePath, FileMode.Open, FileAccess.ReadWrite))
                {
                    book.Write(stream);
                    stream.Close();
                    book.Close();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public void CreatCellStyle(string filePath)
        {
            //filestream.Position = 0;
            IWorkbook book1 = null;
            FileStream fileStream = null;
            try
            {
                string extensionName = Path.GetExtension(filePath);
                book1 = SetWorkbookObject(filePath);
                if (book1 == null) return;
                //如果原xlsx表格內容為空，需要使用creat創建內容
                //手動新建的空白xlsx表格默認有三個工作表“sheet1”，“sheet2”，“sheet3”，但是沒有行和單元格
                if (book1.GetSheet("Sheet1") != null)
                {
                    int index = book1.GetSheetIndex("Sheet1");
                    book1.RemoveSheetAt(index);
                }
                ISheet sheet1 = book1.CreateSheet("Sheet1");
                ICell cell1 = GetCell(sheet1, 0, 0);
                cell1.SetCellValue("設置單元格樣式");
                ICellStyle cellStyle1 = book1.CreateCellStyle();

                //背景颜色设置
                if (false)
                {
                    //創建一個單元格樣式對象
                    //設置單元格填充圖案為纯色
                    cellStyle1.FillPattern = FillPattern.SolidForeground;
                    //cellStyle1.FillPattern = FillPattern.FineDots;
                    //設置單元格背景顏色為黃色（設置屬性 FillPattern 后生效）
                    cellStyle1.FillBackgroundColor = NPOI.HSSF.Util.HSSFColor.Yellow.Index;
                    //設置單元格填充圖案顔色為紅色（設置屬性 FillPattern 后生效）
                    cellStyle1.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.Red.Index;
                    //設置單元格對齊方式為右对齐
                    cellStyle1.Alignment = HorizontalAlignment.Right;
                    //將样式對象赋给单元格對象
                    cell1.CellStyle = cellStyle1;
                }


                //字体设置
                if (false)
                {
                    //創建字體對象
                    IFont font1 = book1.CreateFont();
                    //設置字體名稱
                    font1.FontName = "宋體";
                    //設置字體大小
                    font1.FontHeightInPoints = 15;
                    //設置粗體
                    font1.IsBold = true;
                    //設置字體顔色
                    font1.Color = NPOI.HSSF.Util.HSSFColor.Black.Index;
                    //設置單下劃綫
                    font1.Underline = FontUnderlineType.Single;
                    //font1.IsStrikeout = true;  //設置刪除線
                    //font1.TypeOffset = FontSuperScript.Super;    //設置上標
                    //将设置好的字体對象賦給樣式對象
                    cellStyle1.SetFont(font1);
                    //設置單元格水平對齊方式為居中
                    cellStyle1.Alignment = HorizontalAlignment.Center;
                    //設置單元格垂直對齊方式為居中
                    cellStyle1.VerticalAlignment = VerticalAlignment.Center;
                    //將样式對象赋给单元格對象
                    cell1.CellStyle = cellStyle1;
                }

                // 图示各种填充图案
                if (false)
                {
                    Type type = typeof(FillPattern);
                    string[] filltypes = type.GetEnumNames();
                    Array array = type.GetEnumValues();
                    int count = 6;
                    //这里需要每次循环都创建一次ICellStyle,如果仅修改FillPattern属性,所有的单元格都是同一种图案
                    /*ICellStyle fillStyle = book.CreateCellStyle();
                    fillStyle.FillBackgroundColor = NPOI.HSSF.Util.HSSFColor.Green.Index;*/
                    foreach (FillPattern item in array)
                    {
                        //FillBackgroundColor是背景色，不设置的话默认是白色
                        //FillForegroundColor是图案颜色，不设置的话默认是黑色
                        //FillPattern是设置背景色或图案颜色的必要项目，当未设置FillForegroundColor时，SolidForeground的默认颜色是白色
                        ICellStyle fillStyle = book1.CreateCellStyle();
                        fillStyle.FillBackgroundColor = NPOI.HSSF.Util.HSSFColor.Red.Index;
                        fillStyle.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.Yellow.Index;
                        fillStyle.FillPattern = item;
                        GetCell(sheet1, count, 2).SetCellValue(item.ToString());
                        GetCell(sheet1, count, 3).CellStyle = fillStyle;
                        count++;
                    }
                }


                //行号和列宽设置
                if (false)
                {
                    //單元格基本屬性設置
                    /*int[] widthArr = new int[20];
                    for (int i = 0; i < 20; i++)
                    {
                        string value = "012345678901234567890123456789";
                        GetCell(sheet, 0, i).SetCellValue(value.Substring(0,i+1));
                        sheet1.SetColumnWidth(i,(i+1)*256);
                        widthArr[i]= sheet.GetColumnWidth(i);
                    }*/
                    //设置单元格内容，自定义方法GetCell()
                    GetCell(sheet1, 0, 0).SetCellValue("0");
                    GetCell(sheet1, 0, 1).SetCellValue("0123");
                    GetCell(sheet1, 0, 2).SetCellValue("0123456789");
                    GetCell(sheet1, 0, 3).SetCellValue("0123456789");
                    sheet1.CreateRow(1);
                    //设置行高
                    //HeightInPoints的单位是磅，而Height的单位是1 / 20磅
                    sheet1.GetRow(0).HeightInPoints = 20;
                    sheet1.GetRow(1).Height = 40 * 20;
                    //设置列宽
                    //列寬單位是1/256字符，列的下标也是从0开始
                    sheet1.SetColumnWidth(0, 1 * 256);
                    sheet1.SetColumnWidth(1, 4 * 256);
                    sheet1.SetColumnWidth(2, 10 * 256);
                    //設置自動列寬
                    sheet1.AutoSizeColumn(3);
                    //設置工作表默認長度和寬度
                    //sheet1.DefaultColumnWidth = 100 * 256;
                    //sheet1.DefaultRowHeight = 30 * 20;
                }

                //單元格合併
                if (true)
                {
                    string[] abcArr = {"A","B","C","D","E","F","G","H","I","J" };
                    for (int i = 0; i < 10; i++)
                    {
                        for (int j = 0; j < 10; j++)
                        {
                            //string tempStr1 = GetCell(sheet1, i, j).ToString();
                            //if (String.IsNullOrEmpty(tempStr1))
                            GetCell(sheet1, i, j).SetCellValue($"{abcArr[j]}{i+1}");
                        }
                    }

                    //設置A1格式為水平、垂直居中
                    ICellStyle cellstyleMergerd = book1.CreateCellStyle();
                    cellstyleMergerd.Alignment = HorizontalAlignment.Center;
                    cellstyleMergerd.VerticalAlignment = VerticalAlignment.Center;
                    GetCell(sheet1, 0, 0).CellStyle = cellstyleMergerd;

                    //合併單元格區域
                    CellRangeAddress cellRange1 = new CellRangeAddress(0, 1, 0, 1);
                    //檢查該範圍單元格是否是已合并单元格的一部分
                    if (!sheet1.IsMergedRegion(cellRange1))     
                        sheet1.AddMergedRegion(cellRange1);
                    sheet1.AddMergedRegion(new CellRangeAddress(2, 3, 2, 3));
                    sheet1.AddMergedRegion(new CellRangeAddress(4, 5, 4, 5));
                    sheet1.AddMergedRegion(new CellRangeAddress(8, 9, 8, 9));
                    sheet1.AddMergedRegion(new CellRangeAddress(6, 7, 6, 7));


                    //合併前移除有交叉的合併單元格
                    CellRangeAddress cellrange2 = new CellRangeAddress(2, 3, 2, 3);
                    //獲取工作表sheet1的所有合併單元格
                    /*   List<CellRangeAddress> cellRanges1 = sheet1.MergedRegions;
                       for (int i = 0; i < cellRanges1.Count; i++)
                       {
                           bool isCoincide1 = cellrange2.MinColumn <= cellRanges1[i].MaxColumn && cellrange2.MinRow <= cellRanges1[i].MaxRow;
                           bool isCoincide2 = cellrange2.MaxColumn >= cellRanges1[i].MinColumn && cellrange2.MaxRow <= cellRanges1[i].MinRow;
                           if (isCoincide1 || isCoincide2)
                           {
                               //移除工作表sheet1中下標為i的合併單元格
                               sheet1.RemoveMergedRegion(i);
                           }
                       }
                       sheet1.AddMergedRegion(cellrange2);*/

                    //合併單元格常用方法
                    List<CellRangeAddress> getAllMergedRegions = sheet1.MergedRegions;   //獲取所有的合併單元格區域
                    List<int> list1 = new List<int>();
                    list1.Add(1);
                    list1.Add(3);
                    //sheet1.RemoveMergedRegions(list1);
                    //sheet1.RemoveMergedRegion(2);
                    sheet1.ValidateMergedRegions();

                }


                //手動創建的xlsx文件經過代碼修改後需要再新建一個文件覆蓋掉源文件，這樣就不會有文件打不開的情況
                //fileStream = File.Create(filePath);
                //fileStream = new FileStream(filePath,FileMode.Open,FileAccess.Read);
                fileStream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                book1.Write(fileStream);
                book1.Close();
                fileStream.Close();
             }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            if (File.Exists(filePath))
            {
                StartFile(WPSPATH, filePath);
                //OpenExcelFile(filePath);
            }
            //WinExec(filePath,1);
            //File.Open 不可用
            //File.Open(filePath,FileMode.Open);
            //Process.Start()不可用
            //System.Diagnostics.Process.Start("D://NPOI_StyleSetting.xlsx");
            //System.Diagnostics.Process.Start(filePath);

        }

        /// <summary>
        /// 合併單元格
        /// </summary>
        /// <param name="filePath"></param>
        public void MergeCells(string filePath)
        {
            IWorkbook book = null;
            try
            {
                book = SetWorkbookObject(filePath);
                ISheet sheet = book.GetSheetAt(0);

                //設置選中單元格
                //System.NotImplementedException: 'The method or operation is not implemented.'
                //sheet.SetActiveCellRange(1, 1, 0, 3);

                #region 獲取範圍單元格
                Func<ISheet, int, int, int, int, List<ICell>> getCellRangeFunc = (sheetFunc, rowStart, rowEnd, columnStart, columnEnd) =>
                {
                    List<ICell> temp = new List<ICell>();
                    for (int i = rowStart; i <= rowEnd; i++)
                    {
                        for (int j = columnStart; j <= columnEnd; j++)
                        {
                            IRow row = sheetFunc.GetRow(i);
                            if (row == null) sheetFunc.CreateRow(i);
                            ICell cell = row.GetCell(j);
                            if (cell == null) row.CreateCell(j);
                            temp.Add(cell);
                            Console.WriteLine(i + "  " + j);
                        }
                    }
                    return temp;
                };
                List<ICell> listCells = getCellRangeFunc(sheet, 0, 4, 0, 4);
                ICellRange<ICell> cellRange = SSCellRange<ICell>.Create(0, 0, 5, 5, listCells, typeof(XSSFCell));
                #endregion

                //合併單元格
                //sheet.AddMergedRegion(new CellRangeAddress(1,5,0,0));

                FileStream fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write);
                book.Write(fileStream);
                fileStream.Close();
                book.Close();
            }
            catch (Exception e)
            {

                throw e;
            }
        }

        /// <summary>
        /// 公式設置
        /// </summary>
        /// <param name="filePath"></param>
        public void FormulaSettings(string filePath)
        {
            IWorkbook book;
            try
            {
                CreatFileByTxt(filePath);
                book = SetWorkbookObject(filePath);
                ISheet sheet = book.GetSheetAt(0);

                //基本計算
                GetCell(sheet, 1, 4).SetCellFormula("C2*D2");
                GetCell(sheet, 2, 4).SetCellFormula("C3+D3");
                GetCell(sheet, 3, 4).SetCellFormula("C4-D4");
                GetCell(sheet, 4, 4).SetCellFormula("C5/D5");

                //SUM函數
                GetCell(sheet, 0, 5).SetCellValue("SUM函數");
                GetCell(sheet, 1, 5).SetCellFormula("sum(C2:E2)");
                GetCell(sheet, 2, 5).SetCellFormula("sum(C3,E3)");
                GetCell(sheet, 3, 5).SetCellFormula("sum(C2:E2)+sum(C3:E3)");
                //GetCell(sheet, 4, 5).SetCellFormula("sum(C4:E4)");

                //定義區域並求和
                IName range1 = book.CreateName();
                range1.RefersToFormula = $"{sheet.SheetName}!$C4:$E4";
                range1.NameName = "range1";
                GetCell(sheet, 4, 5).SetCellFormula("sum(range1)");

                //设置日期格式
                ICellStyle dateStyle = book.CreateCellStyle();
                IDataFormat dateFormat = book.CreateDataFormat();
                dateStyle.DataFormat = dateFormat.GetFormat("yyyy年m月d日");


                //日期公式
                GetCell(sheet, 0, 6).SetCellValue("日期函數");
                //DateTime time = new DateTime(2022, 7, 3);
                DateTime time = DateTime.Now;
                ICell cellG2 = GetCell(sheet, 1, 6);
                cellG2.SetCellValue(time);
                cellG2.CellStyle = dateStyle;
                /*string stringValue =cell1.StringCellValue;
                DateTime dateValue = cell1.DateCellValue;
                bool boolValue = cell1.BooleanCellValue;*/
                //日期在Excel中都是double类型
                GetCell(sheet, 2, 6).CellStyle = dateStyle;
                GetCell(sheet, 2, 6).SetCellFormula("TODAY()");
                GetCell(sheet, 3, 6).CellStyle = dateStyle;
                GetCell(sheet, 3, 6).SetCellValue("2019年10月5日");
                GetCell(sheet, 4, 6).CellStyle = dateStyle;
                GetCell(sheet, 4, 6).SetCellValue(44753);
                GetCell(sheet, 5, 6).CellStyle = dateStyle;
                GetCell(sheet, 5, 6).SetCellFormula("CONCATENATE(DATEDIF(G4,TODAY(),\"y\"),\"年\"," + "DATEDIF(G4,TODAY(),\"ym\"),\"个月\")");
                GetCell(sheet, 6, 6).CellStyle = dateStyle;
                GetCell(sheet, 6, 6).SetCellFormula("CONCATENATE(DATEDIF(G4,TODAY(),\"d\"),\"年\")");
                GetCell(sheet, 7, 6).CellStyle = dateStyle;
                GetCell(sheet, 7, 6).SetCellFormula("CONCATENATE(DATEDIF(G4,TODAY(),\"m\"),\"个月\")");









                #region 图示各种填充图案
                Type type = typeof(FillPattern);
                string[] filltypes = type.GetEnumNames();
                Array array = type.GetEnumValues();
                int count = 0;
                //这里需要每次循环都创建一次ICellStyle,如果仅修改FillPattern属性,所有的单元格都是同一种图案
                /*ICellStyle fillStyle = book.CreateCellStyle();
                fillStyle.FillBackgroundColor = NPOI.HSSF.Util.HSSFColor.Green.Index;*/
                foreach (FillPattern item in array)
                {
                    //FillBackgroundColor是背景色，不设置的话默认是白色
                    //FillForegroundColor是图案颜色，不设置的话默认是黑色
                    //FillPattern是设置背景色或图案颜色的必要项目，当未设置FillForegroundColor时，SolidForeground的默认颜色是白色
                    ICellStyle fillStyle = book.CreateCellStyle();
                    fillStyle.FillBackgroundColor = NPOI.HSSF.Util.HSSFColor.Red.Index;
                    fillStyle.FillPattern = item;
                    fillStyle.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.Yellow.Index;
                    GetCell(sheet, 11, count).SetCellValue(item.ToString());
                    GetCell(sheet, 12, count).CellStyle = fillStyle;
                    count++;
                }
                /*ICellStyle fillStyle1 = book.CreateCellStyle();
                ICellStyle fillStyle1 = book.CreateCellStyle();
                ICellStyle fillStyle1 = book.CreateCellStyle();
                ICellStyle fillStyle1 = book.CreateCellStyle();
                ICellStyle fillStyle1 = book.CreateCellStyle();
                ICellStyle fillStyle1 = book.CreateCellStyle();
                fillStyle.FillBackgroundColor = NPOI.HSSF.Util.HSSFColor.Green.Index;
                fillStyle.FillPattern = FillPattern.AltBars;    //AltBars
                GetCell(sheet,8,0).SetCellValue("AltBars");
                GetCell(sheet,9,0).CellStyle =fillStyle;
                fillStyle.FillPattern = FillPattern.BigSpots;   //BigSpots
                GetCell(sheet, 8, 1).SetCellValue("BigSpots");
                GetCell(sheet, 9, 1).CellStyle = fillStyle;
                fillStyle.FillPattern = FillPattern.Bricks;   //Bricks
                GetCell(sheet, 8, 2).SetCellValue("Bricks");
                GetCell(sheet, 9, 2).CellStyle = fillStyle;
                fillStyle.FillPattern = FillPattern.Diamonds;   //Diamonds
                GetCell(sheet, 8, 3).SetCellValue("Diamonds");
                GetCell(sheet, 9, 3).CellStyle = fillStyle;
                fillStyle.FillPattern = FillPattern.FineDots;   //FineDots
                GetCell(sheet, 8, 4).SetCellValue("FineDots");
                GetCell(sheet, 9, 4).CellStyle = fillStyle;
                fillStyle.FillPattern = FillPattern.LeastDots;   //LeastDots
                GetCell(sheet, 8, 5).SetCellValue("LeastDots");
                GetCell(sheet, 9, 5).CellStyle = fillStyle;
                fillStyle.FillPattern = FillPattern.LessDots;   //LessDots
                GetCell(sheet, 8, 6).SetCellValue("LessDots");
                GetCell(sheet, 9, 6).CellStyle = fillStyle;
                fillStyle.FillPattern = FillPattern.SolidForeground;   //SolidForeground
                GetCell(sheet, 8, 7).SetCellValue("SolidForeground");
                GetCell(sheet, 9, 7).CellStyle = fillStyle;
                fillStyle.FillPattern = FillPattern.SparseDots;   //SparseDots
                GetCell(sheet, 8, 8).SetCellValue("SparseDots");
                GetCell(sheet, 9, 8).CellStyle = fillStyle;
                fillStyle.FillPattern = FillPattern.Squares;   //Squares
                GetCell(sheet, 8, 9).SetCellValue("Squares");
                GetCell(sheet, 9, 9).CellStyle = fillStyle;
                fillStyle.FillPattern = FillPattern.ThickBackwardDiagonals;   //ThickBackwardDiagonals
                GetCell(sheet, 8, 10).SetCellValue("ThickBackwardDiagonals");
                GetCell(sheet, 9, 10).CellStyle = fillStyle;*/
                #endregion

                //设置格式-蓝色背景/白色背景
                ICellStyle styleBlue = book.CreateCellStyle();
                //styleBlue.FillBackgroundColor = NPOI.HSSF.Util.HSSFColor.Blue.Index;
                styleBlue.FillPattern = FillPattern.SolidForeground;
                styleBlue.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.BlueGrey.Index;
                ICellStyle styleWhite = book.CreateCellStyle();
                styleWhite.FillPattern = FillPattern.SolidForeground;
                styleWhite.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.White.Index;

                //获取范围单元格
                List<ICell> cells = GetCellList(sheet, 1, 1, 1, 6);
                ICellRange<ICell> cellRangeA1A6 = SSCellRange<ICell>.Create(1, 1, 1, 6, cells, typeof(XSSFCell));
                foreach (ICell item in cellRangeA1A6)
                {
                    //设置背景为蓝灰色
                    item.CellStyle = styleBlue;
                }
                List<ICell> cellsA2F5 = GetCellList(sheet, 2, 1, 4, 6);
                ICellRange<ICell> cellRangeA2F5 = SSCellRange<ICell>.Create(2, 1, 4, 6, cellsA2F5, typeof(XSSFCell));
                foreach (ICell item in cellRangeA2F5)
                {
                    item.CellStyle = styleWhite;
                }

                //給單元格賦值數字
                /*CellSetValue(GetCell(sheet, 2, 5), "123456");
                CellSetValue(GetCell(sheet, 3, 5), "2022/7/22");*/

                using (FileStream fileStream = File.Create(filePath))
                {
                    book.Write(fileStream);
                }
                book.Close();
            }
            catch (Exception e)
            {

                throw e;
            }
            Process.Start(filePath);
        }

        public IWorkbook SetWorkbookObject(string filePath)
        {
            IWorkbook book;
            FileStream fileStream;
            try
            {
                //判断文件是否存在
                if (!File.Exists(filePath))
                {
                    switch (Path.GetExtension(filePath))
                    {
                        case ".xlsx":
                            return book = new XSSFWorkbook();
                        case ".xls":
                            return book = new HSSFWorkbook();
                        default:
                            return null;
                    }
                }
                fileStream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                fileStream.Position = 0;
                string extensionName = Path.GetExtension(filePath);
                if (extensionName.Equals(".xlsx"))
                {
                    book = new XSSFWorkbook(fileStream);
                }
                else if (extensionName.Equals(".xls"))
                {
                    book = new HSSFWorkbook(fileStream);
                }
                else
                {
                    book = null;
                }
                fileStream.Close();
            }
            catch (Exception e)
            {
                throw e;
            }
            return book;
        }

        public void CreatFileByTxt(string filePath)
        {
            IWorkbook book = null;
            FileStream fileStream = null;
            try
            {
                //創建工作簿對象
                book = new XSSFWorkbook();
                ISheet sheet = book.CreateSheet("貨物清單");

                //獲取txt文本信息
                string txtPath = Directory.GetCurrentDirectory() + @"\tempFile\貨物信息.txt";
                string[,] txtContent = ReadTxt(txtPath);
                int rowLength = txtContent.GetLength(0);        //獲取行的數量
                int columnLength = txtContent.GetLength(1);     //獲取列的數量

                //創建Header
                IRow row = sheet.CreateRow(0);
                row.CreateCell(0).SetCellValue("ID");
                row.CreateCell(1).SetCellValue("貨物名稱");
                row.CreateCell(2).SetCellValue("貨物數量");
                row.CreateCell(3).SetCellValue("貨物單價");
                row.CreateCell(4).SetCellValue("貨物總價");

                //創建4*5的單元格對象,並將內容寫入單元格內
                for (int i = 1; i < rowLength; i++)
                {
                    sheet.CreateRow(i);
                    for (int j = 0; j < columnLength; j++)
                    {
                        CellSetValue(GetCell(sheet, i, j), txtContent[i, j]);
                        //sheet.GetRow(i).CreateCell(j).SetCellValue(txtContent[i, j]);
                    }
                }

                //創建不同類型的style
                //創建頭部style
                ICellStyle styleTop = book.CreateCellStyle();
                IFont fontTop = book.CreateFont();
                fontTop.FontName = "微軟雅黑";
                fontTop.Color = NPOI.HSSF.Util.HSSFColor.Black.Index;
                fontTop.IsBold = true;
                styleTop.SetFont(fontTop);
                //設置選中區域
                //sheet.SetActiveCellRange(0,0,0,4);
                //設置範圍單元格


                //創建文件並將工作簿保存寫入
                fileStream = new FileStream(filePath, FileMode.Create, FileAccess.ReadWrite);
                book.Write(fileStream);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                fileStream.Close();
                book.Close();
            }
        }

        public string[,] ReadTxt(string filePath)
        {
            //二維數組為空可以嗎？
            StreamReader sr = null;
            List<string> lineContent;
            string[,] array = null;
            //StringBuilder stringBuilder;
            try
            {
                lineContent = new List<string>();
                string tempStr;
                sr = new StreamReader(filePath);
                while ((tempStr = sr.ReadLine()) != null)
                {
                    lineContent.Add(tempStr);
                }
                //獲取文本的行數和列數（默認是陣列）,行需要多加一行用來存儲表頭信息
                int rowNum = lineContent.Count + 1;
                int columnNum = lineContent[0].Split(",").Length;
                //將二維數組第一行設置為表頭數據
                array = new string[rowNum, columnNum];
                for (int i = 0; i < columnNum; i++)
                {
                    array[0, i] = lineContent[0].Split(",")[i].Split("=")[0];
                }
                //獲取文本內容，從第二行開始
                for (int i = 0; i < rowNum; i++)
                {
                    //跳出循環，防止下標越界異常
                    if (i == rowNum - 1) break;
                    string[] content = lineContent[i].Split(",");
                    for (int j = 0; j < columnNum; j++)
                    {
                        // Console.WriteLine($"i={i}, j={j}");
                        //數組從第二行開始
                        array[i + 1, j] = content[j].Split("=")[1].Replace(";", "");
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                sr.Close();
            }
            return array;
        }

        /// <summary>
        /// 獲取（含創建）工作表中指定的一個單元格
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="rowIndex"></param>
        /// <param name="columnIndex"></param>
        /// <returns></returns>
        public static ICell GetCell(ISheet sheet, int rowIndex, int columnIndex)
        {
            //非空判斷
            if (sheet.GetRow(rowIndex) == null)
                sheet.CreateRow(rowIndex);
            if (sheet.GetRow(rowIndex).GetCell(columnIndex) == null)
                return sheet.GetRow(rowIndex).CreateCell(columnIndex);
            return sheet.GetRow(rowIndex).GetCell(columnIndex);
        }


        /// <summary>
        /// 給字符串型值匹配相應的Excel數據類型，並為單元格賦值
        /// </summary>
        public static void CellSetValue(ICell cell, string content)
        {
            DateTime dateTime;
            double numeric;
            if (double.TryParse(content, out numeric))
            {
                cell.SetCellValue(numeric);
            }
            /*else if (DateTime.TryParse(content, out dateTime))
            {
                cell.SetCellValue(dateTime);
                cell.SetCellType(CellType.Numeric);
            }*/
            else
            {
                cell.SetCellValue(content);
            }

            #region 使用Convert進行轉換時需要確定字符串代表的類型，不然會抛error
            /*if (Convert.ToDouble(content).ToString().Equals(content))
            {
                cell.SetCellValue(content);
                cell.SetCellType(CellType.Numeric);
            }
            else if (Convert.ToDateTime(content).ToString().Equals(content))
            {
                cell.SetCellValue(Convert.ToDateTime(content));
            }
            else
            {
                cell.SetCellValue(content);
            }*/
            #endregion
        }

        public static string CellValueType(ICell cell)
        {
            string value;
            switch (cell.CellType)
            {
                case CellType.Blank:
                    return value = "[null]";
                case CellType.Boolean:
                    return value = "bool";
                case CellType.String:
                    return cell.StringCellValue;

            }
            return null;
        }

        /// <summary>
        /// 获取指定工作表中某个矩形范围的单元格集合
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="firstRow"></param>
        /// <param name="firstColumn"></param>
        /// <param name="height"></param>
        /// <param name="width"></param>
        /// <returns></returns>
        public List<ICell> GetCellList(ISheet sheet, int firstRow, int firstColumn, int height, int width)
        {
            List<ICell> temp = new List<ICell>(height * width);
            for (int i = firstRow; i < height + firstRow; i++)
            {
                for (int j = firstColumn; j < width + firstColumn; j++)
                {
                    temp.Add(GetCell(sheet, i - 1, j - 1));
                }
            }
            return temp;
        }

        /// <summary>
        /// 啟動某個文件
        /// </summary>
        /// <param name="exeName"></param>
        /// <param name="operType"></param>
        /// <returns></returns>
        [DllImport("kernel32.dll")]
        public static extern int WinExec(string exeName, int operType);

        public static void StartFile(string exepath, string filepath)
        {
            /*ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = filepath;
            psi.Arguments = "";
            psi.WindowStyle = ProcessWindowStyle.Normal;
            Process pro = Process.Start(psi);
            pro.WaitForExit();*/

            Process process = new Process();
            process.StartInfo.FileName = exepath;
            process.StartInfo.Arguments = filepath;
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardOutput = false;
            process.StartInfo.RedirectStandardInput = true;
            process.StartInfo.CreateNoWindow = false;
            process.Start();
            process.WaitForExit();
            process.Close();
        }

        /// <summary>
        /// /使用COM组件打开Excel文件（需要此电脑安装Excel程序）
        /// </summary>
        /// <param name="filepath"></param>
        public static void OpenExcelFile(string filepath)
        {
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application(); //引用Excel对象
            Microsoft.Office.Interop.Excel.Workbook book = excel.Application.Workbooks.Add(filepath);
            //引用Excel工作簿
            excel.Visible = true; //使Excel可视
        }

        public static void ClearSheet(ISheet sheet)
        {

            IEnumerator rows = sheet.GetEnumerator();
        }
    }
}
