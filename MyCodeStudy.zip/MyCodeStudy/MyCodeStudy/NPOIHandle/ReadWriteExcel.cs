﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NPOI;
using NPOI.XSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.HSSF.UserModel;

using System.Diagnostics;
using System.IO;
using NPOI.SS.Util;

namespace MyCodeStudy
{
    class ReadWriteExcel : IRunning
    {
        public void Run()
        {
            //SetBackGround();
            //SetFont();
            //SetHeightAndWidth();
            //ReadExcel();
            SetMergedRegion();
            //SetDateCell();
            //CreateExcel();
            //SetFormulate();
        }

        public void SetMergedRegion()
        {
            IWorkbook workbook1 = new XSSFWorkbook();
            ISheet sheet1 = workbook1.CreateSheet("SetMergedRegion");
            ICell cellA1 = sheet1.CreateRow(0).CreateCell(0);
            ICell cellB1 = sheet1.GetRow(0).CreateCell(1);
            ICell cellC1= sheet1.GetRow(0).CreateCell(2);
            ICell cellA2= sheet1.CreateRow(1).CreateCell(0);
            ICell cellB2 = sheet1.GetRow(1).CreateCell(1);
            ICell cellC2 = sheet1.GetRow(1).CreateCell(2);
            ICell cellA3 = sheet1.CreateRow(2).CreateCell(0);
            ICell cellB3 = sheet1.GetRow(2).CreateCell(1);
            ICell cellC3 = sheet1.GetRow(2).CreateCell(2);
            cellA1.SetCellValue("A1");
            cellB1.SetCellValue("B1");
            cellC1.SetCellValue("C1");
            cellA2.SetCellValue("A2");
            cellB2.SetCellValue("B2");
            cellC2.SetCellValue("C2");
            cellA3.SetCellValue("A3");
            cellB3.SetCellValue("B3");
            cellC3.SetCellValue("C3");

            //設置A1對齊為水平和垂直居中
            ICellStyle cellstyleMerge = workbook1.CreateCellStyle();
            cellstyleMerge.Alignment = HorizontalAlignment.Center;
            cellstyleMerge.VerticalAlignment = VerticalAlignment.Center;
            cellA1.CellStyle = cellstyleMerge;

            //合併單元格區域
            //單元格區域對象，row和column從下標0開始
            CellRangeAddress cellRange1 = new CellRangeAddress(0,1,0,1);
            //合併前檢查該區域是否在其他合併區域中
            //if (!sheet1.IsMergedRegion(cellRange1))
                //sheet1.AddMergedRegion(cellRange1);//合併單元格


            //寫入文件
            FileStream fileStream = File.Create(@"D:\SetMergedRegion.xlsx");
            workbook1.Write(fileStream);
            fileStream.Close();
            workbook1.Close();
            OpenFile(@"D:\SetMergedRegion.xlsx");
            Console.ReadKey();
        }
        public void ReadExcel()
        {
            if (!File.Exists(@"D:\NPOIRead.xlsx")) return;
            string fileName = @"D:\NPOIRead.xlsx";
            //FileStream fileStream = File.OpenRead(fileName);
            IWorkbook workbook1 = new XSSFWorkbook(File.OpenRead(@"D:\NPOIRead.xlsx"));
            ICell cellC2 = workbook1.GetSheetAt(0).GetRow(1).GetCell(2);
            Console.WriteLine(" C2: "+GetCellValue(cellC2));          
        }
        public static object GetCellValue(ICell cell) {
            object value=null;
            if (cell == null) return "Cell is null";
            switch (cell.CellType){
                case CellType.Numeric://日期在NPOI中是以double類型存儲的                   
                    if (DateUtil.IsCellDateFormatted(cell)){//判斷是否是日期
                        value = cell.DateCellValue;break;
                    }
                    value = cell.NumericCellValue; break;
                case CellType.Formula:
                    value = cell.CellFormula;//獲取公式，如"SUM(11,22)"
                    //value = cell.NumericCellValue;//獲取公式結果,結果為數值
                    //value = cell.StringCellValue;//獲取公式結果,結果為字符串
                    break;
                default:
                    value = cell.ToString(); break;
            }
            return value;
        }

        public void SetHeightAndWidth()
        {
            IWorkbook workbook1 = new XSSFWorkbook();
            ICell cell1 = workbook1.CreateSheet("SetHeightAndWidth").CreateRow(0).CreateCell(0);
            ICell cell2 = workbook1.GetSheetAt(0).GetRow(0).CreateCell(1);
            ICell cell3 = workbook1.GetSheetAt(0).GetRow(0).CreateCell(2);
            ICell cell4 = workbook1.GetSheetAt(0).GetRow(0).CreateCell(3);
            cell1.SetCellValue("22");
            cell2.SetCellValue("333");
            cell3.SetCellValue("4444");
            cell4.SetCellValue("1234567890");
            //設置行高--Height的單位是1/20磅，HeightInPoints的單位是磅
            workbook1.GetSheetAt(0).GetRow(0).Height = 15*20;//設置第一行行高
            workbook1.GetSheetAt(0).CreateRow(1).HeightInPoints = 30;//創建第二行並設置行高
            //設置列寬--列寬的單位是1/256字符
            workbook1.GetSheetAt(0).SetColumnWidth(0,2* 256);
            workbook1.GetSheetAt(0).SetColumnWidth(1,3* 256);
            workbook1.GetSheetAt(0).SetColumnWidth(2,4* 256);

            //workbook1.GetSheetAt(0).AutoSizeColumn(3);//設置自動列寬

            //寫入文件
            FileStream fileStream = File.Create(@"D:\SetHeightAndWidth.xlsx");
            workbook1.Write(fileStream);
            fileStream.Close();
            workbook1.Close();
            OpenFile(@"D:\SetHeightAndWidth.xlsx");
            Console.ReadKey();
        }
        public void SetFont()
        {
            IWorkbook workbook1 = new XSSFWorkbook();
            ICell cell1 = workbook1.CreateSheet("SetFont").CreateRow(0).CreateCell(0);
            
            cell1.SetCellValue("字體設置");
            ICellStyle cellStyle1 = workbook1.CreateCellStyle();//創建一個單元格樣式對象                                                                                                                       
            IFont font1 = workbook1.CreateFont();//創建字體對象      
            font1.FontName = "宋體";//設置字體名稱           
            font1.FontHeightInPoints = 15;//設置字體大小            
            font1.IsBold = true;//設置粗體            
            font1.Color = NPOI.HSSF.Util.HSSFColor.Black.Index;//設置字體顔色           
            font1.Underline = FontUnderlineType.Single;//設置單下劃綫
            //font1.IsStrikeout = true;//設置刪除線     
            cellStyle1.SetFont(font1); //将设置好的字体對象賦給樣式對象
            //設置單元格水平對齊方式為居中
            cellStyle1.Alignment = HorizontalAlignment.Center;
            //設置單元格垂直對齊方式為居中
            cellStyle1.VerticalAlignment = VerticalAlignment.Center;
            //將样式對象赋给单元格對象
            cell1.CellStyle = cellStyle1;

            //寫入文件
            FileStream fileStream = File.Create(@"D:\SetFont.xlsx");
            workbook1.Write(fileStream);
            fileStream.Close();
            workbook1.Close();
            OpenFile(@"D:\SetFont.xlsx");
        }

        public void SetBackGround()
        {
            IWorkbook workbook1 = new XSSFWorkbook();
            ICell cell1 = workbook1.CreateSheet("SetBackGroundColor").CreateRow(0).CreateCell(0);
            cell1.SetCellValue("Red Color");

            ICellStyle cellStyle1 = workbook1.CreateCellStyle();//創建一個單元格樣式對象                                                        
            cellStyle1.FillPattern = FillPattern.SolidForeground;//設置單元格填充圖案為纯色
            //設置單元格填充圖案顔色為紅色（設置屬性 FillPattern 后生效）
            cellStyle1.FillForegroundColor = NPOI.HSSF.Util.HSSFColor.Red.Index;
            cellStyle1.Alignment = HorizontalAlignment.Left;//設置單元格對齊方式為左对齐           
            cell1.CellStyle = cellStyle1;//將样式對象赋给单元格對象

            //寫入文件
            FileStream fileStream = File.Create(@"D:\SetBackGroundColor.xlsx");
            workbook1.Write(fileStream);
            fileStream.Close();
            workbook1.Close();
            OpenFile(@"D:\SetBackGroundColor.xlsx");
        }

        public void CreateExcel()
        {          
            IWorkbook book = new XSSFWorkbook();//創建一個工作簿
            
            ISheet sheet = book.CreateSheet("ExcelCreate");//創建一個工作表
            
            IRow row = sheet.CreateRow(0);//創建第一行
            
            ICell cell = row.CreateCell(0);//在第一行的第一列創建單元格
            
            cell.SetCellValue("This is A1");//給單元格賦值
            //創建文件流
            FileStream fileStream = new FileStream(@"D:\NPOI_Creat.xlsx", FileMode.OpenOrCreate);           
            book.Write(fileStream);//將工作簿寫入文件流
            
            fileStream.Close();//釋放资源
            book.Close();//釋放资源
        }

        public void SetDateCell() 
        {
            IWorkbook workbook1 = new XSSFWorkbook();
            ICell cell1 = workbook1.CreateSheet("DateCell").CreateRow(0).CreateCell(0);
            cell1.SetCellValue(new DateTime(2008,9,10,13,14,15));

            //設置單元格日期格式
            ICellStyle cellstyle1 = workbook1.CreateCellStyle();
            IDataFormat dataFormat1 = workbook1.CreateDataFormat();

            cellstyle1.DataFormat = dataFormat1.GetFormat("yyyy年m月d日H时M分S秒");
            cell1.CellStyle = cellstyle1;


            ICell cell2 = workbook1.CreateSheet("Scientific Notation").CreateRow(0).CreateCell(0);
            cell2.SetCellValue(123456789);

            //設置單元格日期格式
            ICellStyle cellstyle2 = workbook1.CreateCellStyle();
            //IDataFormat dataFormat2 = workbook1.CreateDataFormat();

            cellstyle2.DataFormat = HSSFDataFormat.GetBuiltinFormat("0.000E+00");
            cell2.CellStyle = cellstyle2;
            //寫入文件
            FileStream fileStream = File.Create(@"D:\SetDateCell.xlsx");
            workbook1.Write(fileStream);
            fileStream.Close();
            workbook1.Close();
            OpenFile(@"D:\SetDateCell.xlsx");
        }
        public void SetChinese()
        {
            IWorkbook workbook1 = new XSSFWorkbook();
            ICell cell1 = workbook1.CreateSheet("Chinese").CreateRow(0).CreateCell(0);
            cell1.SetCellValue(123456789);

            ICellStyle cellstyle1 = workbook1.CreateCellStyle();
            IDataFormat dataFormat1 = workbook1.CreateDataFormat();
            cellstyle1.DataFormat = dataFormat1.GetFormat("[DbNum2][$-804]0");
            cell1.CellStyle = cellstyle1;

            FileStream fileStream = File.Create(@"D:\SetChinese.xlsx");
            workbook1.Write(fileStream);
            fileStream.Close();
            workbook1.Close();
        }

        public void SetFormulate() 
        {
            IWorkbook workbook1 = new XSSFWorkbook();
            ISheet sheet1 = workbook1.CreateSheet("SetFormulat");
            IRow row1 = sheet1.CreateRow(0);
            ICell cell1 = row1.CreateCell(0);
            ICell cell2 = row1.CreateCell(1);
            ICell cell3 = row1.CreateCell(2);
            ICell cell4 = row1.CreateCell(3);
            ICell cell5 = row1.CreateCell(4);
            cell1.SetCellValue(1);
            cell2.SetCellValue(2);
            cell3.SetCellValue(3);
            cell4.SetCellValue(4);
            //cell5.SetCellFormula("A1+B1+C1+D1");
            //cell5.SetCellFormula("SUM(A1,B1,C1,D1)");
            //cell5.SetCellFormula("SUM(A1:D1)");
            //cell5.SetCellFormula("A1*B1*C1*D1");

            IRow row2 = sheet1.CreateRow(1);
            IRow row3 = sheet1.CreateRow(2);
            IRow row4 = sheet1.CreateRow(3);
            IRow row5 = sheet1.CreateRow(4);
            ICell cellA2 = row2.CreateCell(0);
            ICell cellA3 = row3.CreateCell(0);
            ICell cellA4 = row4.CreateCell(0);
            ICell cellA5 = row5.CreateCell(0);
            cellA2.SetCellValue("Here is a NPOI example");
            cellA3.SetCellFormula("UPPER(A2)");
            cellA4.SetCellFormula("LOWER(A2)");
            cellA5.SetCellFormula("PROPER(A2)");

            ICell cellB2 = row2.CreateCell(1);
            ICell cellB3 = row3.CreateCell(1);
            ICell cellB4 = row4.CreateCell(1);

            cellB2.SetCellValue(" A  B C    D   ");
            cellB3.SetCellFormula("TRIM(B2)");
            cellB4.SetCellFormula("TRIM(\"A  B C    D   \")");

            //寫入文件
            FileStream fileStream = File.Create(@"D:\SetFormulat.xlsx");
            workbook1.Write(fileStream);
            fileStream.Close();
            workbook1.Close();
        }

        public static void OpenFile(string filePath)
        {
            Process process = new Process();
            process.StartInfo.FileName = "cmd.exe";
            process.StartInfo.Arguments = "/c "+filePath;
            process.StartInfo.CreateNoWindow = false;
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardInput = true;
            process.StartInfo.RedirectStandardOutput = true;

            process.Start();
            //process.WaitForExit();
            process.Close();
        }
    }
}
