﻿using MyCodeStudy;
using NPOI.XWPF.UserModel;
using NPOI.HSSF.UserModel;
using NPOI.WP.UserModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MyCodeStudy
{
    class ReadWord : IRunning
    {
        public void Run()
        {
            string dirPath = @"C:\Users\F7692596\Desktop\文書\一审";
            DirectoryInfo di = new DirectoryInfo(dirPath);
            //Stream stream0 = File.OpenRead(@"C:\Users\F7692596\Desktop\文書\一审\人运与刘付林华安财产保险股份有限公司广东分公司东莞中心支公司机动车交通事故责任纠纷一案民事一审判决....docx");
            Stream stream0 = File.OpenRead(@"C:\Users\F7692596\Desktop\马祥云东莞兴雄鞋业有限公司健康权纠纷民事一审民事判决书.docx");
            XWPFDocument doc0 = new XWPFDocument(stream0);
            foreach (var para in doc0.Paragraphs)
            {
                Console.WriteLine(para.Text);
            }
            foreach (var item in di.GetFiles())
            {
                FileStream fs = new FileStream(item.FullName,FileMode.Open,FileAccess.Read);
                Stream stream = File.OpenRead(item.FullName);
                XWPFDocument doc = new XWPFDocument(stream);
                foreach (var para in doc.Paragraphs)
                {
                    Console.WriteLine(para);
                }             
                fs.Close();
                stream.Close();
            }
            Console.ReadKey();
        }
    }
}
