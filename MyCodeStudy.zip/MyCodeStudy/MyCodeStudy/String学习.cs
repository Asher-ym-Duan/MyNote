﻿using System;
using System.IO;

namespace MyCodeStudy
{
    public class String学习 : IRunning
    {
        public void Run()
        {
            string strA = "Good!";
            string strB = "Good!";
            string strC = strA;
            string strD = strA;
            string strE = "Good!" + "Good!";
            string strF = "Good!" + strA;
            string strG = new string("Good!Good!");
            string strH = new string("Good!");
            //string strI = new string(strA);
            //string strJ = new string(strA);
            string strI = new string("Good!");
            string strJ = new string("Good!");

            Console.WriteLine($"strA==strB? {strA==strB}");
            Console.WriteLine($"strA==strC? {strA==strC}");
            Console.WriteLine($"strA==strH? {strA == strH}");
            Console.WriteLine($"strA==strI? {strA == strI}");
            Console.WriteLine();

            Console.WriteLine($"strC==strD? {strC==strD}");

            Console.WriteLine($"strE==strF? {strE==strF}");
            Console.WriteLine($"strE==strG? {strE==strG}");

            Console.WriteLine($"strH==strI? {strH == strI}");
            Console.WriteLine($"strI==strJ? {strI == strJ}");
            Console.WriteLine($"strI.Equals(strJ)? {strI.Equals(strJ)}");
            Console.WriteLine();

            object objA = new object();
            object objB = new object();
            Console.WriteLine($"objA.Equals(objB) {objA.Equals(objB)}");
            Console.WriteLine();
            Console.WriteLine("----------------------------------------------------------------------");

            
            Emp emp1 = new Emp() { Name="张三"};
            Emp emp2 = new Emp() {Name= "张三" };
            Emp emp3 = new Emp() { Name = "李四" };
            Emp emp4 = emp1;
            Emp emp5 = emp1;
            //emp5.Name = "王五";

            Console.WriteLine($"emp5.Name={emp5.Name}  emp1.Name={emp1.Name}");
            Console.WriteLine($"emp1==emp2? {emp1==emp2}");
            Console.WriteLine($"emp1==emp4? {emp1 == emp4}");
            Console.WriteLine($"emp1.Equals(emp2)? {emp1.Equals(emp2)}");          
            //Console.WriteLine($"object.Equals(emp1,emp2)? {object.Equals(emp1,emp2)}");          
            Console.WriteLine($"emp1.Equals(emp4)? {emp1.Equals(emp4)}");
            Console.WriteLine();

            FileInfo fi1 = new FileInfo(@"D:\1.txt");
            FileInfo fi2 = new FileInfo(@"D:\1.txt");
            Console.WriteLine($"fi1.Equals(fi2){fi1.Equals(fi2)}");

            FileInfo fi3=null;
            //Console.WriteLine(fi3.Equals(fi1));
            Console.WriteLine(fi1.Equals(fi3));
            Console.WriteLine(fi1==fi3);


            int a = 1;
            a.Equals(1);


            Console.ReadKey();

        }
    }
    public class Emp
    {
        private string name;

        public string Name { get => name; set => name = value; }

        public override bool Equals(object obj)
        {
            Emp emp = obj as Emp;
            return emp.name == this.name;
        }
    }
}
