﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Word;
using Spire.Doc;
using Spire.Doc.Documents;

namespace MyCodeStudy
{
    class ReadDoc : IRunning
    {
        public void Run()
        {

        }
        public void ReadByCom()
        {
            string dirPath = @"C:\Users\F7692596\Desktop\文書\一审\";
            string docPath1 = dirPath + "马祥云东莞兴雄鞋业有限公司健康权纠纷民事一审民事判决书.doc";
            object docPath = docPath1;
            object missing = System.Reflection.Missing.Value;
            object readOnly = true;
            Microsoft.Office.Interop.Word.Application wordApp;
            wordApp = new Microsoft.Office.Interop.Word.Application();
            Microsoft.Office.Interop.Word.Document wordDoc = wordApp.Documents.Open(ref docPath, ref missing,
                                          ref readOnly,
                                          ref missing,
                                          ref missing,
                                          ref missing,
                                          ref missing,
                                          ref missing,
                                          ref missing,
                                          ref missing,
                                          ref missing,
                                          ref missing,
                                          ref missing,
                                          ref missing,
                                          ref missing,
                                          ref missing);
            string result = wordDoc.Content.Text;
            wordDoc.Close();
            wordApp.Quit();
        }
    }
}
