﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCodeStudy
{
    /// <summary>
    /// 学习索引器的用法
    /// </summary>
    internal class IndexerStudy : IRunning
    {
        /// <summary>
        /// Main方法，使用接口实现
        /// </summary>
        public void Run()
        {
            IndexerStudy study = new IndexerStudy(10);

            //使用索引器的set方法，给数组赋值
            study[0] = "Ann";
            study[1] = "Asher";
            study[2]="Aiden";
            study[3] = "Nick";
            study[4] = "Fliex";

            //使用索引器的get方法，返回数组内容
            for (int i = 0; i < study.size; i++)
            {
                Console.WriteLine($"The subscript of {i}："+study[i]);
            }
            //使用重载索引器的get方法，返回数组下标
            Console.WriteLine(study["Asher"]);
            Console.ReadKey(true);
        }

        //声明一个私有数组
        private string[] _nameArr;

        //用于给数组赋予长度
        public int size=10;

        //
        public IndexerStudy()
        { 
        
        }

        /// <summary>
        /// 构造函数，可自定义数组长度
        /// </summary>
        /// <param name="length"></param>
        public IndexerStudy(int length)
        {
            size = length;
            _nameArr = new string[size];
            for (int i = 0; i < size; i++)
            {
                _nameArr[i] = "N·A";
            }
        }

        /// <summary>
        /// 索引器，
        /// get方法：根据下标返回内容
        /// set方法：给数组某个下标赋值
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public string this[int index]
        {
            get
            {
                string tem = "";
                if (index >= 0 && index < _nameArr.Length)
                {
                    tem = _nameArr[index];
                }
                return tem;
            }
            set
            {
                if (index >= 0 && index < _nameArr.Length)
                {
                    _nameArr[index] = value;
                }
            }

        }

        /// <summary>
        /// 重载索引器
        /// get方法：根据内容返回下标
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public int this[string str]
        {
            get
            {
                for (int i = 0; i <size; i++)
                {
                    if (_nameArr[i].Equals(str))
                    {
                        return i;
                    }
                }
                return -1;
            }
        }

    }
}
