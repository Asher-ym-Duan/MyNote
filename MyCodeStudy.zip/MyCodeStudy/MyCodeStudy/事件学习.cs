﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCodeStudy
{
    class 事件学习 : IRunning
    {
        public void Run()
        {
            MyEvent myEvent = new MyEvent();
            MySubscriptionEvent mySubEvent = new MySubscriptionEvent();

            mySubEvent.SubscribeCountEvent(myEvent);
            myEvent.OnSimpleCount();
            Console.WriteLine("The Count = " + mySubEvent.Count);

            mySubEvent.SubscribeEatEvent(myEvent);
            myEvent.OnEat();



            Console.ReadKey();
        }
    }

    /// <summary>
    /// 事件订阅类
    /// </summary>
    class MySubscriptionEvent
    {
        #region 订阅计数事件
        public int Count { get; private set; }

        /// <summary>
        /// 用于订阅事件的方法
        /// </summary>
        /// <param name="myEvent"></param>
        public void SubscribeCountEvent(MyEvent myEvent)
        {
            //为对象myEvent的CountEvent事件注册事件处理方法-实例方法引用形式
            //myEvent.SimpleCount += OnCountEvnet;
            //为对象myEvent的CountEvent事件注册事件处理方法-委托形式
            myEvent.SimpleCount += new MyEvent.SimpleCountEventHandle(OnCountEvnet);
            //为对象myEvent的CountEvent事件注册事件处理方法-委托形式-Lambda表达式
            //myEvent.SimpleCount += ()=>{ Count+=2; };
            //为对象myEvent的CountEvent事件注册事件处理方法-委托形式-匿名函数形式
            //myEvent.SimpleCount += delegate { Count+=3; };

        }

        /// <summary>
        /// 计数事件的事件处理程序(事件处理方法)
        /// </summary>
        /// <param name="source"></param>
        /// <param name="args"></param>
        public void OnCountEvnet()
        {
            Count++;
        }
        #endregion

        #region 订阅吃饭事件
        public void OnEatEvent(object sender, EatEventArgs args)
        {
            Console.WriteLine("The eat food type is:" + args.FoodType);
        }
        public void SubscribeEatEvent(MyEvent myEvent)
        {
            myEvent.Eat += OnEatEvent;
        }
        #endregion
    }

    /// <summary>
    /// 事件发布类
    /// </summary>
    class MyEvent
    {
        #region 发布计数事件
        //声明一个委托
        public delegate void SimpleCountEventHandle();
        //声明一个非静态的计数事件
        public event SimpleCountEventHandle SimpleCount;
        //声明一个非静态的计数事件，EventHandle是系统自带的一个委托
        //public event EventHandler CountEvent;

        /// <summary>
        /// 触发计数事件的方法
        /// </summary>
        /// <param name="source"></param>
        /// <param name="args"></param>
        public void OnSimpleCount()
        {
            for (int i = 1; i < 100; i++)
            {
                if (i % 12 == 0)
                {
                    if (SimpleCount != null)   //检查计数事件是否注册了事件处理方法
                    {
                        SimpleCount();
                    }
                }
            }
        }
        #endregion

        #region 发布可以传递数据的吃饭事件
        //声明吃饭的委托
        //public delegate void EatEventHandle(object sender,EatEventArgs eatEventArgs); //方式1
        public delegate void EatEventHandle(MyEvent myEvent, EatEventArgs eatEventArgs); //方式2
        //声明吃饭事件
        public event EatEventHandle Eat;    //方式1
        //public event EventHandler<EatEventArgs> Eat;    //方式2

        /// <summary>
        /// 触发吃饭事件的方法
        /// </summary>
        public void OnEat()
        {
            EatEventArgs eatArgs = new EatEventArgs();
            eatArgs.FoodType = "cooked rick";
            if (Eat != null)
            {
                Eat(this, eatArgs);
            }
        }
        #endregion
    }

    /// <summary>
    /// 自定义一个用于吃饭事件的类
    /// </summary>
    class EatEventArgs : EventArgs
    {
        public string FoodType { get; set; }
    }
}