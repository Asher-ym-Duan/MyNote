﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCodeStudy
{
    /// <summary>
    /// 电脑信息类，用于测试
    /// </summary>
    class computeInfo
    { 
        
    }
    /// <summary>
    /// 学习集合的用法
    /// </summary>
    internal class CollectionStudy : IRunning
    {
        public void Run()
        {

        }

        /// <summary>
        /// 学习哈希表的用法
        /// </summary>
        public void HashtableStudy()
        {
            
        }


        /// <summary>
        /// 学习动态数组的用法
        /// </summary>
        public void ArrayListStudy()
        {
            ArrayList arrayList = new ArrayList();
            arrayList.Add(100);
            arrayList.Add("Asher");
            arrayList.Add(101);
            arrayList.Add(102);
            Console.WriteLine(arrayList.Count);
        }
    }
}
