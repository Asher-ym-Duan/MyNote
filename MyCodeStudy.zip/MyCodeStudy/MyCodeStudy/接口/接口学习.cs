﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Linq;
using DSCodeStudy;


namespace MyCodeStudy.接口
{
    public class 接口学习 : IRunning
    {
        public void Run()
        {
           List<int> list = new List<int>() { 1,2,3,5};
            IEnumerable<int> vs=list.Where(x => x > 1);
            foreach (var item in list)
            {
                Console.WriteLine(item.ToString());
            }
            list.Sort((x, y) => { 
                return Math.Abs(x-3)- Math.Abs(y - 3);
            });

            foreach (var item in list)
            {
                Console.Write(item.ToString()+"\t");
            }

            DirectoryInfo DInfo = new DirectoryInfo("D:\\Tools");
            Console.WriteLine();
        }
    }
}
