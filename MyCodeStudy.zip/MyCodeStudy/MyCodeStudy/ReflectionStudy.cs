﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;//使用反射需要添加这个命名空间
using System.Text;
using System.Threading.Tasks;

namespace MyCodeStudy
{
    /// <summary>
    /// 学习反射的用法
    /// </summary>
    internal class ReflectionStudy : IRunning
    {
        public void Run()
        {
            #region 反射获取自定义特性标签信息
            TestAttribute test =new TestAttribute(3,4);
            test.Display();

            //获取实例test的类型对象
            //（类类型，接口类型，数组类型，值类型，枚举类型，类型参数，泛型类型定义和 “open  or closed constructed generic types”等）
            //Type type = typeof(TestAttribute);        //method1:typeof运算符
            //Type type = test.GetType();     //method2:实例的GetType()方法
            //Console.WriteLine(test.ToString());
            Type type = Type.GetType(test.ToString());      //method3:Type类的静态方法GetType()


            //获取类的所有自定义特性
            //GetCustomAttributes（false/true）这个函数返回此成员（可以是类/方法等）的所有自定义特性,返回值为基类类型的数组
            Object[] attributeInfos = type.GetCustomAttributes(false);
            //因为是数组，所以需要遍历
            foreach (Object classAttribute in attributeInfos)
            {
                //使用强制类型转换
                AttributeTest.DebugInfo debugInfo = (AttributeTest.DebugInfo)classAttribute;
                if (null != debugInfo)  //非空判断
                {
                    Console.WriteLine("BugNo:\t" + debugInfo.BugNo);
                    Console.WriteLine("Developer:\t" + debugInfo.Developer);
                    Console.WriteLine("LastReview:\t" + debugInfo.LastReview);
                    Console.WriteLine("Remark:\t" + debugInfo.Message);
                    Console.WriteLine();
                }
            }

            //获取方法的自定义特性
            MethodInfo[] methods= type.GetMethods();    //获取该Type的所有公共方法
            foreach (MethodInfo method in methods)  //遍历所有方法
            { 
                Console.WriteLine(method.Name);
                foreach (Object methodAttribute in method.GetCustomAttributes(true))    //返回方法中的自定义特性
                {
                    Console.WriteLine(methodAttribute.ToString());

                    //直接采用强制类型转换会报错：System.InvalidCastException:“無法將類型 '__DynamicallyInvokableAttribute' 的物件轉換為類型 'TestAttribute.DebugInfo'
                    //原因是遍历方法的时候遍历到了 bool Equals(object obj),这个方法是 Object 中的，使用 override 可以重写。
                    //当你查看这些方法的定义会发现 object 中的这些方法都有 [__DynamicallyInvokable] 特性所以这里报错是因为 __DynamicallyInvokable 和 DeBugInfo 之间没有继承关系所以无法强制转换，
                    //而使用as关键字会在转换失败的时候将 dbi 设为 null，可以尝试下去掉非空判断程序依然会报错
                    //Error Code：
                    // AttributeTest.DebugInfo debugInfo = (AttributeTest.DebugInfo)methodAttribute;

                    //这里采用了装箱代替强制转换（？为什么装箱不会报错）
                    AttributeTest.DebugInfo debugInfo = methodAttribute as AttributeTest.DebugInfo;
                    if (null != debugInfo)  //非空判断
                    {
                        Console.WriteLine("BugNo:\t" + debugInfo.BugNo);
                        Console.WriteLine("Developer:\t" + debugInfo.Developer);
                        Console.WriteLine("LastReview:\t" + debugInfo.LastReview);
                        Console.WriteLine("Remark:\t" + debugInfo.Message);
                        Console.WriteLine();
                    }
                }
            }
            #endregion


            Console.ReadKey(); 
        }
    }

    /// <summary>
    /// 用于测试反射功能-获取自定义特性的各项标签
    /// </summary>
    [AttributeTest.DebugInfo(1, "Asher", "2022-04-28", Message = "Study Reflcetion and Attribute")]
    class TestAttribute
    {
        protected double length;
        protected double width;
        public double Length
        {
            get { return length; }
        }
        public double Widthy
        {
            get { return width; }
        }
        public TestAttribute(double len,double wid)
        {
            this.length = len;
            this.width = wid;
        }

        //给方法GetArea()设置自定义特性
        [AttributeTest.DebugInfo(1, "Asher", "2022-04-28", Message = "This is GetArea()")]
        public double GetArea()
        {
            return length * width;
        }

        //给方法Display()设置自定义特性
        [AttributeTest.DebugInfo(2, "Asher", "2022-04-28", Message = "This is Display()")]
        public void Display()
        {
            Console.WriteLine("Length:" + length);
            Console.WriteLine("Width:" + width);
            Console.WriteLine("Area:"+GetArea());
        }
    }
}
