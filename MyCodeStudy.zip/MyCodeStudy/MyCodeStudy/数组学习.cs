﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace MyCodeStudy
{
    class 数组学习 : IRunning
    {
        public void Run()
        {
            //设置控制台的输出编码格式为utf-8
            Console.OutputEncoding = Encoding.UTF8;
            //GetLength();
            Console.WriteLine("-------------------方法传入实参--------------");
            string str = "Today";
            TestReferenceType(ref str);
            Console.WriteLine(str);


            //参数数组
            Console.WriteLine("\n-------------------参数数组---------------");
            //int[] arr = { 1,2,3};
            int[] arr = (int[])Array.CreateInstance(typeof(int), 3);
            GetParamsArrayLenth(arr);
            GetParamsArrayLenth(1, 2, 3);


            ///数组的元素排序
            Console.WriteLine("\n-------------------一维数组的排序--------------");
            Console.Write("两个For循环进行冒泡排序:\t");
            int[] salaryArr = { 8000, 7000, 15000, 11000, 20000 };
            for (int i = 0; i < salaryArr.Length - 1; i++)
            {
                for (int j = i + 1; j < salaryArr.Length; j++)
                {
                    if (true && salaryArr[i] < salaryArr[j])  //从大到小排序
                    {
                        int temp = salaryArr[i];
                        salaryArr[i] = salaryArr[j];
                        salaryArr[j] = temp;
                    }
                    if (false && salaryArr[i] > salaryArr[j])  //从小到大排序
                    {
                        int temp = salaryArr[i];
                        salaryArr[i] = salaryArr[j];
                        salaryArr[j] = temp;
                    }
                }
            }
            PrintArrayElement<int>(salaryArr);      //打印数组元素

            Console.WriteLine();
            Console.Write("Array.Sort()方法实现从小到大排序:\t");
            Array.Sort(salaryArr);
            PrintArrayElement<int>(salaryArr);       //打印数组元素

            Console.WriteLine();
            Console.Write("Array.Sort()和Array.Reverse()方法实现从大到小排序:\t");
            Array.Sort(salaryArr);    //Array.Sort(Array array);一个参数的Sort默认从小到大排序
            Array.Reverse(salaryArr);     //实现从小到大排序，可以先Sort(),再Reverse()
            PrintArrayElement<int>(salaryArr);       //打印数组元素

            Console.WriteLine();
            Console.Write("Array.Sort<T>(T[] array, Comparison < T > comparison)方法实现大小排序:\t");
            //Comparison < T >是一个方法委托，两个参数，返回值为int
            //Array.Sort(salaryArr,(s1,s2)=>{ return s1.CompareTo(s2); });      //从小到大排序
            Array.Sort(salaryArr, (s1, s2) => { return s2.CompareTo(s1); });        //从大到小排序
            Array.Sort(salaryArr, (s1, s2) =>   s2.CompareTo(s1));        //从大到小排序
            PrintArrayElement<int>(salaryArr);       //打印数组元素

            Console.WriteLine();
            Array.Sort(salaryArr, delegate (int s1,int s2){ return s2.CompareTo(s1); });        //从大到小排序
            PrintArrayElement<int>(salaryArr);       //打印数组元素


            Console.WriteLine();
            Console.Write("Array.Sort(Array array, IComparer? comparer)方法实现大小排序:\t");
            //实现IComparer接口的类实现comparer()方法
            Array.Sort(salaryArr, new ForComparer());    //根据定义的
            PrintArrayElement<int>(salaryArr);       //打印数组元素

            Console.WriteLine();
            double[] douArr = { 1.1, 4.4, 2.2, 3.3, 0.01 };
            Array.Sort(douArr);
            PrintArrayElement<double>(douArr);       //打印数组元素

            string[] strArr = { "Today","Yesterday","Tomorrow"};
            Array.Sort(strArr);
            PrintArrayElement<string>(strArr);       //打印数组元素

            Console.ReadKey();
        }
        public int GetParamsArrayLenth(params int[] arr)
        {
            Console.WriteLine("The array lenth is: " + arr.Length);
            return arr.Length;
        }

        public void GetLength()
        {
            int[] arr = new int[] { 1, 2, 3 };
            int[,] arr1 = new int[,] { { 1, 2, 3, 4, 5 }, { 11, 12, 13, 14, 15 } };
            Console.WriteLine("arr.Length=" + arr.Length);
            Console.WriteLine("arr1.Length=" + arr1.Length);

            int[][] arr2 = new int[][] { new int[] { 1, 2, 3, 4 }, new int[] { 11, 12, 13 }, new int[] { 21, 22 } };
            Console.WriteLine("arr2.Length=" + arr2.Length);
            Console.WriteLine("arr2[0].Length=" + arr2[0].Length);
        }

        public void TestReferenceType(ref string text)
        {
            text = "Tomorrow";
            EatEventArgs obj1 = new EatEventArgs();
            obj1.FoodType = "西瓜";
            EatEventArgs obj2 = obj1;
            obj2.FoodType = "冬瓜";
            Console.WriteLine(obj1.FoodType + "--" + obj2.FoodType);
        }


        /// <summary>
        /// 打印数组每一个元素
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="arr"></param>
        public static void PrintArrayElement<T>(T[] arr)
        {
            Type type = typeof(T);
            if (type == typeof(int) || type == typeof(double) || typeof(string)==type)
            {
                foreach (var item in arr)
                {
                    Console.Write(item + "\t");
                }
            }
        }


    }

    /// <summary>
    /// 实现IComparer<T>的类，用于测试-对int型数组的大小排序
    /// </summary>
    class ForComparer : IComparer<int>
    {
        public int Compare(int x, int y)
        {
            //方法1：简便写法
            //return x.CompareTo(y);    //从小到大排序
            //return y.CompareTo(x);    //从大到小排序

            //方法2：自定义写法
            //从小到大排序的逻辑是根据返回值：
            // <0 ，x < y
            // ==0 , x==y
            // >0 , x>y
            //从大到小的逻辑反之
            if (false)   //从小到大排序
            {
                if (x > y)
                {
                    return 1;
                }
                else if (x == y)
                {
                    return 0;
                }
                else
                {
                    return -1;
                }
            }
            if (true)   //从大到小排序
            {
                if (x > y)
                {
                    return -1;
                }
                else if (x == y)
                {
                    return 0;
                }
                else
                {
                    return 1;
                }
            }

        }
    }
}
