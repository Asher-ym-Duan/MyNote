﻿#define TEST_ATTRIBUTE
//#undef TEST_ATTRIBUTE
using System;
using System.Collections.Generic;
using System.Diagnostics; //使用 Attribute 时需要引用该命名空间
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MyCodeStudy
{

    /// <summary>
    /// 学习特性的用法
    /// </summary>
    internal class AttributeStudy : IRunning
    {

        //特性（Attribute）是用于在运行时传递程序中各种元素（比如类、方法、结构、枚举、组件等）的行为信息的声明性标签
        //.Net框架提供了两种类型的特性：预定义特性和自定义特性
        public void Run()
        {
            AttributeTest.Message("This");      //测试Conditional预定义特性
            AttributeTest.Message("2022-04-28", "段勇铭");      //测试Obsolete预定义特性
            Console.ReadKey();
        }

    }
    public class AttributeTest
    {
        //Conditional预定义特性标记了一个条件方法，其执行依赖于指定的预处理标识符。
        //其可以等价于#if  #endif
        [Conditional("TEST_ATTRIBUTE")]
        public static void Message(string str)
        {
            Console.WriteLine(str);
        }


        //Obsolete预定义特性表示这个方法被弃用，两个重载：
        //[Obsolete()]      提示该方法已过时
        //[Obsolete("在版本1.2中遗弃")]       可以添加过时的相关信息
        //[Obsolete("在版本1.2中遗弃", false)]        可以设置使用该方法时是否报错
        [Obsolete()]
        public static void Message(string Time, string Name)
        {
            Console.WriteLine($"Name:{Name}  Time:{Time}");
        }


        //定义特性必须要派生自System.Attribute类
        //AttributeUsage预定义特性可以描述一个自定义特性，一个重载
        //[AttributeUsage(AttributeTarges.Method|AttributeTarges.Constructor|……|)]
        //
        [AttributeUsage(AttributeTargets.All, AllowMultiple = true, Inherited = true)]
        public class DebugInfo : System.Attribute
        {
            private int bugNo;
            private string developer;
            private string lastReview;
            public string message;

            public DebugInfo(int input_bugNo, string input_developer, string input_lastReview)
            {
                this.bugNo = input_bugNo;
                this.developer = input_developer;
                this.lastReview = input_lastReview;
            }

            public int BugNo
            {
                get { return bugNo; }
            }
            public string Developer
            {
                get { return developer; }
            }
            public string LastReview
            {
                get { return lastReview; }
            }
            public string Message
            {
                set { message = value; }
                get { return message; }
            }
        }
    }
    
}