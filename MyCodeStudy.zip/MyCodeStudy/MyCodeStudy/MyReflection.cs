﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;

namespace MyCodeStudy

{
    public class DevcieInfo
    {
        public string PanelNum;
        public string DeviceSerial;
    }

    public delegate void StartOnePanelTest(DevcieInfo info);
    public interface IDeviceWatcher
    {
        void Setup();
        void InsertHandler(StartOnePanelTest startTestDelegate);
        void Stop();
    }
    public class MyReflection:IRunning
    { 
        public IDeviceWatcher watcher;

        public void Run()
        {
            MyReflection myReflection = new MyReflection();
            myReflection.findDll();
            Console.ReadKey();
        }
        public void findDll()
        {
            string path = @"D:\C#Study\Reflection";
            string refDll = "DeviceWatcher.dll";
            string refClass = "DeviceWatcher.UsbDeviceWatcher";
            bool exist = File.Exists(refDll);

            DirectoryInfo di = new DirectoryInfo(path);     //创建指定路径的DirectoryInfo类的实例
            FileInfo[] files = di.GetFiles(refDll,SearchOption.AllDirectories);
            refDll = files[0].FullName;     //截取搜寻到的第一个文件or目录的完整目录
            path = Path.GetFullPath(refDll);        //获取绝对路径
            Assembly pluginAss = Assembly.LoadFrom(path);       //加载程序集

            if (pluginAss !=null)
            {
                Type pluginType = pluginAss.GetType(refClass);      //获取指定的类型
                Console.WriteLine(pluginType.ToString());
                object watcher=Activator.CreateInstance(pluginType);        //会发生异常？？？
            }
            //Console.WriteLine(watcher);
            //Console.WriteLine(exist);
            //Console.WriteLine(path);
            Console.ReadKey(true);
        }
    }
}
