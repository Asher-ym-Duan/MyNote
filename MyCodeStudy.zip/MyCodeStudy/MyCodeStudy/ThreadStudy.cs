﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MyCodeStudy
{
    /// <summary>
    /// 学习多线程的使用
    /// </summary>
    internal class ThreadStudy : IRunning
    {
        public void Run()
        {
            //1.创建线程的第一个方法：Thread类
            //创建一个无参的方法线程
            ThreadStart threadStartA = new ThreadStart(TestMethod);
            Thread threadA = new Thread(threadStartA);
            //创建一个带参(1个参数)的方法线程，线程启动时需要输入参数
            //注意：使用 ParameterizedThreadStart 委托不是传递数据的类型安全的方法，
            //      因为 System.Threading.Thread.Start(System.Object) 方法重载接受任何对象
            //注意：ParameterizedThreadStart只能实例化带一个参数的方法，有多个参数时可以输入一个存储参数信息的实例化对象
            ParameterizedThreadStart parameterizedThreadStartB = new ParameterizedThreadStart(TestMethod);
            Thread threadB =new Thread(parameterizedThreadStartB);
            //创建一个带参（2个及以上参数）的方法线程
            //注意：将线程执行的方法和参数都封装到一个类里面。通过实例化该类，方法就可以调用属性来实现间接的类型安全地传递参数。
            Employee Employee = new Employee("Asher","F7692596",23,1,Gender.male,Position.engineer,5000);
            Thread threadC = new Thread(new ThreadStart(Employee.showMessage));
            //线程启动
            //threadA.Start();
            //threadB.Start("Ann");
            //threadC.Start();


            //2.创建线程的第二个方法：线程池
            //注意：这里只能加入带参数（1个参数）的方法，
            //疑问：怎么传入参数?
            //解答：ThreadPool.QueueUserWorkItem(方法名,参数对象);
            ThreadPool.QueueUserWorkItem(TestMethod,new Object());
            ThreadPool.QueueUserWorkItem(Employee.showMessage,"ThreadPool");
            ThreadPool.QueueUserWorkItem((m)=>Console.WriteLine("Lambda  Parameter："+m),3);

            //3.创建线程的第三个方法：Task
            System.Threading.Tasks.Task.Factory.StartNew(TestMethod, "TeskCreat");


            //全部线程暂停
            Thread.Sleep(2000);
            Console.ReadKey();
        }

        /// <summary>
        /// 不带参数的方法
        /// </summary>
        public  void TestMethod()
        {
            for (int i = 0; i < 100; i=i+2)
            {
                Console.WriteLine(i+" Method without parameters");
            }
            Console.WriteLine("------------------------End--------------------");
        }

        /// <summary>
        ///带参数的方法 
        /// </summary>
        /// <param name="age"></param>s
        /// <param name="name"></param>
        public void TestMethod(object obj)
        {
            /*            //判断obj的类型是否为WorkInfo，否就退出方法
                        if (!(typeof(Employee) == obj.GetType()))
                        {
                            return;
                        }
                        //将传入的参数转换为WorkInfo类型
                        Employee Employee = obj as Employee;
                        //循环输出信息，用于线程测试
                        for (int i = 0; i < 1500; i=i+2)
                        {
                            Console.WriteLine(i+"\tThis is a method");
                            Console.WriteLine($"Name:{Employee.name}\tage:{Employee.age}\t{Employee.gender}");
                        }*/
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(i + " Method have one parameter: "+obj);
            }
            Console.WriteLine("------------------------End--------------------");
        }
    }
}
