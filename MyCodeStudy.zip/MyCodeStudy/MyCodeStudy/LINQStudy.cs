﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCodeStudy
{
    //疑问1：Select()和Where()为什么可以互换位置？

    /// <summary>
    /// 学习Linq的使用
    /// </summary>
    internal class LINQStudy : IRunning
    {
        public void Run()
        {
            //1.过滤运算符where
            int[] array = { 1, 2, 3, 4, 5 };
            var timesArray=array.Select(x=>x*10).Where(x=>x>20).ToArray();
            foreach (var item in timesArray)
            {
                //Console.WriteLine(item);
            }
            //对于文件的处理
            string path = @"D:\CodeStudy\FileHandling";
            string[] filePaths=Directory.GetFiles(path);
            
            try
            {
                //FileStream fs = new FileStream(filePaths[0], FileMode.OpenOrCreate, FileAccess.ReadWrite);
                //IEnumerable<char> textLine = File.ReadAllText(filePaths[0]).Where((row, index) => index == 1);
                IEnumerable<char> textLine = File.ReadAllText(filePaths[0]);
                //IEnumerable<string> textLine = File.ReadAllLines(filePaths[0]).Where((row, index) => index == 1);
                foreach (var line in textLine)
                {
                    Console.WriteLine(line);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            StreamReader streamReader = new StreamReader(filePaths[0]);
            string content = streamReader.ReadToEnd();
            Console.WriteLine(content); 




            //2.过滤运算符OfType
            foreach (var item in Employee.employees)
            {
                Console.WriteLine($"{item.name}\t{item.workYear} 年");
            }
            Employee[] emp = Employee.employees.Where(e=>e.workYear>2).ToArray();
            /*var typeResult = from s in Employee.employees.OfType<string>() select s;
            var typeResult2 = Employee.employees.OfType<string>();
            Console.WriteLine($"{typeResult}:::{typeResult2}");*/


           


            //测试 yield 的用法
            //使用yield可以定义迭代器
            //使用yield  return语句看一次返回一个元素
            //更多详情请参考：https://docs.microsoft.com/zh-cn/dotnet/csharp/language-reference/keywords/yield
            //约束：
            /*foreach (var item in GetAllEvenNumber())
            {
                Console.WriteLine(item);
            }*/
            /*IEnumerable<int> arrs = GetAllEvenNumber();
            foreach (var item in arrs)
            {
                Console.WriteLine(item);
            }*/
            

            Console.ReadKey();
        }
        
        /// <summary>
        /// 获取0-100的偶数，用于测试 yield 的用法
        /// </summary>
        /// <returns></returns>
        public IEnumerable<int> GetAllEvenNumber()
        {
            for (int i = 0; i <= 100; i++)
            {
                if (i % 2 == 0)
                {
                    //步骤1：该语句执行一次后会跳出该函数，并记录当前位置
                    //步骤2：跳出该函数后会执行调用该函数的语句
                    //步骤3：调用语句执行完毕后会继续进入该函数的下次循环，重复步骤1和步骤2，直到循环结束
                    yield return i;
                }
            }
            yield break;    //跳出 yield
        }
    }
}
