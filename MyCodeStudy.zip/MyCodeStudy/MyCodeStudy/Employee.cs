﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCodeStudy
{
    /// <summary>
    /// 员工类，用于储存员工信息
    /// </summary>
    public class Employee
    {
        public string jobNumber;
        public string name;
        public int age;
        public DateTime entryDate;
        public double workYear;
        public Gender gender;
        public Position position;
        private double _salary;
        public double Salary { get; set; }
        //给Employee类型的静态集合employees赋值

        public static List<Employee> employees = new List<Employee>()
        {
            new Employee("Asher", "F7692596","2021/7/22"),
            new Employee("Ann","F7692820","2021/8/13"),
            new Employee("Aiden","F7691188","2019/11/7"),
            new Employee("Jovan","F7692577","2021/7/16"),
            new Employee("Gregory","502218","2016/9/26"),
            new Employee("Eaton","F1216090","2008/7/25"),
            new Employee("Wendel","502036","2015/8/2"),
        };

        /// <summary>
        ///构造函数，参数： 姓名+工号
        /// </summary>
        /// <param name="name"></param>
        /// <param name="jobNumber"></param>
        public Employee(string name, string jobNumber)
        {
            this.name = name;
            this.jobNumber = jobNumber;
        }

        /// <summary>
        /// 构造函数，参数：姓名+工号+入职日期
        /// </summary>
        /// <param name="name"></param>
        /// <param name="jobNumber"></param>
        /// <param name="entryDate"></param>
        public Employee(string name, string jobNumber, string entryDate)
        {
            this.name = name;
            this.jobNumber = jobNumber;
            this.entryDate= DateTime.Parse(entryDate);
            this.workYear = GetWorkYear(this.entryDate);
        }
       
        /// <summary>
        /// 构造函数，参数：姓名+工号+年龄+工作年资+性别+职位+薪资（底薪）
        /// </summary>
        /// <param name="name"></param>
        /// <param name="number"></param>
        /// <param name="age"></param>
        /// <param name="workyear"></param>
        /// <param name="gender"></param>
        /// <param name="position"></param>
        /// <param name="salary"></param>
        public Employee(string name, string number, int age, int workyear, Gender gender, Position position, int salary)
        {
            this.name = name;
            this.position = position;
            this.age = age;
            this.jobNumber = number;
            this.workYear = workyear;
            this.gender = gender;
            this.Salary = salary;
        }

        /// <summary>
        /// 用于测试多参数线程的方法
        /// </summary>
        /// <param name="position"></param>
        public void showMessage()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"{i} name:{name} position:{position} workYear:{workYear}");
            }
            Console.WriteLine("---------------------End-----------------------");
        }

        /// <summary>
        /// 用于测试多参数线程的方法
        /// </summary>
        /// <param name="position"></param>
        public void showMessage(object obj)
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"{i} name:{name} position:{position} workYear:{workYear} parameter:{obj}");
            }
            Console.WriteLine("---------------------End-----------------------");
        }

        /// <summary>
        /// 根据入职日期来计算职工的工作年资
        /// </summary>
        /// <param name="entryDate"></param>
        /// <returns></returns>
        public static double GetWorkYear(DateTime entryDate)
        {
            DateTime corrent = DateTime.Now;    //获取当前系统时期
            TimeSpan timeSpan = corrent- entryDate ;    //运算符重载，可以直接将两个时期进行加减运算
            double workYear = Math.Round((double)timeSpan.TotalDays / 365,2);   //计算年资
            return workYear;
        }
    }


    /// <summary>
    /// 性别枚举：male or female
    /// </summary>
    public enum Gender
    {
        female,
        male
    }

    /// <summary>
    /// 职务枚举：普通员工，工程师，老板
    /// </summary>
    public enum Position
    {
        generalStaff,
        engineer,
        boss
    }
}
