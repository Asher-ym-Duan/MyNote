﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MyCodeStudy.多线程
{
    public class 同步上下文学习 : IRunning
    {
        public static int[,] 座位表 = new int[10,10];

        public static Random random = new Random(); 

        public void Run()
        {
            /*
             * 假设你是一个食堂管理老师，管理学生吃饭
            吃饭流程：
                1.学生可以选择3个窗口之一排队打饭
                2.学生打完饭后，你作为老师需要给学生安排座位
                3.学生吃完后，需要通知你一声，你可以再次管理该座位
            */

            Console.WriteLine($"Run()--Task.CurrentId:{Task.CurrentId}--DateTime:{DateTime.Now.ToString("HH:mm:ss")}");
            SubMainThread();
        }
        public void SubMainThread()
        {
            string methodName = "SubMainThread()";
            Console.WriteLine($"{methodName}--Task.CurrentId:{Task.CurrentId}--DateTime:{DateTime.Now.ToString("HH:mm:ss")}");

            List<Student> stdList =   new List<Student>();
            stdList.Add(new Student("学生小明"));
            stdList.Add(new Student("学生小花"));
            stdList.Add(new Student("学生小华"));
            stdList.Add(new Student("学生小张"));
            stdList.Add(new Student("学生小王"));
            stdList.Add(new Student("学生小马"));
            stdList.Add(new Student("学生小朱"));

            List<打饭阿姨> 阿姨链表  = new List<打饭阿姨>();
            阿姨链表.Add(new 打饭阿姨("赵阿姨"));
            阿姨链表.Add(new 打饭阿姨("钱阿姨"));
            阿姨链表.Add(new 打饭阿姨("孙阿姨"));

            Teacher teacher = new Teacher("李老师");

            foreach (Student student in stdList)
            {
                TaskFactory taskFactory = new TaskFactory();
                taskFactory.StartNew(() => {
                    int num = random.Next(0, 阿姨链表.Count);
                    student.Act(阿姨链表[num], teacher);
                }, TaskCreationOptions.PreferFairness);
            }

            Console.ReadKey();
        }

        public void Student_A()
        {
            string methodName = "Student_A";
            Console.WriteLine($"{methodName}--Task.CurrentId:{Task.CurrentId}--DateTime:{DateTime.Now.ToString("HH:mm:ss")}");
            Console.WriteLine($"");
        }
        }
    
    public class Student 
    {
        public bool HaveFood=false;
        public bool IsSiting = false;
        public string Name { get; set; }

        public Student(string name)
        { 
            this.Name = name;
        }

        public void Act(打饭阿姨 阿姨, Teacher teacher)
        {
           // 阿姨.打饭Event += On打饭事件;
            //teacher.安排座位Event += On安排座位事件;
            排队打饭(阿姨);
            阿姨.打饭给学生();
            while (!HaveFood)
            {
                Thread.Sleep(1000);
            }
            排队找座位(teacher);
            teacher.安排座位();
            while (!IsSiting)
            {
                Thread.Sleep(1000);
            }
            Thread.Sleep(10000);
            Console.WriteLine($"学生 {Name} 吃完饭了！--{DateTime.Now.ToString("HH:mm:ss")} \n");
        }

        public void 排队打饭(打饭阿姨 阿姨)
        {
            阿姨.QueueEnque(this);

        }

        public void On打饭事件(object sender, EventArgs e)
        {
            打饭阿姨 ayi =sender as 打饭阿姨;
            ayi.打饭给学生();
        }

        public void 排队找座位(Teacher teacher)
        {
            teacher.QueueEnqueue(this);
        }

        public void On安排座位事件(object sender, EventArgs e)
        {
            Teacher tec =sender as Teacher;
            tec.安排座位();
        }

    }


    public class Teacher
    {

        public delegate void 安排座位EventHandle(object sender, EventArgs e);

        public event 安排座位EventHandle 安排座位Event;

        private  readonly object obj_lock = new object();

        public ConcurrentQueue<Student> _anpaizuoweiQueue;

        public ConcurrentQueue<Student> 安排座位队列 
        {
            get { return _anpaizuoweiQueue; }
            set {
                _anpaizuoweiQueue = value;
                if (_anpaizuoweiQueue.Count>0)
                {
                    On安排座位(this,null);
                }
            }
        }

        public string Name { 
            get; 
            set; }

        public Teacher(string name)
        {
            _anpaizuoweiQueue = new ConcurrentQueue<Student>();
            this.Name = name;
        }

        public void QueueEnqueue(Student std)
        {
            安排座位队列.Enqueue(std);
            On安排座位(this,null);
        }
        public void 安排座位()
        {
            lock(obj_lock)
            {
                if (!安排座位队列.TryPeek(out Student student))
                {
                    return;
                }
                Console.WriteLine($"{Name} 正在给 {student.Name} 安排座位……--{DateTime.Now.ToString("HH:mm:ss")} \n");
                Thread.Sleep(3000);
                if (安排座位队列.TryDequeue(out student))
                {
                    Console.WriteLine($"{Name} 给 {student.Name} 安排好了座位!--{DateTime.Now.ToString("HH:mm:ss")} \n");
                    student.IsSiting = true;
                }
            }
            
        }
        public void On安排座位(object sender, EventArgs e)
        {

            if (this.安排座位Event != null)
            {
                安排座位Event(this, null);
            }
        }
    }


    public class 打饭阿姨
    {
        public delegate void 打饭EventHandle(object sender,EventArgs e);

        public event 打饭EventHandle 打饭Event;

        private  readonly object obj_lock = new object();

        public ConcurrentQueue<Student> _danfanQueue;
        public ConcurrentQueue<Student> 打饭队列 
        {
            get 
            {
                return _danfanQueue;
            }
            set {
                _danfanQueue = value;
            } 
        }
        public string Name { get; set; }

        public 打饭阿姨(string name)
        {
            _danfanQueue = new ConcurrentQueue<Student>();
            this.Name=name;
        }
        public void QueueEnque(Student student)
        {
            打饭队列.Enqueue(student);
            if (打饭队列.Count>0)
            {
                On打饭(this,null);
            }
        }

        public void 打饭给学生()
        {
            lock (obj_lock)
            {
                if (!打饭队列.TryPeek(out Student student))
                {
                    return;
                }             
                Console.WriteLine($"{Name} 正在给 {student.Name} 打饭……--{DateTime.Now.ToString("HH:mm:ss")} \n");
                Thread.Sleep(5000);
                if (打饭队列.TryDequeue(out student))
                {
                    Console.WriteLine($"{Name} 给 {student.Name} 打好了饭!--{DateTime.Now.ToString("HH:mm:ss")} \n");
                    student.HaveFood = true;
                }
            }
           
        }

        public void On打饭(object sender, EventArgs e)
        {
            if (this.打饭Event!=null)
            {
                打饭Event(this,null);
            }
        }
    }
}
