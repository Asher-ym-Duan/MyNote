﻿using MyCodeStudy.多线程;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MyCodeStudy
{
    class 多线程学习 : IRunning
    {
        private readonly static object obj_Lock = new object();

        private int state = 0;
        public void Run()
        {
            Console.OutputEncoding = Encoding.UTF8;     //设置控制台输出编码格式为UTF-8

            try
            {
                #region 1.Thread创建线程
                if (false)
                {
                    Console.WriteLine("------------------------Thread独立创建线程-------------------------");
                    //创建无参方法的线程
                    ThreadStart threadStart1 = new ThreadStart(TestParameter);
                    Thread thread1 = new Thread(threadStart1);
                    //Thread thread1 = new Thread(new ThreadStart(TestParameter));      //简便写法
                    thread1.Start();
                    //创建带参方法(一个参数，参数为object类型)的线程
                    Thread thread2 = new Thread(new ParameterizedThreadStart(TestParameter));
                    //thread2.Start();
                    thread2.Start("西瓜");
                    //创建无参循环方法的线程
                    Thread thread3 = new Thread(EndlessPrint);
                    //thread3.Start();
                    //Thread.Sleep(2000);
                    //thread3.Interrupt();
                    //thread3 = null;
                    //Console.WriteLine("thread3状态： "+thread3.IsAlive);


                    //查看当前进程的所有线程
                    foreach (ProcessThread item in Process.GetCurrentProcess().Threads)
                    {

                    }

                    //.NET 5及更高版本不支持Abort方法
                    //thread3.Abort();
                    Process currentProcess = Process.GetCurrentProcess();
                    currentProcess.Threads[2].Dispose();
                    //待续……
                }
                #endregion

                #region ThreadPool创建线程
                if (false)
                {
                    Console.WriteLine();
                    Console.WriteLine("------------------------ThreadPool创建线程-------------------------");
                }
                #endregion

                #region Task创建线程
                if (false)
                {
                    Console.WriteLine();
                    Console.WriteLine("------------------------Task创建线程-------------------------");

                    //1.Task的实例，通过Start()方法开启线程
                    Task task1 = new Task(() => { this.TestParameter(); });  //无参委托的Task实例
                    task1.Start();
                    Task task2 = new Task((x) => this.TestParameter(x), "Task创建线程");    //带参委托的Task实例
                    task2.Start();
                    Task<int> task3 = new Task<int>(() =>
                    {
                        Console.WriteLine("Task3---当前年份：" + DateTime.Now.Year);
                        return DateTime.Now.Year;
                    });     //带返回值委托的Task实例
                    task3.Start();

                    //2.静态方法Task.Run()开启线程
                    Task.Run(() => { Console.WriteLine("Task.Run()---无返回值"); }); //无返回值的静态Run()
                    Task<string> task4 = Task<string>.Run(() =>
                    {
                        Console.WriteLine("Task4---Task.Run()---有返回值");
                        return "强哥已go die！";
                    }); //有返回值的静态Run()
                    Console.WriteLine(task4.Result);

                    //3.Task.Factory.StartNew()开启线程
                    TaskFactory factory = Task.Factory;
                    factory.StartNew(() =>
                    {
                        Console.WriteLine("Task.Factory.StartNew()---无返回值");
                    });
                    Task<string> task5 = factory.StartNew<string>(() =>
                    {
                        Console.WriteLine("Task5---Task.Factory.StartNew()---有返回值");
                        return "结局仓促";
                    });

                    //new Task().RunSynchronously()（同步方式，上面三种异步方式）
                    Task task6 = new Task(() => { Console.WriteLine("Task6---异步启动"); });
                    task6.RunSynchronously();
                }
                #endregion

                #region Task学习
                if (false)
                {
                    Console.WriteLine();
                    Console.WriteLine("------------------------Task学习-------------------------");

                    //Wait
                    Console.WriteLine("时间：执行taskStudy1前---" + DateTime.Now.ToString("HH:mm:ss:ff"));
                    Task taskStudy1 = Task.Run(() =>
                    {
                        int i = 1000000000;
                        for (int j = 0; j < i; j++)
                        {
                            if (j % 50000000 == 0)
                            {
                                Console.Write(j + "\t");
                            }
                        }
                    });
                    //taskStudy1.Wait();
                    taskStudy1.Wait(1000);
                    Console.WriteLine();
                    Console.WriteLine("时间：执行taskStudy1后--" + DateTime.Now.ToString("HH:mm:ss:ff"));
                    Console.WriteLine("测试Console.WriteLine()方法");


                    Task task6 = new Task(() => { Console.WriteLine("Task6---异步启动"); });
                    task6.RunSynchronously();
                    //在使用WaitAny、WaitAll、WhenAll、Continue时更具有扩展性，需要使用Task数组形式
                    List<Task> tasks1 = new List<Task>();
                    tasks1.Add(taskStudy1);
                    tasks1.Add(task6);
                    //WaitAny,当参数中的其中一个task完成时，就继续往下执行，，，卡主线程
                    //Task.WaitAny(taskStudy1,task6);
                    Task.WaitAny(tasks1.ToArray());
                    Console.WriteLine("时间：执行WaitAny后--" + DateTime.Now.ToString("HH:mm:ss:ff"));

                    //WaitAll，当参数中的所有task完成时，才继续往下执行，，，卡主线程
                    Console.WriteLine();
                    //Task.WaitAll(taskStudy1,task6);
                    Task.WaitAll(tasks1.ToArray());

                    //Task静态方法 WhenAny+ContinueWith 等价于 TaskFactory实例方法 ContinueWhenAny，，，不卡主线程
                    Console.WriteLine();
                    //Task.WhenAny(taskStudy1, task6).ContinueWith((s)=> { this.EndlessPrint(30);});
                    //Task.WhenAny(tasks1.ToArray()).ContinueWith((s)=> { this.EndlessPrint(30);});
                    TaskFactory factory = Task.Factory;
                    Task task7 = factory.ContinueWhenAny(tasks1.ToArray(), (s) => this.EndlessPrint(30));

                    //Task静态方法 WhenAny+ContinueWith 等价于 TaskFactory实例方法 ContinueWhenAny,,,不卡主线程
                    Console.WriteLine();
                    tasks1.Add(task7);
                    //Task.WhenAll(tasks1.ToArray()).ContinueWith((s) => { this.EndlessPrint(20); });
                    //factory.ContinueWhenAll(tasks1.ToArray(), (s) => this.EndlessPrint(30));


                    Task.WaitAll(task7);
                    Console.WriteLine();
                    Console.WriteLine("-------TaskCreationOptions-------");
                    //Task 的实例属性TaskCreationOptions只能在创建实例时设置，并且在子线程中设置

                    //None,默认情况，子线程和父线程和没有运行关系
                    Task creatOption1 = new Task(() =>
                    {
                        Console.WriteLine("进入Action<string>方法  creatOption1");
                        Task taskChild1 = new Task(() => { this.PrintString("ABCDEFG", 5); });
                        Task taskChild2 = new Task(() => { this.PrintString("HIJKLMN", 5); });
                        taskChild1.Start();
                        taskChild2.Start();
                        Console.WriteLine("退出Action<string>方法  creatOption1");
                    });
                    //creatOption1.Start();

                    //AttachedToParent,子线程附加到父线程，测试有效
                    //父线程必须等待所有子线程执行结束才能结束，相当于Task.WaitAll(task1, task2)。
                    Task creatOption2 = new Task(() =>
                    {
                        string str = "AttachedToParent";
                        Console.WriteLine("进入Action<string>方法  " + str);
                        Task taskChild1 = new Task(() => { this.PrintString("ABCDEFG", 5); }, TaskCreationOptions.AttachedToParent);
                        Task taskChild2 = new Task(() => { this.PrintString("HIJKLMN", 5); }, TaskCreationOptions.AttachedToParent);
                        taskChild1.Start();
                        taskChild2.Start();
                        Console.WriteLine("退出Action<string>方法  " + str);
                    });
                    //creatOption2.Start();

                    //DenyChildAttach
                    //不允许子任务附加到父任务上，反AttachedToParent，和默认效果一样。
                    Task creatOption3 = new Task(() =>
                    {
                        string str = "creatOption3";
                        Console.WriteLine("进入Action<string>方法 " + str);
                        Task taskChild1 = new Task(() => { this.PrintString("ABCDEFG", 5); }, TaskCreationOptions.DenyChildAttach);
                        Task taskChild2 = new Task(() => { this.PrintString("HIJKLMN", 5); }, TaskCreationOptions.DenyChildAttach);
                        taskChild1.Start();
                        taskChild2.Start();
                        Console.WriteLine("退出Action<string>方法 " + str);
                    });
                    //creatOption3.Start();

                    //PreferFairness
                    //相对来说比较公平执行的先申请的线程优先执行  ，测试结果显示不是按顺序，为什么？？
                    Task creatOption4_1 = new Task(() =>
                    {
                        this.PrintString("ABCDEFG", 5);
                    }, TaskCreationOptions.PreferFairness);
                    Task creatOption4_2 = new Task(() => { this.PrintString("HIJKLMN", 5); }, TaskCreationOptions.PreferFairness);
                    //creatOption4_1.Start();
                    //creatOption4_2.Start();

                    //LongRunning
                    //事先知道是长时间执行的线程就加这个参数，线程调度会优化。
                    //RunContinuationsAsynchronously
                    //强制以异步方式执行添加到当前任务的延续。
                    //HideScheduler
                    //防止环境计划程序被视为已创建任务的当前计划程序。 这意味着像 StartNew 或 ContinueWith 创建任务的执行操作将被视为 System.Threading.Tasks.TaskScheduler.Default当前计划程序。


                    //creatOption1.Wait();
                    //Console.WriteLine("creatOption2 is completed "+creatOption2.IsCompleted);
                    //creatOption2.Wait();
                    //Console.WriteLine("creatOption2 is completed "+creatOption2.IsCompleted);
                    //creatOption3.Wait();
                    //creatOption4_1.Wait();
                    //creatOption4_2.Wait();

                }
                #endregion

                #region Task进阶--多线程捕获异常
                if (false)
                {
                    Console.WriteLine();
                    Console.WriteLine("------------------------Task进阶-多线程捕获异常-------------------------");

                    //线程不等待时：任务内部发生异常，而异常捕捉try catch在任务外部，此时捕捉不到异常
                    try
                    {
                        Task task = new Task(() =>
                        {
                            int j = 0;
                            int k = 10 / j; //引发异常
                            Console.WriteLine("---打印--");
                        });
                        //task.Start();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error :" + ex.Message);
                    }

                    //线程不等待时：多线程中，如果要捕捉异常，可以在线程内部try-catch，可以捕捉到异常
                    try
                    {
                        Task task = new Task(() =>
                        {
                            try
                            {
                                int j = 0;
                                int k = 10 / j; //引发异常
                                Console.WriteLine("---打印--");
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("线程等待---任务内部Try： Error :" + ex.Message);
                            }

                        });
                        //task.Start();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("任务外部Try：Error :" + ex.Message);
                    }

                    //线程等待时：多线程中，如果要捕捉异常，需要设置主线程等待子线程执行结束，可以捕捉到异常
                    try
                    {
                        Task task = new Task(() =>
                        {
                            int i = 0;
                            int j = 10;
                            int k = j / i; //尝试除以0，会异常
                        });
                        task.Start();
                        //线程等待
                        task.Wait();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("任务外部Try：Error :" + ex.Message);
                    }

                }
                #endregion

                #region Task进阶--线程取消
                if (true)
                {
                    Console.WriteLine();
                    Console.WriteLine("------------------------Task进阶-线程取消-------------------------");

                    //线程取消是不能从外部取消的，
                    //线程取消的实质还是通过变量去控制程序的运行和结束，正常结束，或者发生异常结束

                    //初始化一个CancellationTokenSource实例
                    CancellationTokenSource souce = new CancellationTokenSource();

                    //注册一个线程取消后执行的Action委托
                    souce.Token.Register(() =>
                    {
                        this.DoingSomething("Canceled", 500);
                    });

                    Task task1 = new Task(() =>
                    {
                        while (!souce.IsCancellationRequested)
                        //while (true)
                        {
                            this.DoingSomething("Asher", 500);
                        }
                    }, souce.Token);
                    task1.Start();

                    //第一种:直接取消
                    Thread.Sleep(1000);     //阻塞线程2秒
                    //Cancel方法更新IsCancellationRequested的值
                    souce.Cancel();

                    Console.WriteLine("----------------开始使用TaskManage----------------");
                    //TaskManage taskManage1 = new TaskManage();
                    TaskManage taskManage1 = new TaskManage(()=>Console.WriteLine("已取消线程"));
                    //CancellationTokenSource sourceManage1 = new CancellationTokenSource();
                    taskManage1.RunLoopTask(() =>
                    {
                        this.DoingSomething("==TaskManage==", 500);
                    });
                    Thread.Sleep(3000);
                    taskManage1.CancelTask();


                    //task1.Start();

                    //第二种:延时取消
                    //souce.CancelAfter(2000);

                    //第三种：在CancellationTokenSource构造函数中添加延时时间
                    //CancellationTokenSource souce1 = new CancellationTokenSource(2000);

                    //第四种：组合取消
                    //组合中的任意一个实例取消，组合体就取消，但组合中的其他实例不受影响
                    if (true)
                    {
                        CancellationTokenSource souceCombine1 = new CancellationTokenSource();
                        CancellationTokenSource souceCombine2 = new CancellationTokenSource();
                        CancellationTokenSource souceCombine3 = new CancellationTokenSource();
                        CancellationTokenSource combineSource = CancellationTokenSource.CreateLinkedTokenSource(
                            souceCombine1.Token, souceCombine2.Token, souceCombine3.Token);
                        souceCombine2.Cancel();
                        //Console.WriteLine($"souceCombine1.IsCancellationRequested={souceCombine1.IsCancellationRequested}");
                        Console.WriteLine($"souceCombine2.IsCancellationRequested={souceCombine2.IsCancellationRequested}");
                        Console.WriteLine($"souceCombine3.IsCancellationRequested={souceCombine3.IsCancellationRequested}");
                        Console.WriteLine($"souceCombine3.IsCancellationRequested={souceCombine3.IsCancellationRequested}");
                    }


                    //CancellationToken类监控取消??
                }
                #endregion

                #region Task进阶--线程返回值
                if (false)
                {
                    Console.WriteLine();
                    Console.WriteLine("------------------------Task进阶-线程返回值-------------------------");

                    //线程开启类的返回值
                    Task<string> task1 = new Task<string>(() =>
                    {
                        this.DoingSomething("task1", 100);
                        return "OK";
                    });
                    task1.Start();
                    Console.WriteLine($"读取的子线程task1返回值为---{task1.Result}--{Thread.CurrentThread.ManagedThreadId.ToString("00")}---{DateTime.Now.ToString("HH:mm:ss.ff")}");

                    //线程延续类的返回值
                    Task<string> task2 = new Task<string>(() =>
                    {
                        this.DoingSomething("task2", 100);
                        return "Today";
                    });
                    task2.Start();
                    Task<string> task3 = task2.ContinueWith((t) =>
                    {  //这里的t代表task2
                        this.DoingSomething("task3", 100);
                        return t.Result + " " + "Tomorrow";
                    });
                    Console.WriteLine($"读取的子线程task2返回值为---{task2.Result}--{Thread.CurrentThread.ManagedThreadId.ToString("00")}---{DateTime.Now.ToString("HH:mm:ss.ff")}");
                    Console.WriteLine($"读取的子线程task3返回值为---{task3.Result}--{Thread.CurrentThread.ManagedThreadId.ToString("00")}---{DateTime.Now.ToString("HH:mm:ss.ff")}");

                    //线程条件延续类
                    Task<int> task4 = new Task<int>(() =>
                    {
                        this.DoingSomething("task4", 500);
                        return 4;
                    });
                    Task<int> task5 = new Task<int>(() =>
                    {
                        this.DoingSomething("task5", 500);
                        return 5;
                    });
                    task4.Start();
                    task5.Start();
                    Task<int>[] tasklist1 = { task4, task5 };
                    //Task.WaitAll(tasklist1);
                    var task = Task.WhenAny(tasklist1);   //WhenAny的返回值task是Task<Task<int>>，意味着task.Resut是Task<int>,task.Result.Result才是int
                    Console.WriteLine($"读取的子线程task返回值为---{task.Result.Result}--{Thread.CurrentThread.ManagedThreadId.ToString("00")}---{DateTime.Now.ToString("HH:mm:ss.fff")}");
                    //var task3 = Task.WhenAny(taskList1);

                }
                #endregion

                #region Task进阶--线程安全
                if (false)
                {
                    Console.WriteLine();
                    Console.WriteLine("------------------------Task进阶-线程安全-------------------------");
                    //线程安全：一段业务逻辑，单线程执行和多线程执行后的结果如果完全一致，是线程安全的，否则就是线程不安全的

                    //1.线程安全产生的原因
                    //线程的开启需要时间，线程开启不阻塞主线程的执行，循环10000次的时间不足够开启10000个线程的时间就会出现数据不足10000的现象出现
                    //单线程执行10000次
                    if (false)
                    {
                        List<int> intlist = new List<int>();
                        for (int i = 0; i < 10000; i++)
                        {
                            intlist.Add(i);
                        }
                        Console.WriteLine($"intlist中有{intlist.Count}条数据");

                        //多线程执行10000次
                        List<Task> taskList1 = new List<Task>();
                        List<int> intlist1 = new List<int>();
                        //int[] intArr1 = new int[10000];
                        Task task;
                        for (int i = 0; i < 10000 - 1; i++)
                        {
                            task = new Task(() =>
                            {
                                intlist1.Add(i);
                                //intArr1[i] = i;
                            });
                            taskList1.Add(task);
                            task.Start();
                        }
                        Task.WaitAll(taskList1.ToArray());
                        Console.WriteLine($"intlist1中有{intlist1.Count}条数据,intlist1的长度为{intlist1.Count}");
                        //Console.WriteLine($"intArr11中有{intArr1.Length}条数据");

                    }


                    //2.加锁解决线程安全问题
                    //锁的本质：是独占引用，加锁是反多线程的，可以解决线程安全问题，但是不推荐大家使用，加锁会影响性能
                    //锁的标准写法： private readonly static object obj_Lock = new object(); 锁对象，不要去锁String锁This
                    //多线程执行10000次
                    if (false)
                    {
                        List<Task> taskList2 = new List<Task>();
                        List<int> intlist2 = new List<int>();
                        for (int i = 0; i < 10000; i++)
                        {
                            Task.Run(() =>
                            {
                                lock (obj_Lock) //锁对象，不要去锁String锁This
                                {
                                    intlist2.Add(i);
                                }
                            });
                        }
                        Task.WaitAll(taskList2.ToArray());
                        Console.WriteLine($"intlist2中有{intlist2.Count}条数据");
                    }


                    //3.分块执行解决线程安全问题
                    //把执行的任务切割，然后分别开启一个线程执行，
                    //每一个线程内部执行的动作是单线程，线程安全，等待所有线程执行结束以后，再做一个统一汇总
                    if (false)
                    {
                        List<int> intlist = new List<int>();
                        List<int> intlist2 = new List<int>();
                        List<int> intlist3 = new List<int>();
                        int Num1 = 3000;
                        int Num2 = 6000;
                        int Num3 = 10000;
                        List<Task> taskList = new List<Task>();
                        taskList.Add(Task.Run(() =>
                        {
                            for (int i = 0; i < Num1; i++)
                            {
                                intlist.Add(i);
                            }
                        }));
                        taskList.Add(Task.Run(() =>
                        {
                            for (int i = Num1; i < Num2; i++)
                            {
                                intlist2.Add(i);
                            }
                        }));

                        taskList.Add(Task.Run(() =>
                        {
                            for (int i = Num2; i < Num3; i++)
                            {
                                intlist3.Add(i);
                            }
                        }));
                        Task.WaitAll(taskList.ToArray());
                        intlist.AddRange(intlist2);
                        intlist.AddRange(intlist3);
                        Console.WriteLine($"intlist中有{intlist.Count}条数据");

                    }

                    //4.使用线程安全对象
                    if (false)
                    {
                        lock (obj_Lock)
                        {
                            Interlocked.Increment(ref state);
                        }
                    }

                    //解决中间变量问题





                }
                #endregion


                #region Task进阶--解决中间变量问题
                if (false)
                {
                    Console.WriteLine();
                    Console.WriteLine("------------------------Task进阶-解决中间变量问题-------------------------");

                    //1.单线程执行
                    if (false)
                    {
                        for (int i = 0; i < 5; i++)
                        {
                            Console.WriteLine($"ThreadID={Thread.CurrentThread.ManagedThreadId.ToString("00")}_i={i}");
                        }
                    }

                    //2.多线程执行问题
                    //Task开启线程的时候，延迟开启，在循环的时候，不会阻塞主线程，
                    //循环很快，线程执行业务逻辑的时候，循环已经结束了，i已经变成5了，所以打出来的都是5
                    if (false)
                    {
                        for (int i = 0; i < 5; i++)
                        {
                            Task.Run(() =>
                            {
                                Console.WriteLine($"ThreadID={Thread.CurrentThread.ManagedThreadId.ToString("00")}_i={i}");
                            });
                        }
                    }

                    //3.多线程执行+中间变量
                    //可以另外定义个变量，在每次循环的时候赋值，循环多少次，就会有多少个k，每个线程使用的是每一次循环内部的k
                    if (true)
                    {
                        for (int i = 0; i < 5; i++)
                        {
                            int k = i;
                            Task.Run(() =>
                            {
                                Console.WriteLine($"ThreadID={Thread.CurrentThread.ManagedThreadId.ToString("00")}_k={ k}");
                            });
                        }
                    }


                }
                #endregion


                #region Parallel学习
                if (false)
                {
                    Console.WriteLine();
                    Console.WriteLine("------------------------Parallel学习-------------------------");

                    //1.Parallel特点
                    //可以传入多个委托，多个委托中的内容是会开启线程来执行，执行的线程可能是新的线程，也可能是主线程
                    if (false)
                    {
                        //会阻塞主线程，相当于是主线程等待子线程执行结束
                        Parallel.Invoke(
                            () => this.DoingSomething("张三", 500),
                            () => this.DoingSomething("李四", 500),
                            () => this.DoingSomething("王五", 500),
                            () => this.DoingSomething("赵六", 500)
                        );
                        //把Parallel包在一个Task里面实现不卡主线程
                        Task.Run(() =>
                        {
                            Parallel.Invoke(
                            () => this.DoingSomething("Aiden", 500),
                            () => this.DoingSomething("Jerry", 500),
                            () => this.DoingSomething("Tom", 500),
                            () => this.DoingSomething("Wendel", 500)
                            );
                        });
                    }

                    //2.Parallel.For
                    //实现循环开启线程执行动作，可以获取索引，可以控制开启的线程数量
                    if (false)
                    {
                        ParallelOptions options = new ParallelOptions();
                        options.MaxDegreeOfParallelism = 10;
                        Parallel.For(0, 10, options, index =>
                        {
                            Console.WriteLine($"index：{ index}  线程ID:  {Thread.CurrentThread.ManagedThreadId.ToString("00")}");
                        });
                    }

                    //3、Parallel.ForEach
                    //实现循环遍历数组开启线程执行动作，可以获取数组值，可以控制开启的线程数量
                    if (false)
                    {
                        List<int> intlist = new List<int>() { 1, 2, 3, 5, 7, 11, 13, 17 };
                        ParallelOptions options = new ParallelOptions();
                        options.MaxDegreeOfParallelism = 3;
                        Parallel.ForEach(intlist, options, s =>
                        {
                            Console.WriteLine($"index：{ s}  线程ID:  {Thread.CurrentThread.ManagedThreadId.ToString("00")}");
                        });
                    }
                }
                #endregion

                #region Await/Async
                if (false)
                {
                    Console.WriteLine();
                    Console.WriteLine("------------------------Await/Async学习-------------------------");

                    //async修饰符只能修饰返回值为Task和void的方法，它不能用于程序的入口点，即Main方法
                    //await只能用于带async修饰符的方法中
                    //CallWithAsync();

                    //1.无返回值，有Async，无Await
                    //async是用来修饰方法，如果单独出现，方法会警告，不会报错，和普通的多线程方法没有什么区别，不存在线程等待的问题
                    if (false)
                    {
                        NoReturnAsyncNoAwait();
                    }

                    //2.无返回值，有Async，有Await
                    //await在方法体内部，只能放在async修饰的方法内，必须放在task前面
                    //主线程到await这里就返回了，执行主线程任务
                    //ask中的任务执行完毕以后，继续执行await后面的后续内容，有可能是子线程，也有可能是其他线程，甚至有可能是主线程来执行
                    //类似ContinueWith回调await后面的后续内容
                    if (false)
                    {
                        NoReturnAsyncAwait();
                    }

                    //3.无返回值，返回Task，有Async，有Await
                    //async Task == async void, Task和Task能够使用await, Task.WhenAny, Task.WhenAll等方式组合使用。Async Void 不行
                    //使用await时会默认返回一个
                    if (true)
                    {
                        Task task = NoReturnTaskAsyncAwait();
                        Console.WriteLine("task.IsCompleted={0}",task.IsCompleted);
                        Task.WhenAny(task).ContinueWith((a)=> {     //
                            this.DoingSomething("Continue Task",500);
                        });
                    }
                    
                }
                #endregion
            }
            catch (Exception ex)
            {
                Console.WriteLine("发生异常，异常信息：" + ex.Message);

            }
            Console.WriteLine();
            Console.WriteLine("程序末尾");
            Console.ReadKey();
        }

        public void TestParameter()
        {
            Console.WriteLine("这是一个无参数方法");
        }


        public void TestParameter(object obj)
        {
            if (obj != null)
            {
                Console.WriteLine($"这是一个有参数方法，参数数量为1，参数类型为object，当前传入的参数为 {obj.ToString()}");
                return;
            }
            Console.WriteLine($"这是一个有参数方法，参数数量为1，参数类型为object，当前传入的参数为 null");
        }


        public void EndlessPrint()
        {
            int i = 0, j = 0;
            int num = 50000000;
            while (true)
            {
                if (i % num == 0)
                {
                    Console.Write((j++) + " ");
                }
                i++;
            }
        }


        public void EndlessPrint(int count)
        {
            for (int i = 1; i <= count; i++)
            {
                Thread.Sleep(100);
                Console.Write(i + "\t");
            }
        }


        public void PrintString(string text, int count)
        {
            Console.WriteLine("--开始打印字符");
            char[] charArr = text.ToCharArray();
            for (int i = 0; i < count; i++)
            {
                foreach (var item in charArr)
                {
                    Thread.Sleep(10);
                    Console.Write(item + "\t");
                }
                Console.WriteLine(text + "\t");
            }
            Console.WriteLine("--结束打印字符");
        }


        /// <summary>
        /// 带Thread.Sleep的print方法
        /// </summary>
        /// <param name="name"></param>
        /// <param name="time">毫秒</param>
        public void DoingSomething(string name, int milliSecond)
        {
            Console.WriteLine($"DoingSomething--Start--{name}--{DateTime.Now.ToString("HH:mm:ss:fff")}");
            Thread.Sleep(milliSecond);
            Console.WriteLine($"DoingSomething--End--{name}--{DateTime.Now.ToString("HH:mm:ss:fff")}");
        }


        /// <summary>
        /// 打招呼的方法
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static string Greeting(string name) 
        {
            Thread.Sleep(1000);
            return string.Format("Hello, {0}",name);
        }


        /// <summary>
        /// 异步的方式返回一个打招呼的方法
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static Task<string> GreetingAsync(string name)
        {
            return Task.Run<string>(()=> {
                return Greeting(name);
            });
        }


        /// <summary>
        /// 调用异步方法
        /// </summary>
        public async static void CallWithAsync()
        {
            string result = await GreetingAsync("Asher");
            Console.WriteLine(result);
        }


        /// <summary>
        /// 无返回值，有Async，无Await
        /// </summary>
        private async void NoReturnAsyncNoAwait()
        {
            Console.WriteLine($"NoReturnAsyncNoAwait---Start---ThreadId={Thread.CurrentThread.ManagedThreadId}--{DateTime.Now.ToString("HH:mm:ss.fff")}");
            Thread.Sleep(3000);
            Console.WriteLine($"NoReturnAsyncNoAwait---End---ThreadId={Thread.CurrentThread.ManagedThreadId}--{DateTime.Now.ToString("HH:mm:ss.fff")}");
        }


        /// <summary>
        /// 无返回值，有Async，有Await
        /// </summary>
        private async void NoReturnAsyncAwait()
        {
            Console.WriteLine($"NoReturnAsyncAwait--Start--{Thread.CurrentThread.ManagedThreadId.ToString("00")}--{DateTime.Now.ToString("HH:mm:ss.fff")}");
            Task task = Task.Run(() =>
            {
                Thread.Sleep(3000);
                Console.WriteLine($"Task.Run--NoReturnAsyncAwait--{Thread.CurrentThread.ManagedThreadId.ToString("00")}--{DateTime.Now.ToString("HH:mm:ss.fff")}");
            });

            //主线程到await这里就返回了，执行主线程任务
            //task中的任务执行完毕以后，继续执行await后面的后续内容，有可能是子线程，也有可能是其他线程，甚至有可能是主线程来执行
            await task;

            Console.WriteLine($"NoReturnAsyncAwait--End--{Thread.CurrentThread.ManagedThreadId.ToString("00")}--{DateTime.Now.ToString("HH:mm:ss.fff")}");

            //类似ContinueWith回调await后面的后续内容
            //task.ContinueWith(t =>
            //{
            //    Console.WriteLine($"NoReturnAsyncAwait--End--{Thread.CurrentThread.ManagedThreadId.ToString("00")}--{DateTime.Now.ToString("HH:mm:ss.fff")}");
            //});
        }


        /// <summary>
        /// 无返回值，返回Task，有Async，有Await 
        /// </summary>
        /// <returns></returns>
        private async Task NoReturnTaskAsyncAwait()
        {
            Console.WriteLine($"NoReturnTaskAsyncAwait--Start--{Thread.CurrentThread.ManagedThreadId.ToString("00")}--{DateTime.Now.ToString("HH:mm:ss.fff")}");
            Task task = Task.Run(() =>
            {
                Thread.Sleep(3000);
                Console.WriteLine($"Task.Run--NoReturnTaskAsyncAwait--{Thread.CurrentThread.ManagedThreadId.ToString("00")}--{DateTime.Now.ToString("HH:mm:ss.fff")}");
            });
            await task;
            //Thread.Sleep(3000);
            Console.WriteLine($"NoReturnTaskAsyncAwait--End--{Thread.CurrentThread.ManagedThreadId.ToString("00")}--{DateTime.Now.ToString("HH:mm:ss.fff")}");
        }


        /// <summary>
        /// 返回Task<int>，有Async，有Await
        /// </summary>
        /// <returns></returns>
        private Task<int> ReturnTaskIntAsyncAwait()
        {
            Console.WriteLine($"ReturnTaskIntAsyncAwait--Start--{Thread.CurrentThread.ManagedThreadId.ToString("00")}--{DateTime.Now.ToString("HH:mm:ss.fff")}");
            TaskFactory taskFactory = new TaskFactory();
            Task<int> iResult = Task.Run(() =>
            {
                Thread.Sleep(3000);
                Console.WriteLine($"Task.Run--ReturnTaskIntAsyncAwait--{Thread.CurrentThread.ManagedThreadId.ToString("00")}--{DateTime.Now.ToString("HH:mm:ss.fff")}");
                return 123;
            });

            Console.WriteLine($"ReturnTaskIntAsyncAwait--End--{Thread.CurrentThread.ManagedThreadId.ToString("00")}--{DateTime.Now.ToString("HH:mm:ss.fff")}");
            return iResult;
        }


        /// <summary>
        /// 返回Task，实现多个任务顺序执行不阻塞
        /// </summary>
        /// <returns>async 就只返回long</returns>
        private async Task ReturnTaskAsyncAwaits()
        {
            Console.WriteLine($"ReturnTaskAsyncAwaits--Start--{Thread.CurrentThread.ManagedThreadId.ToString("00")}--{DateTime.Now.ToString("HH:mm:ss.fff")}");

            await Task.Run(() =>
            {
                this.DoingSomething("task1",500);
            });

            await Task.Run(() =>
            {
                this.DoingSomething("task2",500);
            });

            await Task.Run(() =>
            {
                this.DoingSomething("task3",500);
            });

            Console.WriteLine($"ReturnTaskAsyncAwaits--Start--{Thread.CurrentThread.ManagedThreadId.ToString("00")}--{DateTime.Now.ToString("HH:mm:ss.fff")}");
        }


        /// <summary>
        /// 计算方法
        /// </summary>
        /// <param name="total"></param>
        /// <returns></returns>
        private async Task<long> CalculationAsync(long total)
        {
            var task = await Task.Run(() =>
            {
                Console.WriteLine($"This is CalculationAsync Start,ThreadId={Thread.CurrentThread.ManagedThreadId}");
                long lResult = 0;
                for (int i = 0; i < total; i++)
                {
                    lResult += i;
                }
                Console.WriteLine($"This is CalculationAsync   End,ThreadId={Thread.CurrentThread.ManagedThreadId}");

                return lResult;
            });

            return task; //这句话必须由主线程来执行，线程在同一时刻只能做一件事儿
        }


        /// <summary>
        /// 在Winform中存在特殊处理
        /// </summary>
        private async Task TextAsyncResultChange()
        {
            Console.WriteLine($"TextAsyncResultChange--End--{Thread.CurrentThread.ManagedThreadId.ToString("00")}--{DateTime.Now.ToString("HH:mm:ss.fff")}");
            long lResult = await this.CalculationAsync(1_000_000);
            //更改控件的值，必须是(UI线程)主线程去执行；这跟Winform设计有关系，在Winform中，await后面的内容，都会让主线程来执行
            //this.textAsyncResult.Text = lResult.ToString();
            Console.WriteLine($"TextAsyncResultChange--End--{Thread.CurrentThread.ManagedThreadId.ToString("00")}--{DateTime.Now.ToString("HH:mm:ss.fff")}");
        }

    }

    

}
