﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MyCodeStudy.多线程
{
    public class TaskManage : IDisposable
    {
        private bool dispose;
        private Task task;
        private CancellationTokenSource cts;

        public Task Task { get => task; }
        public CancellationTokenSource Cts { get => cts; }
        public bool Dispose1 { get => dispose; }

        public TaskManage(Action ctsRegister) : this()    //立意明确，各只留一个接口来给两个属性赋值
        {
            this.cts.Token.Register(ctsRegister);
        }

        public TaskManage()
        {
            this.dispose = false;
            this.cts = new CancellationTokenSource();
        }

        public void CancelTask()
        {
            this.cts.Cancel();
            this.Dispose();
        }

        /// <summary>
        /// 只能执行需要循环操作的任务，方法内部有循环，检查标志位当前类的cts.IsCancellationRequested
        /// </summary>
        /// <param name="action"></param>
        public void RunLoopTask(Action action)
        {
            this.task = Task.Run(() => {
                Console.WriteLine("cts.IsCancellationRequested=" + cts.IsCancellationRequested);
                while (!this.cts.IsCancellationRequested)
                {
                    action();
                }
            }, this.cts.Token);
        }

        public void RunTask(Action action)
        {
            this.task = Task.Run(() => {
                if (!this.cts.IsCancellationRequested)
                {
                    action();
                }
            }, this.cts.Token);
        }

        public void Dispose()
        {
            //this.cts.Dispose();         //System.StackOverflowException:“”
            dispose = true;
            GC.SuppressFinalize(this);
        }
    }
}
