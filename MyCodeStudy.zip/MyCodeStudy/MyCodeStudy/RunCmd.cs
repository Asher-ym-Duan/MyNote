﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace MyCodeStudy
{
    class RunCmd : IRunning
    {
        public static string content="content is null";
        public void Run()
        {
            Console.WriteLine("Execute project: MyCodeStudy");
            LaunchCommandLineApp();
            Console.WriteLine(content);
            Console.ReadKey();
        }

        private void Application_Exit(object sender, EventArgs e)
        {
            // Assume we have a boolean variable indicating whether the
            //   application did its work successfully

            // Use 0 to indicate success, 1 to indicate that something went wrong
            content = "content is modified by  event";
        }

        public void LaunchCommandLineApp()

        {

            Process process = new Process();

            process.StartInfo.FileName = "cmd.exe";

            //string command = "start \"\" /b \"C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Google Chrome\"";
            string command = @" C:\Users\F7692596\source\repos\SetExtiCodeTo-1\SetExtiCodeTo-1\bin\Debug\SetExtiCodeTo-1.exe 123 && echo good ";
            //string command = @" D:\CodeStudy\DHAv2_Tool\dhav2client.exe P0B2R50114350271 && echo good ";

            process.StartInfo.Arguments = "/c " + command;

            Console.WriteLine("Execute CMD command: "+command); 

            process.StartInfo.UseShellExecute = false; //是否使用操作系统shell启动

            process.StartInfo.CreateNoWindow = false; //是否在新窗口中启动该进程的值 (不显示程序窗口)

            process.Start();

            process.Exited += new EventHandler(Application_Exit);

            // process.BeginErrorReadLine();
            // process.BeginOutputReadLine();

            //process.StandardOutput
            //string output = process.StandardOutput.ReadToEnd();

            process.WaitForExit(); //等待程序执行完退出进程

            int exitCode = process.ExitCode;

            Console.WriteLine("\n ExitCode:" + exitCode);

            process.Close();

        }
    }
}
