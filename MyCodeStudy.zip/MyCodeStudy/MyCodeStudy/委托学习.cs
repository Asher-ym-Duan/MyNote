﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyCodeStudy
{
    public class 委托学习 : IRunning
    {
        public delegate void  PrintNum(int x);
        public void Run()
        {
            Console.OutputEncoding = Encoding.UTF8;     //设置输出编码格式

            //委托作为参数时，可以直接将方法作为参数传入
            DelegateAsParameterMethod(ConsolePrintNumMethod);

            //使用Lambda表达式时，+= 需要该委托至少有一个方法
            PrintNum print = (x) => Console.WriteLine("Lambda--The num is： "+x.ToString());
            print(101);
            print += (x) => Console.WriteLine("Lambda--The num is： " + (x/2).ToString());
            print(102);

            //将实例方法作为参数传入方法中，并修改实例属性
            LogRecord logRecord = new LogRecord();
            Console.WriteLine();
            Console.WriteLine("Before Log=\n"+ logRecord.log);
            RecordLogMethod(logRecord.AddString, "毕业时间：20210615");
            RecordLogMethod(logRecord.AddString,"入职时间：20210722");
            Console.WriteLine("After Log=\n" + logRecord.log);


        }


        //将字符串logStr作为参数执行LogRecordDelegate委托
        public void RecordLogMethod(LogRecordDelegate logRecord,string logStr)
        {
            logRecord(logStr+"\n");
        }

        #region 测试委托能否作为参数传入方法
        public void DelegateAsParameterMethod(PrintNum print)
        {
            print(1);
            print(2);
        }
        public void ConsolePrintNumMethod(int x)
        {
            Console.WriteLine("The num is: " + x.ToString());
        }
        #endregion
    }

    public delegate void LogRecordDelegate(string logStr);

    class LogRecord
    {
        public StringBuilder log { get; set; }

        public LogRecord()
        { 
            log = new StringBuilder();
        }

        public void AddString(string logStr)
        { 
            this.log.Append(logStr);
        }
    }
}
