﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;

namespace MyCodeStudy.Socket
{
    public class 扫描局域网:IRunning
    {
        List<string> ips = new List<string>() {
            "10.156.220.223",
            "10.156.220.137",
            "10.156.221.86",
        };
        public void Run()
        {
            try
            {
                foreach (var item in ips)
                {
                    IPAddress ip = IPAddress.Parse(item);
                    IPHostEntry myScanHost = Dns.GetHostByAddress(ip);

                    string strHostName = myScanHost.HostName.ToString();
                    Console.WriteLine($"strHostName={strHostName}");
                    foreach (var ipitem in myScanHost.AddressList)
                    {
                        Console.WriteLine(ipitem.ToString());
                    }
                }
                IPAddress ip2 = IPAddress.Parse("10.156.220.");
                IPHostEntry myScanHost2 = Dns.GetHostByAddress(ip2);

                string strHostName2 = myScanHost2.HostName.ToString();
                Console.WriteLine($"strHostName={strHostName2}");
                foreach (var ipitem in myScanHost2.AddressList)
                {
                    Console.WriteLine(ipitem.ToString());
                }

            }
            catch (Exception)
            {

                throw;
            }
           
        }
    }
}
