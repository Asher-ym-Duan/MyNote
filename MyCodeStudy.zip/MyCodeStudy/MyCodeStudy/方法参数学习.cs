﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCodeStudy
{
    internal class 方法参数学习 : IRunning
    {
        public void Run()
        {
            方法参数学习 input = new 方法参数学习();

            //1.ref:可以将变量的地址传入方法内部，而不是简单的复制值
            int refNum = 20;        //实参通过 ref 传参时，需要初始化值
            Console.WriteLine("refNum = " + refNum);    //结果：refNum = 20
            int resultRef = input.TestRef(ref refNum);
            Console.WriteLine("Test Function result:" + resultRef);     //结果：Test Function result:21
            Console.WriteLine("refNum = " + refNum);    //结果：refNum = 21
            Console.WriteLine();

            //2.out：在方法内部去给外部变量赋值，一般用于函数有多个返回值的场所
            int x=1, y=2, z=3;  //可以不赋值，但需要声明
            Console.WriteLine($"x={x} , y={y} , z={z}");    //结果： x=1, y=2, z=3
            int resultOut = input.TestOut(out x,out y,out z);
            Console.WriteLine("Test Function result:"+resultOut);     //结果： Test Function result:20
            Console.WriteLine($"x={x} , y={y} , z={z}");    //结果： x = 21, y = 22, z = 23
            Console.WriteLine();


            //引用对象的传参，引用对象不需要加入ref,字符串比较特殊，仍需要ref
            int[] aaa = {10,2,-3,9,1};
            AscendingSort(aaa);
            foreach (var item in aaa)
            {
                Console.Write(item.ToString()+"\t");
            }
            Console.WriteLine();

            string str = "today is a good day!";
            ChangString(str);
            Console.WriteLine(str);
            ChangString_2(ref str);
            Console.WriteLine(str);


            Console.ReadKey();
        }

        public void AscendingSort(int[] arr)
        {
            Array.Sort(arr);
            arr[0] = 9999;
            //方法内部排序
            /*foreach (var item in arr)
            {
                Console.Write(item.ToString() + "\t");
            }
            Console.WriteLine();*/
        }

        public void ChangString(string str)
        {
            str = "ChangString!";
        }
        public void ChangString_2(ref string str)
        {
            str = "ChangString_2!";
        }
        public int TestRef(ref int i)
        {
            i += 1;
            return i;
        }
        public int TestOut(out int x, out int y, out int z)
        {
            x = 21;
            y = 22;
            z = 23;
            return 20;
        }
    }
}
