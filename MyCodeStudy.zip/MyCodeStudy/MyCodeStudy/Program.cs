﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCodeStudy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            //IRunning run = new String学习();
            //IRunning run = new Socket.扫描局域网();
            IRunning run = new 多线程.同步上下文学习();
            run.Run();
        }
    }
}
