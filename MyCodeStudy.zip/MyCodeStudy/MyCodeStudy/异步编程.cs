﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace MyCodeStudy
{
    class 异步编程 : IRunning
    {
        public void Run()
        {
            Console.OutputEncoding = Encoding.UTF8;

            try
            {
                //DoAsync_Void(1,1);


                Task task = DoAsync_Task(2,2);
                Console.WriteLine($"task.isCompleted={task.IsCompleted}----task.Id={task.Id}----task.Status={task.Status}");


                //Task<int> task = DoAsync_TaskT(3,3);
                //Console.WriteLine($"task.Result={task.Result}----task.isCompleted={task.IsCompleted}----task.Id={task.Id}----task.Status={task.Status}");

                Console.WriteLine($"");
            }
            catch (Exception ex)
            {

                Console.WriteLine("异常信息： "+ ex.Message);
            }

            Console.ReadKey();
        }

        /// <summary>
        /// 返回值为void的异步方法
        /// </summary>
        /// <param name="x1"></param>
        /// <param name="x2"></param>
        /// <returns></returns>
        public async void DoAsync_Void(int x1, int x2)
        {
            Console.WriteLine($"Start---返回值为void的异步方法");
            Task<int> task = Task.Run<int>(() => {
                Console.WriteLine("Enter----获取Sum值的task");
                Thread.Sleep(2000);
                Console.WriteLine("Exit----获取Sum值的task");
                return GetSum(x1, x2);
            });
            await task;
            Console.WriteLine($"End---返回值为void的异步方法");
        }


        /// <summary>
        /// 返回值为Task的异步方法
        /// </summary>
        /// <param name="x1"></param>
        /// <param name="x2"></param>
        /// <returns></returns>
        public async Task DoAsync_Task(int x1, int x2)
        {
            Console.WriteLine($"Start---返回值为Task的异步方法");
            Task<int> task = Task.Run<int>(() => {
                Console.WriteLine("Enter----获取Sum值的task");
                Thread.Sleep(2000);
                Console.WriteLine("Exit----获取Sum值的task");
                return GetSum(x1, x2);
            });
            await task;
            //Console.WriteLine($"End---返回值为Task的异步方法");
        }

        /// <summary>
        /// 返回值为Task<T>的异步方法
        /// </summary>
        /// <param name="x1"></param>
        /// <param name="x2"></param>
        /// <returns></returns>
        public async Task<int> DoAsync_TaskT(int x1, int x2)
        {
            Console.WriteLine($"Start---返回值为Task<T>的异步方法");
            Task<int> task = Task.Run<int>(() => {
                Console.WriteLine("Enter----获取Sum值的task");
                Thread.Sleep(2000);
                Console.WriteLine("Exit----获取Sum值的task");
                return GetSum(x1, x2);
            });
            await task;
            Console.WriteLine($"End---返回值为Task<T>的异步方法");
            return 123;
        }



        /// <summary>
        /// 两数相加的方法
        /// </summary>
        /// <param name="x1"></param>
        /// <param name="x2"></param>
        /// <returns></returns>
        public int GetSum(int x1,int x2)
        {
            return x1 + x2;  
        }


        public int GetMultiplier(int x1,int x2)
        {
            return x1 * x2;
        }
    }
}
