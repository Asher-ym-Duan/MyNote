﻿#define SYMBOL     //定义一个符号
#define SYMBOL_A    //定义一个符号
#undef SYMBOL_A  //解除一个定义
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCodeStudy
{
    /// <summary>
    /// 学习预处理的用法
    /// </summary>
    internal class PreprocessingStudy : IRunning
    {
       

        public void Run()
        {
            //#region 1.折叠代码块 2.给代码块添加注释说明
            #region test region1
            string str = "This is a #region code block";
            Console.WriteLine(str);
            #endregion

#if (SYMBOL)    //类似流程控制
            Console.WriteLine("SYMBOL is defined");
#endif
#if (SYMBOL_A)
            Console.WriteLine("SYMBOL_A is defined");
#else
            Console.WriteLine("SYMBOL_A is not defined");
#endif

            //警告
#warning "line：34  warning to developer" 


            Console.ReadKey();
        }

    }
}
