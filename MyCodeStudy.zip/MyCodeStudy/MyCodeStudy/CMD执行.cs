﻿using System;
using System.Diagnostics;
using System.Reflection;

namespace MyCodeStudy
{
    public class CMD执行 : IRunning
    {
        public string CMDCommand { get; set; }
        public string Sn { get; set; }
        public void Run()
        {
            Sn = "123456";
            //CMDCommand = $"/c adb -s {Sn} shell idme print";
            CMDCommand = $"/c adb devices";

            Cmd cmd = new Cmd();
            CmdCallerMessage cmdMessage = cmd.SyncExecute(CMDCommand, 3000);
            Console.WriteLine("output= "+cmdMessage.OutputDataMessage);
            Console.WriteLine("ErrorData= "+cmdMessage.ErrorDataMessage);
            Console.WriteLine("ExitCode= "+cmdMessage.ExitCode);
            Console.WriteLine("finish= "+cmdMessage.finish);
        }
    }


    /// <summary>
    /// CMD窗口对象
    /// 一个CMD窗口可以：执行命令并获取返回值
    /// </summary>
    public class Cmd
    {
        private CmdCommandCaller caller;
        public Cmd()
        {
            this.caller = new CmdCommandCaller();
            caller.FilePath = "cmd.exe";
        }

        //公共接口，执行命令并获取指令返回值
        public CmdCallerMessage SyncExecute(string args,int millSeconds)
        { 
            return this.caller.SyncExcute(args, millSeconds);
        }

    }


    /// <summary>
    /// CMD命令执行的返回情况对象
    /// </summary>
    public class CmdCallerMessage
    {
        private string errorDataMessage;
        private string outputDataMessage;
        private int exitCode;

        public CmdCallerMessage()
        {
            this.finish = false;
            this.errorDataMessage = "";
            this.outputDataMessage = "";
        }

        public bool finish { get; set; }

        public string OutputDataMessage
        {
            get { return outputDataMessage; }
            set { outputDataMessage = value; }
        }

        public string ErrorDataMessage
        {
            get { return errorDataMessage; }
            set { errorDataMessage = value; }
        }

        public int ExitCode
        {
            get { return exitCode; }
            set { exitCode = value; }
        }


    }


    /// <summary>
    /// CMD窗口用于执行命令的对象
    /// </summary>
    public class CmdCommandCaller
    {

        public CmdCommandCaller()
        {
        }

        public string FilePath
        {
            get;
            set;
        }

        private string syncOutPutStr;
        private string syncErrorStr;

        public CmdCallerMessage SyncExcute(String args, int milliSeconds)
        {
            if (FilePath == null)
            {
                return null;
            }

            try
            {
                Process SyncProcess = new Process();
                CmdCallerMessage ans = new CmdCallerMessage();

                SyncProcess.StartInfo.FileName = FilePath;
                SyncProcess.StartInfo.Arguments = args;

                SyncProcess.StartInfo.CreateNoWindow = true;
                SyncProcess.StartInfo.UseShellExecute = false;
                SyncProcess.StartInfo.RedirectStandardError = true;
                SyncProcess.StartInfo.RedirectStandardInput = true;
                SyncProcess.StartInfo.RedirectStandardOutput = true;
                lock (this)
                {
                    syncOutPutStr = "";
                    syncErrorStr = "";
                    SyncProcess.OutputDataReceived += new DataReceivedEventHandler(SyncOutputDataReceived);
                    SyncProcess.ErrorDataReceived += new DataReceivedEventHandler(SyncErrorDataReceived);

                    SyncProcess.Start();
                    SyncProcess.BeginOutputReadLine();
                    SyncProcess.BeginErrorReadLine();

                    bool isDone = SyncProcess.WaitForExit(milliSeconds);

                    if (isDone)
                    {
                        SyncProcess.WaitForExit();
                        int exitCode = SyncProcess.ExitCode;

                        ans.ExitCode = exitCode;
                        ans.finish = true;
                        ans.OutputDataMessage = syncOutPutStr;
                        ans.ErrorDataMessage = syncErrorStr;
                    }
                    else
                    {
                        ans.ExitCode = -1;
                        ans.finish = false;
                        ans.OutputDataMessage = "";
                        ans.ErrorDataMessage = "";
                        SyncProcess.Kill();
                    }
                }
                return ans;
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        private void SyncOutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            //Test data not null
            if (e.Data != null)
            {
                string data = e.Data.Trim(new char[] { '\0' }).Trim();
                if (data.Length > 0)
                {
                    if (syncOutPutStr.Length > 0)
                    {
                        syncOutPutStr += "\r\n" + data;
                    }
                    else
                    {
                        syncOutPutStr = data;
                    }
                }
            }
        }

        private void SyncErrorDataReceived(object sender, DataReceivedEventArgs e)
        {
            //Test data not null
            if (e.Data != null)
            {
                string data = e.Data.Trim(new char[] { '\0' }).Trim();
                if (data.Length > 0)
                {
                    if (syncErrorStr.Length > 0)
                    {
                        syncErrorStr += "\r\n" + data;
                    }
                    else
                    {
                        syncErrorStr = data;
                    }
                }
            }
        }

    }
}
