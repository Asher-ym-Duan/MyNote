﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using DesignModeStudy;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Collections.Generic;


namespace DesignModeStudy.Test
{
    [TestClass]
    public class Singleton_Test
    {
        [TestMethod]
        public void GetInstance_CanCreat()
        {
            Singleton singleton = Singleton.GetInstance();
            Assert.IsNotNull(singleton);
        }

        [TestMethod]
        public void GetInstance_OneParame_CanCreat()
        {
            Singleton singleton = Singleton.GetInstance("西瓜");
            Assert.IsNotNull(singleton);
            Assert.AreEqual(singleton.MyProperty,"西瓜");
        }


        [TestMethod]
        public void GetInstance_MultiThread_IsOneInstance()
        {
            List<Singleton> singletonsList = new List<Singleton>();
            List<Task> taskLists=new List<Task>();    
            for (int i = 0; i < 5; i++)
            {
                Task task= Task.Run(() => { 
                    Singleton singleton = Singleton.GetInstance();
                    singletonsList.Add(singleton);
                });
                //Debug.WriteLine($"The Current Thread = {Thread.CurrentThread.ManagedThreadId}");
                taskLists.Add(task);
            }
            Task.WaitAll(taskLists.ToArray());
            Assert.IsNotNull(singletonsList);
            for (int i = 0; i<singletonsList.Count-1; i++)
			{
                Assert.AreEqual(singletonsList[i],singletonsList[i+1]);
			}
        }


        [TestMethod]
        public void GetInstance_OneParam_MultiThread_IsOneInstance()
        {
            List<Singleton> singletonsList = new List<Singleton>();
            List<Task> taskLists = new List<Task>();
            for (int i = 0; i < 5; i++)
            {
                Task task = Task.Run(() => {
                    Singleton singleton = Singleton.GetInstance($"西瓜 {i} 号");
                    singletonsList.Add(singleton);
                });
                //Debug.WriteLine($"The Current Thread = {Thread.CurrentThread.ManagedThreadId}");
                taskLists.Add(task);
            }
            Task.WaitAll(taskLists.ToArray());
            Assert.IsNotNull(singletonsList);
            for (int i = 0; i < singletonsList.Count - 1; i++)
            {
                Assert.AreEqual(singletonsList[i], singletonsList[i + 1]);
            }
        }

    }
}
