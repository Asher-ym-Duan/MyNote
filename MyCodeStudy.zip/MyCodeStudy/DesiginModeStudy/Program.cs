﻿using System;
using System.Threading.Tasks;
using System.Diagnostics;

namespace DesignModeStudy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Singleton sin1 = Activator.CreateInstance(typeof(Singleton), true) as Singleton;
            //Console.WriteLine("Hello World!");
            //Debug.Close();
           
            TestSimpleFactory();

            TestFactoryMethod();
            

            TestAbstractFactory();

            Console.ReadKey();
        }

        
        /// <summary>
        /// 测试简单工厂模式的方法
        /// </summary>
        public static void TestSimpleFactory()
        {
            Debug.WriteLine("简单工厂模式");
            AbstractPhone phone = SimpleFactory.CreatPhone(PhoneType.Xiaomi);
            phone.Brand();
        }

        /// <summary>
        /// 测试工厂方法模式的方法
        /// </summary>
        public static void TestFactoryMethod()
        {
            Debug.WriteLine("工厂方法模式");
            XiaomiPhoneFactory xiaomiFactory = new XiaomiPhoneFactory();
            AbstractPhone phone = xiaomiFactory.CreatPhone();
            phone.Brand();
        }

        /// <summary>
        /// 测试抽象工厂模式的方法
        /// </summary>
        public static void TestAbstractFactory()
        {
            Debug.WriteLine("抽象工厂模式");

            IAbstractFactory xiaomiFactory = new XiaomiFactory();
            var xiaomiComputer =  xiaomiFactory.CreatComputer();
            var xiaomiPhone=xiaomiFactory.CreatPhone();
            xiaomiPhone.Brand();
            xiaomiComputer.Brand();

            IAbstractFactory appleFactory = new AppleiFactory();
            AbstractPhone applePhone = appleFactory.CreatPhone();
            AbstractComputer appleComputer = appleFactory.CreatComputer();
            applePhone.Brand();
            appleComputer.Brand();
        }


    }
    class A
    {
        public Action action;
    }
}
