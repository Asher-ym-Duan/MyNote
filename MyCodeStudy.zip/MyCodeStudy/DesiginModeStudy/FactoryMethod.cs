﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace DesignModeStudy
{
    public interface IFactoryMethod
    {
        AbstractPhone CreatPhone();
    }

    public class XiaomiPhoneFactory : IFactoryMethod
    {
        public AbstractPhone CreatPhone()
        {
            return new XiaomiPhone();
        }
    }
    public class ApplePhoneFactory : IFactoryMethod
    {
        public AbstractPhone CreatPhone()
        {
          return new ApplePhone();
        }
    }
}
