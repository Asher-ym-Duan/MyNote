﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace DesignModeStudy
{
    public static class SimpleFactory
    {
        public static AbstractPhone CreatPhone(PhoneType phoneType)
        {
            switch (phoneType)
            {
                case PhoneType.Apple:
                    return new ApplePhone();
                case PhoneType.Xiaomi:
                    return new XiaomiPhone();
                default:
                    return null;
            }
        }

    }

    
}
