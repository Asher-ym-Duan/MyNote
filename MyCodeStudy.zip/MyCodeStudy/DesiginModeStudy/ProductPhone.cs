﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace DesignModeStudy
{
    public enum PhoneType
    {
        Apple,
        Xiaomi
    }
    public abstract class AbstractPhone
    {
        protected abstract void DoOperation();
        public void Brand()
        {
            Debug.WriteLine($"I am {this.GetType().Name}");
        }
    }

    public class ApplePhone : AbstractPhone
    {
        protected override void DoOperation()
        {
            throw new NotImplementedException();
        }
    }

    public class XiaomiPhone : AbstractPhone
    {
        protected override void DoOperation()
        {
            throw new NotImplementedException();
        }
    }

}
