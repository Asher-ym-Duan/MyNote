﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesignModeStudy
{
    public interface IAbstractFactory
    {
        AbstractPhone CreatPhone();

        AbstractComputer CreatComputer();
    }

    public class XiaomiFactory : IAbstractFactory
    {
        public AbstractComputer CreatComputer()
        {
            return new XiaomiComputer();
        }

        public AbstractPhone CreatPhone()
        {
            return new XiaomiPhone();
        }
    }

    public class AppleiFactory : IAbstractFactory
    {
        public AbstractComputer CreatComputer()
        {
            return new AppleComputer();
        }

        public AbstractPhone CreatPhone()
        {
            return new ApplePhone();
        }
    }
}
