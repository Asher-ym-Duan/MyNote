﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesignModeStudy
{
    internal interface IRun
    {
        void Run();
    }
}
