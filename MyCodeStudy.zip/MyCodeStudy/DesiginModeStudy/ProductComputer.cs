﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace DesignModeStudy
{
    public abstract class AbstractComputer
    {
        public void Brand()
        {
            Debug.WriteLine($"I am {this.GetType().Name}");
        }
        protected abstract void DoOperation();
    }
    public class AppleComputer : AbstractComputer
    {
        protected override void DoOperation()
        {
            throw new NotImplementedException();
        }
    }
    public class XiaomiComputer : AbstractComputer
    {
        protected override void DoOperation()
        {
            throw new NotImplementedException();
        }
    }

}
