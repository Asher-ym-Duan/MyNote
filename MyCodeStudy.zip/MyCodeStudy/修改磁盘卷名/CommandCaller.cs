﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChangeDiskVolume
{
    public class ModelCallerMessage
    {
        private string errorDataMessage;
        private string outputDataMessage;
        private int exitCode;

        public ModelCallerMessage()
        {
            this.finish = false;
            this.errorDataMessage = "";
            this.outputDataMessage = "";
        }

        public bool finish { get; set; }

        public string OutputDataMessage
        {
            get { return outputDataMessage; }
            set { outputDataMessage = value; }
        }

        public string ErrorDataMessage
        {
            get { return errorDataMessage; }
            set { errorDataMessage = value; }
        }

        public int ExitCode
        {
            get { return exitCode; }
            set { exitCode = value; }
        }
    }

    public class CommandCaller
    {
        public CommandCaller()
        {
        }

        public string FilePath
        {
            get;
            set;
        }

        private string syncOutPutStr;
        private string syncErrorStr;

        public ModelCallerMessage SyncExcute(String args, int milliSeconds)
        {
            if (FilePath == null)
            {
                return null;
            }

            try
            {
                Process SyncProcess = new Process();
                ModelCallerMessage ans = new ModelCallerMessage();

                SyncProcess.StartInfo.FileName = FilePath;
                //SyncProcess.StartInfo.Arguments = args;

                SyncProcess.StartInfo.CreateNoWindow = false;
                SyncProcess.StartInfo.UseShellExecute = false;
                SyncProcess.StartInfo.RedirectStandardError = true;
                SyncProcess.StartInfo.RedirectStandardInput = true;
                SyncProcess.StartInfo.RedirectStandardOutput = true;
                lock(this)
                {
                    syncOutPutStr = "";
                    syncErrorStr = "";
                    SyncProcess.OutputDataReceived += new DataReceivedEventHandler(SyncOutputDataReceived);
                    SyncProcess.ErrorDataReceived += new DataReceivedEventHandler(SyncErrorDataReceived);

                    SyncProcess.Start();

                    SyncProcess.BeginOutputReadLine();
                    SyncProcess.BeginErrorReadLine();

                    

                    bool isDone = SyncProcess.WaitForExit(milliSeconds);
                  
                    if (isDone)
                    {
                        SyncProcess.WaitForExit();
                        int exitCode = SyncProcess.ExitCode;

                        ans.ExitCode = exitCode;
                        ans.finish = true;
                        ans.OutputDataMessage = syncOutPutStr;
                        ans.ErrorDataMessage = syncErrorStr;
                    }
                    else
                    {
                        ans.ExitCode = -1;
                        ans.finish = false;
                        ans.OutputDataMessage = "";
                        ans.ErrorDataMessage = "";
                        SyncProcess.Kill();
                    }
                }
                return ans;
            }
            catch(Exception e)
            {
                throw e;
            }
        }


        private void SyncOutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            //Test data not null
            if (e.Data != null)
            {
                string data = e.Data.Trim(new char[] { '\0' }).Trim();
                if (data.Length > 0)
                {
                    if (syncOutPutStr.Length > 0)
                    {
                        syncOutPutStr += "\r\n" + data;
                    }
                    else
                    {
                        syncOutPutStr = data;
                    }
                }
            }
        }

        private void SyncErrorDataReceived(object sender, DataReceivedEventArgs e)
        {
            //Test data not null
            if (e.Data != null)
            {
                string data = e.Data.Trim(new char[] { '\0' }).Trim();
                if(data.Length>0)
                {
                    if (syncErrorStr.Length > 0)
                    {
                        syncErrorStr += "\r\n" + data;
                    }
                    else
                    {
                        syncErrorStr = data;
                    }
                }
            }
        }

    }
}
