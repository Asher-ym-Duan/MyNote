﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ChangeDiskVolume
{
    public class Cmd
    {
        private CommandCaller caller;
        public Cmd()
        {
            caller = new CommandCaller();
            caller.FilePath = "cmd.exe";
        }
        public ModelCallerMessage SyncExcute(String args, int milliSeconds)
        {
            return this.caller.SyncExcute(args, milliSeconds);
        }
    }
}
