﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChangeDiskVolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label_Count.DataBindings.Add("Text",this,"Count");
            this.MaximizeBox = false;
            AppendText("Program Start\n");
        }

        private int _count;
        public int Count { 
            get => _count; 
            set {
                _count++;
                this.label_Count.Text = _count.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*System.Diagnostics.Process process = new System.Diagnostics.Process();//创建进程对象
            process.StartInfo.FileName = "cmd.exe";//启动cmd命令
            process.StartInfo.Arguments = "/c convert " + "G:" + " /fs:ntfs";//设置转换命令
            process.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;//隐藏窗口
            process.StartInfo.UseShellExecute = false;//是否使用系统外壳程序启动进程
            process.StartInfo.RedirectStandardInput = true;//是否从流中读取
            process.StartInfo.RedirectStandardOutput = true;//是否写入流
            process.StartInfo.RedirectStandardError = true;//是否将错误信息写入流
            process.StartInfo.CreateNoWindow = true;//是否在新窗口中启动进程
            process.Start();//启动进程            
            process.WaitForExit();//执行完退出
            AppendText("over")*/;
            return;
            this.textBox_after.Enabled = false;
            this.textBox_before.Enabled = false;

            if (string.IsNullOrEmpty(textBox_before.Text)|| string.IsNullOrEmpty(textBox_after.Text))
            {
                AppendText("Input is Empty!");
            }
            string originVolume = textBox_before.Text;
            string changeVolume = textBox_after.Text;
            string output=ChangeDiskVolumeName(originVolume, changeVolume);
            AppendText(output);

            this.textBox_after.Enabled = true;
            this.textBox_before.Enabled = true;
        }
        private string ChangeDiskVolumeName(string originVolume, string changeVolume)
        {
            StringBuilder sb = new StringBuilder(); 
            try
            {
                DriveInfo[] dis = DriveInfo.GetDrives();
                foreach (var item in dis)
                {
                    
                    if (item.IsReady == true && item.VolumeLabel == originVolume)
                    {
                        item.VolumeLabel = changeVolume;
                        sb.AppendLine($"Disk {item.Name} volume name have changed to {changeVolume}");
                        this.Count++;
                    }
                    
                }
                if (sb.Length==0)
                {
                    sb.AppendLine("No matching disk!");
                }
            }
            catch (System.UnauthorizedAccessException ex)
            {
                sb.AppendLine("No administrator privileges!");
                MessageBox.Show("Please re-open the software with administrator!","Error",MessageBoxButtons.OK);
            }
            catch (Exception ex)
            {    
                sb.AppendLine($"Error occurs:"+ex.Message);
            }    
            return sb.ToString();
        }


        private void AppendText(string text)
        {
            string timeStr = DateTime.Now.ToString("HH:mm:ss");
            this.richTextBox1.AppendText($"{timeStr}: {text}");
            //this.richTextBox1.AppendText("\n");
        }


    }
}
