﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace TestConsoleApp
{
    public class FileWatcher
    {
        private string notifyMessage = "";
        public string NotifyMessage { get => notifyMessage; set => notifyMessage = value; }

        FileSystemWatcher fileSystemWatcher;

        public FileWatcher()
        {
            fileSystemWatcher = new FileSystemWatcher();
        }

        private string monitorFolder;

        public string onitorFolder
        {
            get { return monitorFolder; }
            set { monitorFolder = value; }
        }

        private string filter;

        public string Filter { get => filter; set => filter = value; }
        public object MessageBox { get; private set; }

        public void BeginWathceFile(string path, string filter)
        {
            try
            {
                fileSystemWatcher.Path = path;
                fileSystemWatcher.Filter = filter;
                fileSystemWatcher.IncludeSubdirectories = true;
                fileSystemWatcher.NotifyFilter = NotifyFilters.FileName | NotifyFilters.Attributes | NotifyFilters.LastWrite | NotifyFilters.LastAccess | NotifyFilters.Size;
                fileSystemWatcher.Changed += FileSystemWatcher_Changed;
                fileSystemWatcher.Created += FileSystemWatcher_Created;
                fileSystemWatcher.Renamed += FileSystemWatcher_Renamed;
                fileSystemWatcher.Deleted += FileSystemWatcher_Deleted;

                fileSystemWatcher.EnableRaisingEvents = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void FileSystemWatcher_Deleted(object sender, FileSystemEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void FileSystemWatcher_Renamed(object sender, RenamedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void FileSystemWatcher_Created(object sender, FileSystemEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void FileSystemWatcher_Changed(object sender, FileSystemEventArgs e)
        {
            fileSystemWatcher.EnableRaisingEvents = false;
            switch (e.ChangeType)
            {
                case WatcherChangeTypes.Created:
                    break;
                case WatcherChangeTypes.Deleted:
                    break;
                case WatcherChangeTypes.Changed:
                    notifyMessage = $"{DateTime.Now.ToString("HH:mm:ss")}:文件--{e.Name}发生了改变";
                    break;
                case WatcherChangeTypes.Renamed:
                    break;
                case WatcherChangeTypes.All:
                    break;
                default:
                    break;
            }

            fileSystemWatcher.EnableRaisingEvents = true;
        }
    }
}
