﻿using System;
using System.Collections.Concurrent;
using System.Text;
using System.Threading;

namespace TestConsoleApp
{
    public delegate void TestOneParameter(int x);
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            if (true)
            {
                Console.WriteLine("迭代="+DieDai(1) ); 
                Console.WriteLine("迭代="+DieDai(2) ); 
                Console.WriteLine("迭代="+DieDai(3) ); 
                Console.WriteLine("迭代="+DieDai(5) ); 
            }

            ///小于0，升序  大于0，降序
            if (false)
            {
                //int[] aaa = { 1,5,3,-1,4,8,-5 };
                int[] aaa = { 1, 5, 3, -1, 4, 8, -5 };
                //a表示前一个元素，b表示后一个元素
                Array.Sort(aaa,(a,b)=>Math.Abs(a-3)-Math.Abs(b-3));
                //Array.Sort(aaa,(a,b)=>b-a);
                foreach (var item in aaa)
                {
                    Console.Write(item+"\t");
                }
            }

            //字符串的存储方法
            if (false)
            {
                string a = "Good day!";
                string b = "Good day!";
                string c = new string("Good day!");
                string d = new string("Good day!");
                Console.WriteLine("a==b? "+a==b);
                Console.WriteLine("a==c? "+a==c);
                Console.WriteLine("a==d? "+a==d);
                Console.WriteLine("c==d? "+c==d);
                Console.WriteLine("a.Equals(b)? " + a.Equals(b));
                Console.WriteLine("a.Equals(c)? " + a.Equals(c));
                Console.WriteLine("a.Equals(d)? " + a.Equals(d));
                Console.WriteLine("c.Equals(d)? " + c.Equals(d));
            }


            //查看1的数量
            if (false)
            {
                int N = 12;
                Console.WriteLine("数字1到数字"+N.ToString()+"中 1 数量为："+Count1(N));
            }


            //测试字符串"1"的编码
            if (false)
            {
                byte[] a1 = Encoding.UTF8.GetBytes("123");
                byte[] a2 = Encoding.UTF8.GetBytes("18大法师的8");
                byte[] a3 = Encoding.UTF8.GetBytes("000");
                byte[] a4 = Encoding.UTF8.GetBytes("0大是大非");
            }


            //测试ASCII编码和UTF-8解码
            if (false)
            {
                ASCIIAndUTF8("MF-马航");
                ASCIIAndUTF8("calculate: 1 + 2 = ?");
            }


            //测试iniHelper的初始化方法
            if (false)
            {
                Class1.TestInitialString();
            }

            //测试委托作为参数传入方法
            if (false)
            {
                TestOneParameter testone = (x) => { Console.WriteLine("The num is " + x.ToString()); };
                testone(1);

                //TestOneParamterDeledage(TestOneParameter);
            }

            //WatcherFileMethod();

            string str = "My name is asher";
            string subStr = str.Substring(7);

            Console.ReadKey();
        }
        /// <summary>
        /// 求1-2+3-4+…+m
        /// </summary>
        /// <returns></returns>
        public static int DieDai(int x)
        {
            if (x==0)
            {
                return 0;
            }
            int n=x;
            if (x%2==0)
            {
                n = -x;
            }
            return n+DieDai(x-1);
        }


        public static int Count1(int N)
        {
            int a = 0;
            while (N >= 0)
            {
                int Num = N;
                while (Num > 0)
                {
                    if (Num % 10 == 1)
                    { a++; }
                    Num = Num / 10;
                }
                N--;
            }
            return a;
        }

        #region 测试ASCII和UTF-8编码和解码
        public static void ASCIIAndUTF8(string content)
        {
            Console.WriteLine("input is: " + content);
            Console.WriteLine("The string default type is : utf-16 <=> unicode");
            Console.WriteLine();

            //字符串经过不同编码格式装换成字节数组
            byte[] asciiByte = Encoding.ASCII.GetBytes(content);
            byte[] utf8Byte = Encoding.UTF8.GetBytes(content);
            byte[] originByte = Encoding.Unicode.GetBytes(content);
            Console.WriteLine("ASCII encoding byte[]：\t" + ByteArrConvertString(asciiByte));
            Console.WriteLine("UTF-8 encoding byte[]：\t" + ByteArrConvertString(utf8Byte));
            Console.WriteLine("Input-Default encoding byte[]：\t" + ByteArrConvertString(originByte));
            Console.WriteLine();

            //unicode字符串经过相同编解码后的字符串结果
            string asciiStr = Encoding.ASCII.GetString(asciiByte);
            string utf8Str = Encoding.UTF8.GetString(utf8Byte);
            Console.WriteLine("ASCII decoding string：" + asciiStr);
            Console.WriteLine("UTF-8 decoding string：" + utf8Str);
            Console.WriteLine();

            //编码和解码不同的字符串结果
            string encoding_ascii_decoding_utf8 = Encoding.UTF8.GetString(asciiByte);
            string encoding_utf8_decoding_ascii = Encoding.ASCII.GetString(utf8Byte);
            Console.WriteLine("encoding_ASCII_decoding_UTF8：" + encoding_ascii_decoding_utf8);
            Console.WriteLine("encoding_UTF8_decoding_ASCII：" + encoding_utf8_decoding_ascii);
            Console.WriteLine();

            //ASCII编码的字节数组，转化成utf-8的字符串
            string tempStr = Encoding.ASCII.GetString(asciiByte);
            byte[] ascii_utf8_byte = Encoding.UTF8.GetBytes(tempStr);
            string ascii_utf8_string = Encoding.UTF8.GetString(ascii_utf8_byte);
            Console.WriteLine("ASCII encoding byte[]：" + ByteArrConvertString(asciiByte));
            Console.WriteLine("ASCII decoding string：" + asciiStr);
            Console.WriteLine("UTF-8 encoding byte[]：" + ByteArrConvertString(ascii_utf8_byte));
            Console.WriteLine("UTF-8 decoding string：" + ascii_utf8_string);
            Console.WriteLine();

        }

        public static string ByteArrConvertString(byte[] arr)
        {
            StringBuilder sb = new StringBuilder();
            foreach (byte b in arr)
            {
                sb.Append(b + "\t");
            }
            return sb.ToString();
        }
        #endregion


        #region 委托作为参数的方法
        public static void TestOneParamterDeledage(TestOneParameter one)
        {
            Console.WriteLine("This Method:  TestOneParamterDeledage");
            one(3);
            one(6);
        }

        public static void TestOneParameter(int x)
        {
            Console.WriteLine("This Method:  TestOneParamter");
            Console.WriteLine("The Num is " + x.ToString());
        }
        #endregion

        public static void WatcherFileMethod()
        {
            FileWatcher watcher = new FileWatcher();
            watcher.BeginWathceFile(@"C:\Users\F7692596\Desktop\", "*.*");
            while (true)
            {
                string temp = watcher.NotifyMessage;
                Thread.Sleep(1000);
                if (watcher.NotifyMessage != "" && watcher.NotifyMessage != temp)
                    Console.WriteLine(watcher.NotifyMessage);
            }
        }
    }
}
