﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace TestConsoleApp
{
    internal class Class1
    {
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string AppName, string KeyName, string DefaultString, StringBuilder ReturnValue, int Size, string Filename);

        public static string getIniString(string AppName, string KeyName, string defaultString, string filenamee, int size = 100)
        {
            StringBuilder stringBuilder = new StringBuilder();
            GetPrivateProfileString(AppName, KeyName, defaultString, stringBuilder, size, filenamee);
            return stringBuilder.ToString();
        }

        public static void TestInitialString()
        {
            string comPortName;
            int baudRate;
            bool RTS, DTR;

            //相对路径
            //string filePath = "./deviceWatcher/ComPortConfig";
            string filePath = "./deviceWatcher/ComPortConfig.txt";
            comPortName = getIniString("LOT_SINGLE", "COM", "COM3", filePath);

            baudRate = int.Parse(getIniString("LOT_SINGLE", "BaudRate", "9600", filePath));

            RTS = bool.Parse(getIniString("LOT_SINGLE", "RTS", "false", filePath));

            DTR = bool.Parse(getIniString("LOT_SINGLE", "DTR", "false", filePath));

            Console.WriteLine("comPortName="+comPortName);
            Console.WriteLine("baudRate=" + baudRate);
            Console.WriteLine("RTS=" + RTS);
            Console.WriteLine("RTS=" + DTR);
        }
    }
}
