﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Threading;

namespace WinFormStudy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }
        private readonly object _lockOjb = new object();

        private void button2_Click(object sender, EventArgs e)
        {        
              //this.MouseMove += Form1_MouseMove;

        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            this.textBox2.Text = e.Location.ToString();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            List<string> iplist = new List<string>();

            for (int j = 220; j < 224; j++)
            {
                for (int i = 0; i < 255; i++)
                {
                    iplist.Add($"10.156.{j}.{i}");
                }
            }
            foreach (string item in iplist)
            {
                IPHostEntry entry = null;
                this.textBox3.Text = item;
                try
                {
                    Task<IPHostEntry> taskEntry = Dns.GetHostEntryAsync(item);
                    await taskEntry.ConfigureAwait(false);
                    this.textBox1.Text = taskEntry.Result.HostName.ToString();
                    Thread.Sleep(500);
                    if (entry == null)
                    {
                        continue;
                    }
                }
                catch (Exception ex)
                {
                    string dt = DateTime.Now.ToString("HH:mm:ss");
                    lock (_lockOjb)
                    {
                        this.Invoke(new Action(() =>
                        {
                            this.textBox3.Text = ex.Message + " " + dt;
                            Thread.Sleep(500);

                        }));

                    }
                }
                //IPHostEntry entry = Dns.GetHostEntry(item);

            }
        }
    }
}
